var recordData = [
 {
  "length": 59320,
  "seq_id": "BGC0000001",
  "regions": [
   {
    "start": 1,
    "end": 59320,
    "idx": 1,
    "orfs": [
     {
      "start": 1,
      "end": 1083,
      "strand": 1,
      "locus_tag": "orfP",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">orfP</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75490.1</span><br>\n Gene: <span class=\"serif\">orfP</span><br>\n \n Location: 1 - 1,083,\n (total: 1083 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PCMT<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-orfP collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01135.22 (Protein-L-isoaspartate(D-aspartate) O-methyltransferase (PCMT)): [23:143](score: 89.4, e-value: 2.9e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"orfP\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"orfP\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75490.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfP\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfP\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCGAGCTCGACCGGGCCTTCGACGCCGTACCGGCCCCGATCTACACCCACCATGAACGGCACGGCGAAACGGTGCACCGCTCGGCACCGGAGTCGATCCGCCGCGAGCTGGCCGCCCTGCAGGTCCGCGCCGGGGACCGGGTGCTCGAGATCGGTACGGGCTCCGGGTACAGCGGCGCGCTGCTCGCGCACCTGTGCTGCCCGGACGGCCAGGTCACCAGCATCGACATCAGCGACGAACTCGTCCGCCGCGCGGCAGCCATCCACGCCGAGCGCGGGGTAACCAGCGTCGACTGCCATGTTGGCGACGGACTGGCCGGCTACCCGGCCGCAGCGCCCTTCCATCGAGCTGTTTCGTGGTGTGCTCCGCCGCGGCTGCCGAGGGCGTGGACGCAGCAGGTCGTGAACGGTGGGCGGATCGTCGCGTGCCTGCCGATCACGGCCCTGCCGTCGACCACGTTGATCGCCACCATCACCGTTGCGGCCGGGAAACCTCGTATCGAAGCCCTCGCCGGAGGCGGCTACGCCCAGAGCACGCCCGTCGCGGTCGACGATGCCCTGACCGTCCCCGGCCGCTGGGTCGACTACTGCGACCGCCAGCCCGATCCGTCCTGGATCGGCATCTGCTGGCGTTCTGCCGACGACGCCCAGCACACCGGCGCTCGCTCCGCCCTCGGCCAGCTGCTGCATCCCGGGTACACCGACACGTATCGGCAGATGGAGCCGCACTGGCGCTCCTGGTACACCTGGACGTCCGCGCTCGGCGACCCGCAGCTGAGCCTGGTGTCGCTGCGCAACGAGATCCGCGGACTCGGTCACACCACACCAAGTTCGGCGGCGGTGATCCTGACCGATGGCAGGGTCATCGCGGACCGGCCGGACTCGCCGTCCCTGCGCTCCTTGCGGACCTGGCTGCAACGGTGGGAACACGTCGGCCGTCCGGCACCCGAGTCCTTCGCCCGCACCCTGGTGCCGCACGACTGCCCTGATCTCGCCGGCTGGGACCTGCAGGTCGGCCATGGCTCCGTGACCACCGACCGGCAGCCGCCGCGGCGCGTCGATGAGCCTCGCCGCCCTTGA",
      "translation": "MTELDRAFDAVPAPIYTHHERHGETVHRSAPESIRRELAALQVRAGDRVLEIGTGSGYSGALLAHLCCPDGQVTSIDISDELVRRAAAIHAERGVTSVDCHVGDGLAGYPAAAPFHRAVSWCAPPRLPRAWTQQVVNGGRIVACLPITALPSTTLIATITVAAGKPRIEALAGGGYAQSTPVAVDDALTVPGRWVDYCDRQPDPSWIGICWRSADDAQHTGARSALGQLLHPGYTDTYRQMEPHWRSWYTWTSALGDPQLSLVSLRNEIRGLGHTTPSSAAVILTDGRVIADRPDSPSLRSLRTWLQRWEHVGRPAPESFARTLVPHDCPDLAGWDLQVGHGSVTTDRQPPRRVDEPRRP",
      "product": "protein methyltransferase"
     },
     {
      "start": 1208,
      "end": 1834,
      "strand": 1,
      "locus_tag": "AEK75491.1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AEK75491.1</span></strong><br>\n \n  putative hydrolase<br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75491.1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,208 - 1,834,\n (total: 627 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"AEK75491.1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"AEK75491.1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75491.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"AEK75491.1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"AEK75491.1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAGCCGCCGGCCAGCTCTGTCTGCCCGGTGGACACCTCGAAGATGGGGAATCGGTCGTCGCCGGCGCGATACGGGAGACGGCCGAGGAAACGGTGTGTCGAGCTGTCCGAGACGAATCTGGAGTTCGTTCATGTCGTGCACCGCCGCCACGGCCACGACGACCCGCGGCTCGGCTTCTTCTTCCTCGCCACCGCCTGGCAAGGCCAGCCGGTCAACCGGGAACCCCACAAATGCGCAGGCCTGGTCTGGACGGACCCGGCGCAGCCACCCGCCACCACGATCGCGTACACCGTGGCCGCCCTGGAACAGATCCATAGCGGGCGACCCTTCTCCCTGGACGGCTGGGCAGAGCACTCGCCCTCCGCCACGGGCTGCGGAATCGTTGATGTGGCATGGGAACCTCCCGTTCGACGAGGGCAGCGTGAACCGCGCCACCAGCATGACGACGGAGGTCGCCACGGATACACGGTCGGTCAGCCCGACCCCTGCCGTCCGCTGCTCGGGTGTCGCTCGACGGCCCACCCCACCGGTTGCCGTCCTCGCAGGAACGTCTCGTCCTGGCTGCAGCTGTCACCACGCACCCCGGGTCCGTACGCAATTTCTCTGATGTCCCGGGAACGGTGA",
      "translation": "MKPPASSVCPVDTSKMGNRSSPARYGRRPRKRCVELSETNLEFVHVVHRRHGHDDPRLGFFFLATAWQGQPVNREPHKCAGLVWTDPAQPPATTIAYTVAALEQIHSGRPFSLDGWAEHSPSATGCGIVDVAWEPPVRRGQREPRHQHDDGGRHGYTVGQPDPCRPLLGCRSTAHPTGCRPRRNVSSWLQLSPRTPGPYAISLMSRER",
      "product": "putative hydrolase"
     },
     {
      "start": 1887,
      "end": 2633,
      "strand": 1,
      "locus_tag": "abyR",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyR</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75492.1</span><br>\n Gene: <span class=\"serif\">abyR</span><br>\n \n Location: 1,887 - 2,633,\n (total: 747 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1041:transcriptional regulator, SARP family (Score: 257.8; E-value: 4.2e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyR collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00486.31 (Transcriptional regulatory protein, C terminal): [17:87](score: 36.8, e-value: 3.3e-09)<br>\n \n  PF03704.20 (Bacterial transcriptional activator domain): [93:238](score: 126.3, e-value: 1.3e-36)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyR collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyR\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyR\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75492.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyR.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyR\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyR\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGCTCGGAGCATTGCGGATCGCCGATCCCGCACCTCGCACGATTACCGCGCCGAAGGTGGAAACGCTGTTCGCCACGCTCCTCATCCGGGCCAACCACACCGTCACCACCGACGAACTCATCGCTGAGCTGTGGGGCGAGAACCCTCCCCGCCACGCCCGCACCGCGCTGCACGTCTACGTTTCGCAGATCCGCAAGCAGATCCCGAGCCCGCGCCCCGGCGCAGCGGTGCTGCACACGAAGCCGCAGGGCTACCAGATGGAGGTCGACGAGAACCTCGTCGATGCTGTCGAGTTGCAGCGGATGCACGCGCTGGGCAGGTCGTTGCTGGTAACCGACCCGGAGGCGGCCCTGGTCCCGCTGCGCCGCGCGGTCGGGCTGTTCCGGGGTCCCGTGCTCGCCGGCATCCGCAACGGCCTCGTGGTCGGTAACTTCGCCGAATGGGCCGAGGAGGTCCGCGTGGACTGCCTGCACGCCATTGGGCGGGCGGCACTGGCCACGAACCGGCATCGGGAGCTCATCGGCGAACTCGTGCAGTGGGTCGAGGAGCACCCACTGCACGAGCCGCTGCGGGAGGTGTTGATGGTGGCGCTCACCCGGGCCGGTCGCCGCGCCGAGGCGTTGGCGGCGTACCAGTCGACGCGGCGGGTGCTGCACGAGGAGCTGGGGCTTGAGCCTGGTGAGGCGATGCGCCGGCTTCAACTCGCGATCCTGAGTGCCGATGTGGGCCTGGTGCCGGCTGCCTGA",
      "translation": "MLGALRIADPAPRTITAPKVETLFATLLIRANHTVTTDELIAELWGENPPRHARTALHVYVSQIRKQIPSPRPGAAVLHTKPQGYQMEVDENLVDAVELQRMHALGRSLLVTDPEAALVPLRRAVGLFRGPVLAGIRNGLVVGNFAEWAEEVRVDCLHAIGRAALATNRHRELIGELVQWVEEHPLHEPLREVLMVALTRAGRRAEALAAYQSTRRVLHEELGLEPGEAMRRLQLAILSADVGLVPAA",
      "product": "pathway-specific SARP activator"
     },
     {
      "start": 2646,
      "end": 3836,
      "strand": -1,
      "locus_tag": "abyX",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyX</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75493.1</span><br>\n Gene: <span class=\"serif\">abyX</span><br>\n \n Location: 2,646 - 3,836,\n (total: 1191 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1007:cytochrome P450 (Score: 422.2; E-value: 3.1e-128)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyX collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [29:365](score: 95.3, e-value: 3.6e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyX collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyX\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyX\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75493.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyX\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyX\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGACGTCCAGCTGCCCGCGTTCCCGATGACCCGCACCTGTCCCCACCAGCCGCCGGAGGGCTACGCCGCCCTGCGCGAGAATGGGCCACTGGCCCAGGTCCGGCTGGTGGGCGACCGTACGGCGTGGGTGGTGACCGACCACGACGTCGCCCGGACGTTGCTGGTCGACCCGCGACTCTCCTCCGACCGGCTACGACCGGACTTCCCGGTGCTGGTGCCCCGGATGTCCGCCGCCAAGCTGGTACCACTGGTCGGCATGGATCCGCCGGTGCACACCCAGCGGCGGCGCATGCTGATCGCGGCGTTCACTGTCCACCGGACCCAGCAGATGCGCCCAGAGATAGAAGAGATCGTCAGCGCCCGTCTCGACGCGGTGCTGCAGGAGGGCCCGCCGGTGGACCTGGTGCCCACCCTGGCCCTGCCCGTACCGTCCACCGTGATCTGTCGGCTGCTGGGCGTCCCGTACGCCGACCACGACTTCTTCGAGAGCCAGACCCAGCGCATGGTGCTGGGTTCGAGCACCGCACAGGAGGCGGCCGGCGCGGCCGCCGCCCTGACCGAGTACGTCGACACGTTGATCGGGGAGAAGCAGACCAAGCCGGGGGAGGGGCTGCTGGACGAACTCATCGCGAGCCACCTCGACACAGGGCAGATCACCCGGCGGGACCTGGCAGAGACCGTCATGTTCCTACTCGTGGCAGGGCACGAGACCACAGCCAATATGATCACGATGAGCATCGTCGGCCTGCTGGAGAACCCGGAACAACTCGACCGCCTACGCTCCGACTGGAGTCTGCTCCCGAACGCGGTGGAGGAGCTGCTGCGCTACCTGTCCGTCGCCGACGAGATCCAGCGGGTGGTCGCCGAACCCATCGAGGTCGCCGGCCATGTCCTGCGCGTCGGCGACGCGGTCTACCTACCCGCCGCCGCCAGCAACCGGGATCCGGCCGCCTTCCCCGACCCGGACGCGCTGGATGTCTCCCGCCGCGCCCGTCACCACCTGGCCTTCGGCTACGGCATCCACCAGTGCCTGGGCCAGAACCTCGCCCGGGCCGAGCTGGAGGTGACGCTGCGGGCCCTGTTCGAACGACTGCCCACCCTGGCGCTGGCGGAGCCACTGTCGTCGCTGCCGGTGAAACCGGGCGGCTCGGTGCAGGGCGTGTACCGGCTGCCAGTCACCTGGTAG",
      "translation": "MTDVQLPAFPMTRTCPHQPPEGYAALRENGPLAQVRLVGDRTAWVVTDHDVARTLLVDPRLSSDRLRPDFPVLVPRMSAAKLVPLVGMDPPVHTQRRRMLIAAFTVHRTQQMRPEIEEIVSARLDAVLQEGPPVDLVPTLALPVPSTVICRLLGVPYADHDFFESQTQRMVLGSSTAQEAAGAAAALTEYVDTLIGEKQTKPGEGLLDELIASHLDTGQITRRDLAETVMFLLVAGHETTANMITMSIVGLLENPEQLDRLRSDWSLLPNAVEELLRYLSVADEIQRVVAEPIEVAGHVLRVGDAVYLPAAASNRDPAAFPDPDALDVSRRARHHLAFGYGIHQCLGQNLARAELEVTLRALFERLPTLALAEPLSSLPVKPGGSVQGVYRLPVTW",
      "product": "cytochrome P450"
     },
     {
      "start": 3927,
      "end": 6596,
      "strand": -1,
      "locus_tag": "abyH",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyH</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75494.1</span><br>\n Gene: <span class=\"serif\">abyH</span><br>\n \n Location: 3,927 - 6,596,\n (total: 2670 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1149:LuxR family transcriptional regulator (Score: 204; E-value: 7.1e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyH collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00196.22 (Bacterial regulatory proteins, luxR family): [828:884](score: 57.3, e-value: 9.6e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyH collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00196.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyH\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyH\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75494.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyH.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyH\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyH\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCGCGACACGGCAGAGCATCGGATCGGCACATCCGGGCGTCACACACCGCAGGCCCAGGCCACACCCGCAGATCGGCTGTCGCAGGCGCTCGCCCGGGCCCGCTCCGGGCGCGGTGGCGTAGTGGAACTGGTCGGTGAGCCGGGGATCGGCAAGACGCAGGCACTGACCGAGCTGACCCGGCTCGCCCGCGTGGCGGGCATCCCGATCGCCGCCGGTCGGTGCACCGAGGTGACACCGGACAGCCCGCTGACCCTCGCCGCCGCGGTGACCGGAGCCACGGGGAGTCCCGGCGAACTGGCCGATGCGTTGCGGCAGGCCGCCGATCCGGCCGGGTTGCTGGTCGCCGTCGACGACTTCCACTGGGCCGGCGAGGATTCGGTACGGCTGGTGCGGGCGCTGACCCAGACGGCGCTGGACGTCGGGCTCCTGGTCGTCATCGCACTGCGACCGACGCAGACCCACACCGGGCTGCTCGCGGTGCTGGCCGACGGCCGCGACGTCGGTGTCGTCGAGCGCGTGGAGGTGGGTCCGCTGACGCTGCCGGAGTCCGCCCGGCTGCTCGGCTGCAGCATCAAGGACCCACAGGTCCGCAGGCTGCACGAGCGGGCCGAGGGCAATCCCCGGTACCTGCTGGCACTGGCCGCTCCGCGCGGTGCCGCCGCGACGGCGCTGCTCGGCGAGAAGGCGTCACTCGGGCCGGACGCGACGCGCGTCCTGGAAGCCGCCGCCGTGCTGGGTGGCTCGGTGGACGTCGCCGGCGTCGCCGAGGTGGCCGGTCTGCCGCGCGAGCGCGCCTGCGCGGCCACCAGCGTGCTGGTCCGCCGTGACCTGCTGCGCCCGTCCGACCGGCCGCGGGAGTACGTCTTCCGACATCCGGTGCTGCACACGCTCTACTACGACGACATCGACATCTGCTGGCGGGCGGCGGCGCACCGCCGGGCGCGGACCCTGCTGTTGTCACGTGGCGCCCCGCACAGCGTGGTGGCTCCGCACGTCGAGCGGGCACCGCAGGGCTCCGACGAGGATCTGACCGTGCTGGCCGGCGCGGCACAGGAGGCCATGGCGGGCACTCCCGCACAGGCCGTGCGCTGGCTACGGGTGGCGTTGGATCTCGCGCCGGCCGGTGCCCACGCCCGCAACGAGCTTGCCTCCGCCCTGGTCGGCGCGCTGCTCGCGTCGGGGCAGCCCACCGCCAGCAGCGTTCTGCTGCACCAGATCCTGCGGTCCGACCCGCCGCTGTCCTGGGAGGCGCGAGCCCACGCGCTGGTGCCCGGCGCCCTGGCCGAGTGCCTGCTGGGGCGGGCCCGCGAGGGCGGCAGCCTCATCGCCGCCGCACTGGCCGAGGCCCCCGAGGATCCGCCTGCGGTGCTGGTACGCCTCGCGGTCGTGCAGGGCGTGCTGGCGAGCCTGGAGGGAGTTGCGCTGACTCCCGGCGTGGCGGACGTCGCGCTGCGGGTGGCACGCGTACACGGCGACCGGCTCGGCGAGATGGGCGTCCTGTCCGTCCGCGCCTTCGGCGCCGGTGGCGGCGCCGCCAGCGCGGCGGACCTGTCGGCGGCCGCCGCCATCGCGGACGCGGCGGCCGACCCTGACCTGGCCGCAGATCCCGAGTGCCTGGTCATGCTGGCCTCGGCCGAGTCGTACAGCGGCCGATACCGCGACGCACGCCGTCACGCCGCACGCGGCGTGACGGTGATCCGGCGCAGCGGGGGCCGCCACCTGCTCCCGCTGCTCTACAACACGCTGAGCAACAGCTGCCGAAGGCTGGGCGAGTTGGACGCCGCGCAGGAGGCGGCCGCCGAGGCCGCGCGGATCGCGGAGCAGATGGGTGCGTGGCGACTGCACGGGCTGGCGCTGGCGCTGCGTTCGCTCAGTCTCGCCTGGCTGCTGCCGCAGGGCGACCGGGAGCCGGTCGACCTGGCGGAGCAGGCAGCGGCGATCCTCCCACCGGGCAGCTCGACGTGGAGCGCCACGGCCGGGCTGGCGTTGGCACAGGCGGCCCTGGCCGGCGGCGACCCCCGTCGGGCCGTGACCGTCATCCTGGACTTCGGTGGTGGTCCGGGCCTGGACGACATCCCCGACGTGCTGCGTCCGTGGAGCTACGAACTCCTGGCCGCCGCCTCCGGCCGGGCCGATCTTCCCCTGGCGGAGTGGGCGAGCCGCGCCGCGGCGGTCGTGGACCGGATGGGCGTGCCCTACCTACGGCCCTACGCCGTCTCCGCCCGCGCCCACCTGCTGCGCTCGCGCAACGACCTGGCCGGCGCGACCGCGCTCTTCCGCGAGGCCGCCGCGCTCTTCCACACCGCCGGTCTGGCCTTCTCCCAGGCCGTCGCCCTGGCCGAAGCGGCCCGTTGCCAACCCGGCGCGGGCCGGGCTGACCTGGCCCTCGCCCGGGAGGTGGCCCGGCGCTGCGGCGCAGGCCGAGCCCTGGCCGAATACCGCACCCGCCCGTCGGTGACGGAGGTGACCCACCCGATGCTGTCCGTCCTCACGCGACGCGAGCAGGAGATCGCGTCGATGGCGGGCACCGGTCGCAAGACCAAGGACATCTCCAACAGCCTGGCGATCAGCCCCCGCACCGTTGACGTCCACCTCACCCGCATCTACCGCAAGTTGAACATCGCCACCCGCGCCGAGCTGGCCCGGCTCATGGCGAGCATCGCCTGA",
      "translation": "MRDTAEHRIGTSGRHTPQAQATPADRLSQALARARSGRGGVVELVGEPGIGKTQALTELTRLARVAGIPIAAGRCTEVTPDSPLTLAAAVTGATGSPGELADALRQAADPAGLLVAVDDFHWAGEDSVRLVRALTQTALDVGLLVVIALRPTQTHTGLLAVLADGRDVGVVERVEVGPLTLPESARLLGCSIKDPQVRRLHERAEGNPRYLLALAAPRGAAATALLGEKASLGPDATRVLEAAAVLGGSVDVAGVAEVAGLPRERACAATSVLVRRDLLRPSDRPREYVFRHPVLHTLYYDDIDICWRAAAHRRARTLLLSRGAPHSVVAPHVERAPQGSDEDLTVLAGAAQEAMAGTPAQAVRWLRVALDLAPAGAHARNELASALVGALLASGQPTASSVLLHQILRSDPPLSWEARAHALVPGALAECLLGRAREGGSLIAAALAEAPEDPPAVLVRLAVVQGVLASLEGVALTPGVADVALRVARVHGDRLGEMGVLSVRAFGAGGGAASAADLSAAAAIADAAADPDLAADPECLVMLASAESYSGRYRDARRHAARGVTVIRRSGGRHLLPLLYNTLSNSCRRLGELDAAQEAAAEAARIAEQMGAWRLHGLALALRSLSLAWLLPQGDREPVDLAEQAAAILPPGSSTWSATAGLALAQAALAGGDPRRAVTVILDFGGGPGLDDIPDVLRPWSYELLAAASGRADLPLAEWASRAAAVVDRMGVPYLRPYAVSARAHLLRSRNDLAGATALFREAAALFHTAGLAFSQAVALAEAARCQPGAGRADLALAREVARRCGAGRALAEYRTRPSVTEVTHPMLSVLTRREQEIASMAGTGRKTKDISNSLAISPRTVDVHLTRIYRKLNIATRAELARLMASIA",
      "product": "LuxR family transcriptional regulator"
     },
     {
      "start": 6952,
      "end": 7710,
      "strand": 1,
      "locus_tag": "abyI",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyI</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75495.1</span><br>\n Gene: <span class=\"serif\">abyI</span><br>\n \n Location: 6,952 - 7,710,\n (total: 759 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1041:transcriptional regulator, SARP family (Score: 257.6; E-value: 4.6e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyI collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00486.31 (Transcriptional regulatory protein, C terminal): [22:83](score: 34.9, e-value: 1.4e-08)<br>\n \n  PF03704.20 (Bacterial transcriptional activator domain): [94:240](score: 136.6, e-value: 8.4e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyI collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyI\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyI\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75495.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyI.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyI\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyI\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCTACGAATTACTCGGACCACTACGACTGGTGGGCGTGGACACCCGTACACCGGTCAACGCGCCCAAACAGCAGGCGTTGTTGACCACGCTGCTGATTCGCTCCGACCAGGTCGTCGGCAGTGAGCACCTCGGCACCGAACTCTGGGGCGAGCGCCCTCCGCGGCGCGCGCAGGCCGCCCTGCACGTGCACGTGTCCCAGGTGCGCCGCCTGCTCCCGGCAGGTCGGCTCGCGACCGTCACAGGCGGCTACACGCTGCGGATCCGGGCCGGTGACGAGGTCGACGCCCACGAGTTCCGCGCGCTGTCCGAGCGGGGGCGGGCGCATCTGCGCGCGCGCCGGTACCGGGAGGCGGTGGCGTGCTTGGAACGGGCATTGACGCTGTGGCGGACCGGCCCGGTGCTGACGTTGGCCGGCGGGCGGACCGTCGCCGTCTTTGCCCGCTGGCTGGAGGAGACCCGGTTGGAGTGCCTGGAGATGCTCGTGGAGGCGCGACTCGCGCTGGGCGGGCACCAGGAGGTGGTCGACCTGCTGACCGCGGTGCTGGCCGACCATCCACTGCACGAGAACTTCCACCGGCAACTGATGGTCGCGCTGGTCCGCGCCGGACGATGGACCGACGCGTTGCGCGCCTACCAACACACGCACCGGCTGCTCCGCGAGGAACTCGGGTTGGAGCCGGACCGGTCGCTGCGCGAGTTGCACCACTGGATCCTGCGGGCCTACCGGCGGCGGGAGGTAGCCCAAGCCTGCTGA",
      "translation": "MRYELLGPLRLVGVDTRTPVNAPKQQALLTTLLIRSDQVVGSEHLGTELWGERPPRRAQAALHVHVSQVRRLLPAGRLATVTGGYTLRIRAGDEVDAHEFRALSERGRAHLRARRYREAVACLERALTLWRTGPVLTLAGGRTVAVFARWLEETRLECLEMLVEARLALGGHQEVVDLLTAVLADHPLHENFHRQLMVALVRAGRWTDALRAYQHTHRLLREELGLEPDRSLRELHHWILRAYRRREVAQAC",
      "product": "pathway-specific SARP activator"
     },
     {
      "start": 8175,
      "end": 10034,
      "strand": -1,
      "locus_tag": "abyK",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyK</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75496.1</span><br>\n Gene: <span class=\"serif\">abyK</span><br>\n \n Location: 8,175 - 10,034,\n (total: 1860 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyK collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05593.17 (RHS Repeat): [131:167](score: 26.5, e-value: 7.4e-06)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyK collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [90:119](score: 19.2, e-value: 0.00031)<br>\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [131:167](score: 31.0, e-value: 5.4e-08)<br>\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [238:280](score: 33.4, e-value: 9.6e-09)<br>\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [309:335](score: 18.6, e-value: 0.00048)<br>\n \n  TIGR03696 (Rhs_assc_core: RHS repeat-associated core domain): [501:572](score: 40.1, e-value: 9e-11)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyK\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyK\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75496.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyK\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyK\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCGCTCCGTCGACGCCATGCGTTTTGCTGTCCGCGCCGCGGCGAGTTGCCCGAGACCACCCGACCGAGAGGTCCTCGCATGACCCTTGCCCATGAACGAGCGGACGGGCGGAGCCTGGTGTCTCGCCACCCGGACCGCCCGGACCTGCCCCTGTCGCTGGCCGACGCCGCCGGCAACCGGGTGGACTACAGCTACGACGACGGCGGGCGGCTGCTGCGCGCCTACTCCCGGGCCTTCGACCGCGACATCGAGACCCGGACCTACCACCCGGACGGATCGCTCGCCTCGGCCACCGACGGTCGGGGCGCGACCACGGGGTACCACTACGACGGGCGTGGACGCCTGGTCGCCATCGACCCGCCCGAGCCGCTCGGCCAGATCCGCTTCGCCTACGACGACGATTCCCGCGTCGTCCGGGTCACGCACGGTAACGGCCAGCGCGTCGGCTTCACGTACGACGCGTCGGGTCGACTGGTCGAGGTCCGTGACGACGACACCGGCCAGGTGCTCGGGGACTTCGCCCACGACTCCGCCGGCAACCTGACCCACCGGTCCGGCCCGGGCTGGTCGGAGTCGATCCAGTGGCGTGACGGCCGGCGCATCGGCTCGGTCCGGCGCGAGGGCCGCGAGATGGAACAGGTCGGCTACCGCCACACCGCCTCCGGTGCGCTGGCCGCCCAGTTGGACCTCAACGGCACCACCACCTACGGTTACGACGCCGCCGGTCGGCTCGCGGTGCTCGACGACCCGTTCGGTGGCCGGACGAGCTTCGAGTACGACGGCGCCGGGCGGCGTACGGCCACGGTCTTCGCGGGCGGGGGCAGCCAGCGCACGGAGTACGACGCGCTGGGCCGGCCGGTGCGCCTCGTGGTGGCCGACGGGCGGGGCGACCCGGTCCACACGGTGTCGTACGACTACGGCGGTGGTGCCCTGCTCGCCGCCCGCACCGTCGACGGCGTGACCACCGAGTACGCCTACGACGGCCTGGGCCGGGTGGTCCGCGCCGGTGACGAAGAGTTCGGCTACGACCTGGCGAACAACCTGATCCGACTCGGTGGCACCACGTTCGACGTCAACGACGCCGGGCAGCACGTGCGCTTCGGTGAGACGGTCCTCGGCTACGACCGGTCGGGCAACTTCGTCGACGAGGTGAATCCGACGGTGCGCTTCACCTACAGCCCGACCAACCAGACCCGTACCGGGTCGGTCGACGGCCGGCAGGTGGTCGACATCCGCTACGACGGTCTGGACAATCGCGAGCCACGCCGGATCCACGAGACCACGCTGGACGGGCGGTCGGTGACCCACGTTCTGCACCGCACGTCGCTGGGCATCGTCCGGGTCACCGACGACGTACCCACGGCGTTCGTCAGGGAGCCCAGCGGCCGGCTGATCGGGTTGCGCACGGCGGACGGGACCCGCTACCAGGCGGTCACCGACCACCAGGGATCGGTGTTGGCGCTGCTGGCCACGGACGGGACGCTGGCCGCCACCTACACCTACAGCGCGTTCGGCGCGGTCACCGCGACCAGCGGCGTCGCGGCCGTCAACCCGTTCCGCTACCTGGGCGCCTACCAGTTGCTGCGGGGCGCCCACTTCCTGGAGTGCCGCATCTACAACGGGGCATGGGGGCGGTTCACCCAGCCGGATCCGCGGCACCAGGCCCGCGCCCCGTACACCTTCGCAGACAACGACCCGGTGAATTTGGGCAACCCGGCCCGCACCAATTTCTGGGCGACGCTGTCGCGGCCGCCGCGGGAGGCGGTCGCGGCGTTCCACGGCACCCCGCCCCCGCCGACGACGTTTCTCGGCACCGGCATTCCGTTCATCACCCGACGAGGAGACGACAATGACTGA",
      "translation": "MALRRRHAFCCPRRGELPETTRPRGPRMTLAHERADGRSLVSRHPDRPDLPLSLADAAGNRVDYSYDDGGRLLRAYSRAFDRDIETRTYHPDGSLASATDGRGATTGYHYDGRGRLVAIDPPEPLGQIRFAYDDDSRVVRVTHGNGQRVGFTYDASGRLVEVRDDDTGQVLGDFAHDSAGNLTHRSGPGWSESIQWRDGRRIGSVRREGREMEQVGYRHTASGALAAQLDLNGTTTYGYDAAGRLAVLDDPFGGRTSFEYDGAGRRTATVFAGGGSQRTEYDALGRPVRLVVADGRGDPVHTVSYDYGGGALLAARTVDGVTTEYAYDGLGRVVRAGDEEFGYDLANNLIRLGGTTFDVNDAGQHVRFGETVLGYDRSGNFVDEVNPTVRFTYSPTNQTRTGSVDGRQVVDIRYDGLDNREPRRIHETTLDGRSVTHVLHRTSLGIVRVTDDVPTAFVREPSGRLIGLRTADGTRYQAVTDHQGSVLALLATDGTLAATYTYSAFGAVTATSGVAAVNPFRYLGAYQLLRGAHFLECRIYNGAWGRFTQPDPRHQARAPYTFADNDPVNLGNPARTNFWATLSRPPREAVAAFHGTPPPPTTFLGTGIPFITRRGDDND",
      "product": "YD repeat protein"
     },
     {
      "start": 10118,
      "end": 11143,
      "strand": 1,
      "locus_tag": "abyA1",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75497.1</span><br>\n Gene: <span class=\"serif\">abyA1</span><br>\n \n Location: 10,118 - 11,143,\n (total: 1026 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) fabH<br>\n \n  biosynthetic-additional (smcogs) SMCOG1084:3-oxoacyl-(acyl carrier protein) synthase III (Score: 291; E-value: 1.7e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA1 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08545.13 (3-Oxoacyl-[acyl-carrier-protein (ACP)] synthase III): [118:198](score: 43.0, e-value: 3.4e-11)<br>\n \n  PF08541.13 (3-Oxoacyl-[acyl-carrier-protein (ACP)] synthase III C terminal): [253:325](score: 29.7, e-value: 6e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyA1 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08545.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004315' target='_blank'>GO:0004315</a>: 3-oxoacyl-[acyl-carrier-protein] synthase activity<br>\n  \n   PF08545.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006633' target='_blank'>GO:0006633</a>: fatty acid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75497.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyA1.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCAGGACCGTCTCGGTACTCTCGGCGGCCTCGGCGCTGCCCGGGCCGACGGTGGACAACGCGACGCTGGGCCGGCGGCTGGGCATGGACCGCCTGTGGGAGCAGTGGGTCGACGCCTTCATCGGCACCCGTACCCGCCACCTCGCCGTCGATCTGGACAGTGGCGAGATCCGGCACACGCTGGCCGACCTGGCCCACCAGGCCGGAAGCCGGGCTCTCGACGCCGCGGGTGTCACGCCCGAGGAGGTCGACCTGGTGGTGCTGGGCACCGCCACACCGGACCGCCTGATGCCGACGACAGCCACCGTGGTAGCCGACCGGTTGGGCATCGACGGGGTGCCCGCCTACCAGCTCCAGTCCGGCTGCTCGGGTGCCGTGCAGGCCCTGGCCGTCACCCGCAGCCTGCTGCTCGGCGGCACCGCACGCACCGCCCTTGTGCTCGGCGGGGACGTGGTGGCCCGGTTCTACGACCTGACCGCCGACCTGCGGAAGCTGCCGCCCGCGGAGTTCGTCAACTACGTCCTGTTCGGCGACGGCGTCGGGGCCGCGGTCCTGCGGGTCGGCGAGGTCGCAGGCGCGGCGGCGCTGCGCTCGGTCTTCACCCGGCTGGTCGGCCTCGGTCGGGAACCCGGCGCGACACTGGAGTGGTTCGGGCCGACCGAGGACCGCAACCGGCCCGCGGCGACCGAGGACTACAAGGCCATCGAGCGCCACGTGCCGGACCTGGCCGCCGAGGTCGTCGAGGAGCTGCTCGGCGAGTTGGGCTGGGCGCGCGACGACCTCGACTACGTGCTGCCGCCACAACTGTCCGGCCGGATGACCGCGCTGATCGTGGAACGCCTGAAGCTGCCGCAGGCCACCGAGGTGAGCTGTGTGGCGGAGACCGGCAACAACGGCAACGGAATCGTCTTCCTCCAGCTCGAACGGGCGCTCGCCCGACTCGCCGGGGGACAGCGGGCGCTGGGTGTGTCCATCGAGTCCAGCAAGTGGATCAAGTCGGGCTTCGCGTTGGAGGGCCTGTGA",
      "translation": "MTRTVSVLSAASALPGPTVDNATLGRRLGMDRLWEQWVDAFIGTRTRHLAVDLDSGEIRHTLADLAHQAGSRALDAAGVTPEEVDLVVLGTATPDRLMPTTATVVADRLGIDGVPAYQLQSGCSGAVQALAVTRSLLLGGTARTALVLGGDVVARFYDLTADLRKLPPAEFVNYVLFGDGVGAAVLRVGEVAGAAALRSVFTRLVGLGREPGATLEWFGPTEDRNRPAATEDYKAIERHVPDLAAEVVEELLGELGWARDDLDYVLPPQLSGRMTALIVERLKLPQATEVSCVAETGNNGNGIVFLQLERALARLAGGQRALGVSIESSKWIKSGFALEGL",
      "product": "3-oxoacyl-ACP synthase III"
     },
     {
      "start": 11140,
      "end": 13008,
      "strand": 1,
      "locus_tag": "abyA2",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75498.1</span><br>\n Gene: <span class=\"serif\">abyA2</span><br>\n \n Location: 11,140 - 13,008,\n (total: 1869 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1256:FkbH like protein (Score: 445; E-value: 2.5e-135)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyA2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01686 (FkbH: FkbH domain): [262:589](score: 293.8, e-value: 3.5e-88)<br>\n \n  TIGR01681 (HAD-SF-IIIC: HAD phosphatase, family IIIC): [264:386](score: 60.0, e-value: 9.8e-17)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75498.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACGGCGGGTGCCGCGGCCCCGTCCGCCACCGGGTCGGACGCGGCGGCTGAGCTGTCCGAGCTGTACCGCAGCGGCCGGCTGCCCACCGAATTCCCCCGCCTGCGCGCGCTGCTCGCCGAGCTGCCCGACACCGAGCTGCACCGGGCGGGTCGGCTGCTCGAACGGGTGGGCCCCGACGCGGTACGGGCGGCGCACCCGGACGTGCCGGTCGTGCCGATCACCGTCAGCGGGTACGGCACGGTGGCCCCGCTGGTCCCGCTGCTCACCGTGGAGTTGGCCCGGCACGGCCTGCTGCTCGATCCCCGGCTCGGGGACTTCGGCGGCTACCTGGACGCACTCGCCGCCCCGGACGACTCGTCGCTGCTGCTGACCCTGCTCGACGCCCAGGTCGTCTTCGACCAGGTGCCGACACCGTGGCGTCCCGAGGACGTGGCCCACACCTTCACCGCGAAGATCGACCTGATCGAGGGGCTGCTGGCCCGCTCGACCACCCCCGTGGTGCTCAACACGATCCCCCTGCCGAGGATCTTCCCCGCCCAACTGATCGACCACCGGTCCCGCGCCCTGCTCGGCGCCGTGTGGCGGGAGGCGAACGCCCGCCTGCTGCGGCTGTCGCAGGACCACCCGACCGTCGTGGTCGTGGACCTCGACCCCTGGGCGGCGACCGGGCTCGCGGTCCGCGACGCCCGGCTCAGCGTCTACGCCAAGGCGCACCTGACACCGCCGCTGCTGCACGCCTACGCCCGCGAGGTCGCCCACCTGGCCCGGGCCCGTGCCGGCGCGGCCCGCAAGGTGCTCGCCCTGGACCTGGACGAGACCGTCTGGGGAGGGGTCGTCGGCGAGGTCGGCCCGCTCGCCGTCGAGGTGGCCGACAGCCACCGGGGCGAGGCGTTCCGCGAGTTCCAGCGGGTCGTCCGCCAGCTCGGGTCGCAGGGTGTGCTGGTCGCCGCGGTGAGCAAGAACGACCCCGAGCCGGTACGCGAGGCGCTGCGCGCGCACCCAGGCATGACACTGCGGGAGGACGACTTCGTCCGGGTCGTGGCGAACTGGCGGCCCAAGCACGAGAATCTGCGCACCCTCGCCGAGGACCTCAACCTCGGGCTCGACAGCGTCGTCTTCGTCGACGACAGCCCGTTCGAGCAGGGCCTGGTCCGCCGCGAACTGCCCGAGGTGGCGGTGGTCGCCGTCGACGACGAGCCGGCCGATCACGTCGGACGGCTGCTCGCCGACGGCTGGTTCGACACCGTGACGCTGACGGCGGAGGACCGGCAACGACCCGGTCTGTACCGCGCGGAGGTGGAGCGCCGCGACTTCTTGCACTCCTTCGACTCGCTGCGCGACTACCTGGCGGAGCTCAAGGTACGGGTGGACCTGGCCGTCGCCGACGAGACCGACGTGCCCCGCGTCTCGCAGTTGACGCTGCGGACCAACCAGTTCAACCTGACCACCCGGCGACTGGCGCCCGCCGACGTGCTCGCTCTGCTGCGCCACCCCGCCGCAACCGTGCTCACGGTGCGCTGCGCCGACCGTTTCGGCGACATCGGGCTCGTCGGCGCGGTCGTCCTCCGCCACGACGACGACGTCCTGCACGTCGACAACTTCGTGCTGAGCTGCCGGGCCTTCTCCCGCGGGGTGGAGACGGCGACGCTGGCCGAGATCCTGCGCCACGCACGCGGCAGCAGCGCGTCCGCCGTCACCGCCGAGTACCTGCCCAGCCGTCGCAACGCCAAGGTGGCCGACTTCTACCCCCGCAACGGGTTCACGCGTCTCGACGCCACCCACTTCCGGCACGACCTGACCGACATGCCCCGACCGCCGGAACACGTCCAGTTGACCGGCTCCTGGCCCCCCGGAGGAACCCCGTGA",
      "translation": "MTAGAAAPSATGSDAAAELSELYRSGRLPTEFPRLRALLAELPDTELHRAGRLLERVGPDAVRAAHPDVPVVPITVSGYGTVAPLVPLLTVELARHGLLLDPRLGDFGGYLDALAAPDDSSLLLTLLDAQVVFDQVPTPWRPEDVAHTFTAKIDLIEGLLARSTTPVVLNTIPLPRIFPAQLIDHRSRALLGAVWREANARLLRLSQDHPTVVVVDLDPWAATGLAVRDARLSVYAKAHLTPPLLHAYAREVAHLARARAGAARKVLALDLDETVWGGVVGEVGPLAVEVADSHRGEAFREFQRVVRQLGSQGVLVAAVSKNDPEPVREALRAHPGMTLREDDFVRVVANWRPKHENLRTLAEDLNLGLDSVVFVDDSPFEQGLVRRELPEVAVVAVDDEPADHVGRLLADGWFDTVTLTAEDRQRPGLYRAEVERRDFLHSFDSLRDYLAELKVRVDLAVADETDVPRVSQLTLRTNQFNLTTRRLAPADVLALLRHPAATVLTVRCADRFGDIGLVGAVVLRHDDDVLHVDNFVLSCRAFSRGVETATLAEILRHARGSSASAVTAEYLPSRRNAKVADFYPRNGFTRLDATHFRHDLTDMPRPPEHVQLTGSWPPGGTP",
      "product": "phosphatase and glyceryl transferase"
     },
     {
      "start": 13005,
      "end": 13241,
      "strand": 1,
      "locus_tag": "abyA3",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75499.1</span><br>\n Gene: <span class=\"serif\">abyA3</span><br>\n \n Location: 13,005 - 13,241,\n (total: 237 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00550.28 (Phosphopantetheine attachment site): [9:73](score: 34.8, e-value: 1.6e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75499.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCACCCTGCGATCCGTCCACGACTTCGTCACCCTGGTCCGCGACGAGCTTGGGCTGCCCATCGAGGAGAGCGACCTCGACCGCCACCTCGACGACGTCGCCGGATGGGACTCCGTCCACCTGCTCGCGCTCTGCTCGGCGCTGGAGCGCGCCACCGGGCGGTCCATCTCGCTCCCGGCCGTCCTGACCGCCGACAGCCTGGGCGGGATCTACGCGACGGCGGTGGATCGGTGA",
      "translation": "MSTLRSVHDFVTLVRDELGLPIEESDLDRHLDDVAGWDSVHLLALCSALERATGRSISLPAVLTADSLGGIYATAVDR",
      "product": "acyl-carrier protein"
     },
     {
      "start": 13238,
      "end": 13993,
      "strand": 1,
      "locus_tag": "abyA4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75500.1</span><br>\n Gene: <span class=\"serif\">abyA4</span><br>\n \n Location: 13,238 - 13,993,\n (total: 756 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA4 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00198.26 (2-oxoacid dehydrogenases acyltransferase (catalytic domain)): [164:250](score: 64.0, e-value: 1.5e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyA4 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00198.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75500.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCAGCGTCTCCCCCGTCGCCCGCGAGCGCCGGCACACCCTCTTCTTCCTGGAGGCCGTGCGGTCCTTCGCGCCCGTGCACCTGGACGCCGAGGTGGACATGAGCCGCGTCCTGGCCGAGCGGAACCGGGCGCGGGCGGACGGACGGCGGCAGTCGATCGTCAGCCACGTCGTCGTGGCGGCGGGCCGGGTGCTCGCCAAGCATCCCGAGGCCAACGCCGCGATCCAGGGCCGGCTGCGCGCCCGGGTGGCCCGGTACCCGTTCGTGCACGCCAAGGTCACCGTGGACGGTGTCCTCAACGGGGCCCGCGTCGTCCTGGCGACCGTGGTGCCGAATGTCCACGAGGCCGATGTGGACCAGGTGCAGGCCCACCTGAGCCGGATCCGCGCCGTCGACCCGGAACGCGCTCCCGAGTTCGCGGGCATCCGTCGGGTGCACGCCTCGGCCCTGCCGCTGGCGTACGCCCGGTTCCGGCGGGCCGTGCGCGACCTGCGCGTCCGCCCGCTGCTCACCGGCACCGTCGCGGTGACCTCCCTCGGGCACCGCGACGTCGACGGCTTCCACTCCGTCGGGGGCACCACGGTGACGATCGGCGTGGGACGTGTCGCCGACCGGCCGGTGGTCCGTGACGGCCAGATCACCGTCGCACCCGTGCTGCGCCTCAGCCTGACCTTCGACCACCGCGTCATCGACGGGGCGGAAGCGGCCGACGTGCTGACCGACCTCAAGCAGGAACTGGAGAACCCGGCATGA",
      "translation": "MTSVSPVARERRHTLFFLEAVRSFAPVHLDAEVDMSRVLAERNRARADGRRQSIVSHVVVAAGRVLAKHPEANAAIQGRLRARVARYPFVHAKVTVDGVLNGARVVLATVVPNVHEADVDQVQAHLSRIRAVDPERAPEFAGIRRVHASALPLAYARFRRAVRDLRVRPLLTGTVAVTSLGHRDVDGFHSVGGTTVTIGVGRVADRPVVRDGQITVAPVLRLSLTFDHRVIDGAEAADVLTDLKQELENPA",
      "product": "pyruvate/2-oxoglutarate dehydrogenase"
     },
     {
      "start": 13990,
      "end": 15057,
      "strand": 1,
      "locus_tag": "abyA5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75501.1</span><br>\n Gene: <span class=\"serif\">abyA5</span><br>\n \n Location: 13,990 - 15,057,\n (total: 1068 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA5 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06500.14 (Esterase FrsA-like): [45:283](score: 46.8, e-value: 1.9e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75501.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAACGACGTCGCAGAGCTGAAGCAGTACGTCCTCGCCCACGTCAGTGCCCAGAACGCCAGCGCGGACGGCGTGCTCGCCCGCATCGACGACGACGGCGACGGGCCCCGTTCCTGGACGACACAGTGGATCCGCGCCGGCGAGGAGCGGGAACAGGCGGGTGACCTGCTCGCCGCCACCACCTTCTACAACCTGGCCCGCTTCCCCTTCGTGGACTCACCGGGCCGGGCCGAGGCGCTGCGGCGCTGCGTGGCGGTGTTCGACCGGTGGCGTCGTACCGTGCCGGGGATCGAACGCCTGGAGCTGCGACTGCCCGGCGGTGTGGTCCGGGCCTGGGCCGCCGGGCTGTCCACGACCGAACGCCGTCCGGTGCTGCTGATGACCGGCGGCATCGTCAGCATCAAGGAGCAGTGGGCGCCGATCCTGCCGGAGCTGGCGCGCTACGGCTTCGCCGCCGTGGTCACCGAGCTACCGGGCGTCGGCGAGAACGAGCTGCGCTACGACCTGGACAGCGCCGCCCTGTTCGGCGTGCTGCTGGACGCCGTGGCCGAACGCGCGGACACCTCCCGGGCGTACGCGTTGGCGCTGAGCTTCAGCGGGCACCTGGCGCTGCGCGCGGCACCGTCCGAACCCCGACTGCGCGGAATCGTCACCGCCGGCGCACCGGTCGCGGCCTTCTTCACCGACAAGGAGTGGCAGGCGGCGGTGCCCCGCGTCACCGTGGACACCCTGGCCCGGCTGACGCAAACCACCCCGGCGACGGTCTTCGACCACGTCCGCAACTGGGCCCTGACCCCGCAGGACCTGGCCGGGGTACGGATCCCGGTGGCGTACGTGGCCAGCGGACGCGACGAGATCATCCCGCCCGCCGACCCGGCCCTGCTCCGCACGCACGTTCGCGACTTCCGGACGATCACCCACGACGACGTGCACGGCTCACCCGCGCACTTCCCGCACACCCGGCTCTGGACCCTCGCCCAGGTACTCGAGATGAGCGGCGCCGACCCACGGCACCGGGCGGCGGTCGACGGCGCGCTCGCCCAGGTCGAGGGAGGACGGGCGTGA",
      "translation": "MSNDVAELKQYVLAHVSAQNASADGVLARIDDDGDGPRSWTTQWIRAGEEREQAGDLLAATTFYNLARFPFVDSPGRAEALRRCVAVFDRWRRTVPGIERLELRLPGGVVRAWAAGLSTTERRPVLLMTGGIVSIKEQWAPILPELARYGFAAVVTELPGVGENELRYDLDSAALFGVLLDAVAERADTSRAYALALSFSGHLALRAAPSEPRLRGIVTAGAPVAAFFTDKEWQAAVPRVTVDTLARLTQTTPATVFDHVRNWALTPQDLAGVRIPVAYVASGRDEIIPPADPALLRTHVRDFRTITHDDVHGSPAHFPHTRLWTLAQVLEMSGADPRHRAAVDGALAQVEGGRA",
      "product": "AbyA5"
     },
     {
      "start": 15054,
      "end": 32399,
      "strand": 1,
      "locus_tag": "abyB1",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyB1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75502.1</span><br>\n Gene: <span class=\"serif\">abyB1</span><br>\n \n Location: 15,054 - 32,399,\n (total: 17346 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: mod_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: hyb_KS<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 300.4; E-value: 3.6e-91)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyB1 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (7..415)</dt>\n   <dd>\n   \n    found active site cysteine: False, scaffold matched GSSS: False<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (510..791)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (866..937)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (956..1378)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (1477..1760)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (1824..1976)</dt>\n   <dd>\n   \n    catalytic triad H,G,P found: False<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (2189..2365)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (2541..2963)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (3061..3344)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (3404..3560)</dt>\n   <dd>\n   \n    catalytic triad H,G,P inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (3802..3980)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (4055..4127)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (4146..4569)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (4661..4926)</dt>\n   <dd>\n   \n    Malonyl-CoA specific<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (4998..5149)</dt>\n   <dd>\n   \n    catalytic triad H,G,P inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (5407..5582)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyB1 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [5:243](score: 268.2, e-value: 7.9e-80)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [250:366](score: 125.1, e-value: 1.5e-36)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [368:475](score: 70.3, e-value: 1.9e-19)<br>\n \n  PF00698.24 (Acyl transferase domain): [509:811](score: 200.6, e-value: 4.8e-59)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [869:935](score: 47.6, e-value: 1.7e-12)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [954:1205](score: 306.6, e-value: 1.5e-91)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [1212:1328](score: 147.5, e-value: 1.7e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [1330:1446](score: 63.6, e-value: 2.3e-17)<br>\n \n  PF00698.24 (Acyl transferase domain): [1476:1775](score: 193.0, e-value: 9.6e-57)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [1824:2071](score: 147.1, e-value: 6.9e-43)<br>\n \n  PF08659.13 (KR domain): [2189:2365](score: 179.4, e-value: 6.6e-53)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [2452:2519](score: 49.3, e-value: 5.1e-13)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [2539:2790](score: 311.5, e-value: 4.8e-93)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [2797:2913](score: 146.6, e-value: 3.2e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [2915:3030](score: 61.1, e-value: 1.4e-16)<br>\n \n  PF00698.24 (Acyl transferase domain): [3060:3359](score: 193.0, e-value: 9.6e-57)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [3404:3663](score: 135.0, e-value: 3.3e-39)<br>\n \n  PF08659.13 (KR domain): [3802:3980](score: 210.2, e-value: 2.3e-62)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [4056:4123](score: 46.0, e-value: 5.3e-12)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [4144:4396](score: 299.5, e-value: 2.2e-89)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [4403:4519](score: 146.6, e-value: 3.2e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [4521:4611](score: 41.8, e-value: 1.4e-10)<br>\n \n  PF00698.24 (Acyl transferase domain): [4659:4926](score: 175.9, e-value: 1.6e-51)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [4998:5252](score: 119.8, e-value: 1.5e-34)<br>\n \n  PF08659.13 (KR domain): [5407:5582](score: 186.6, e-value: 3.9e-55)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [5677:5744](score: 46.9, e-value: 2.8e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyB1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyB1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75502.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCGCCCCCGACGAGCCGGTCGCCGTCGTCGGTCTGGCCTGCCGGCTGCCCGGCGCCGCCGATCCGGAGGCGTTCTGGGCGCTGCTGCGCGACGGGCGGGAGGCGATCACCGACCCGCCCGCGTCCCGACGCGACCCGGACGGGCGCGCCCGCAGGGGCGGCTTCCTGGACGCGGTGGACCTGTTCGACGCCGAGTTCTTCGGCGTCCCGCCCCGCGAGGCGGCGGCCATGGACCCGCAGCAGCGGCTGGTGCTGGAGCTGAGCTGGGAGGCCCTGGAGGACGCCCGGATCCGCCCGGACGCGCTGGCCGGCAGCCGGACCGGGGTGTTCGTTGGCGCCATCTCCGACGACTACGCGACGCTGCTGCGCCGCCGTGGTCCCGACGCCATCGGCCCGCACTCGTTGACCGGCACGAACCGGGGGATCATCGCCAACCGCGTCTCGTACCACCTCGGGCTGCACGGCCCGAGCATCACCGTCGACTCGGCGCAGTCCTCCGCCCTCGTCGCCGTGCACGTGGCCGCCGAGAGCCTGCGCCGCGGCGAGTCGGAACTGGCCCTCGCCGGTGGGGTGAACCTGAACCTCGCGCCGGAGAGCACGCTGGGCGCCGAACGCTTCGGCGCGCTGTCCCCGGACGGCCGCTGCCACACCTTCGACGCGCGGGCCAACGGGTACGTGCGCGGCGAGGGCGGCGGGCTGGTGGTGCTCAAGCCGCTGGACCGGGCGCTCGCCGACGGCGACCGGGTGCACGCGGTCCTGCTCGGCAGCGCGGTCAACAACGACGGTGTCACCGACGGCCTGACCGTGCCCGGCAGCGACGGGCAGCGGGAGGTGATCCGGCTGGCCCACGAGCGGGCCGGCACCACGCCCGGCGAGGTCGACTACGTCGAGCTGCACGGCACCGGCACGGTCGTCGGCGACCCGGTCGAGGCCGCCGCGCTGGGCGCAGAACTGGGCCAGCTGCGCGACACGCCACTGCTGGTGGGCTCCGCCAAGACCAACGTGGGGCACCTGGAAGGCGCGGCGGGCATCGTCGGGTTCGTCAAGGCCGTGCTCTGCGTACGGCACCGGACGCTGCCGCCGAGCCTGAACTTCGCCACCCCGAACCCACGCATCCCACTCAACGAGCTGAACCTGCGGGTGGTGACCGAGAGCCACACCGTGCCGCGGCCCCTGGTCGTCGGGGTCAGTTCCTTCGGCATGGGCGGCACGAACGCCCACGCCGTACTCACCGAGGCTCCGCTGCGGACGGCGCGGAAGCCGGCTCCCGCGGCGCGCCCGCTGACGTGGGTGGTCTCCGGGCACACCCCGCAGGCCCTGCGGGCGCAGGCCGGGCAGCTCACGAGCCTGGCCGCCGACCCGGCCGACGTGGCGTTCTCGCTGGCCACGACCCGCGCGACGCTGCCCTACCGGGCGGCGGTGGTCGGCGAGACGGCGGCCGACCTGCGCGCCGGGATGGCGGCGGTGGCGACCGGCACGCCCCACCCGGGCACGGTGACCGGCTCCCCGGCCGGCACGCTGGCGTTCGTCTTCACCGGGCAGGGCAGCCAGCGGGCCGGCATGGGGCGGGAGTTGGCCGCCCGGTTCCCGGTGTACGCCCAGGCGTTCGCCGAGGTCGCGGCGGCACTCGACCCGCACCTGGGTCGCCCCCTCGACGAGGTGCTCGACGACGCCGACGCCCTCGACCGCACCGAGTTCGCCCAGCCCGCACTGTTCGCCGTGGAGGTGGCGCTGTTCCGGCTGCTCACCCATTGGGGTCTGCGACCGGACGCGGTGGCGGGCCACTCGGTCGGTGAGATCGCCGCCGCGCACGTGGCCGGCGTGCTGGACCTCCCCGACGCGGCCCGCCTGGTGGCGGCTCGGGGCCGGCTCATGCAGGCGTTGCCGACCGGCGGCGCCATGGTCGCCCTGTCGGCCGGCGAGGAGGAGGTACGACCGCTCCTGCGTCCCGGGGCCGACCTGGCGGCGGTGAACGCGGCGGAGTCGGTCGTGGTGGCCGGCGACGACGACGCCGTCTCCGCCATCGAGGAGACCGTGCGCGGCTGGGGGCGGCGGACCAGCCGGCTACGGGTCAGCCACGCCTTCCACTCGGCCCGGATGGACCCGATGCGCGTCTCCTTCGCGCAGGCACTGGCCGACATCGAGTTCGCGCAGCCGACGATCCCCGTGGTGTCCGCGCTGACGGACCCCGACGTGACCGACGCGGAGCACTGGGTACGCCACGTCCGGGACACCGTCCGGTTCGCCGACGCGGTCCGGGACCTGCGCGACCGGGGCGTCCGCACAGTCCTGGAGGTCGGACCGGACGCGGTGCTCACCGCACTGGCGCACGACGTGGCGGAGCTCGCCGCCGTCGCGGTGCTGCGCCGCGACCGCCCCGAGCCGGACACCGCCGTGACGGCGCTGGCCACCGCGTTCACCCGGGGCGCGGCGGTGGACTGGACCGCCCTGCTCGGTGCCCGCCAGGCGGTCGACCTGCCCCGGTACGCCTTCCAGCGCAGCCGCCACTGGCTGGACCAGGACAACCCAGCGATCGCGGCACCGGAGGTCACCCGCGCCCCCGACGGCACGCCCCGCCGCTCGGACGAGGAACTGCTCGACCTGGTGCGTACCGCCGTCGCGGTCGCCCACGGCCGCGTCGGCCCGGCAGCGATCGACCCGGATACCACGTTCCGCGATCTCGGCCTGGACTCGGTCACCAGCGTGGAGTTCCGCGACCGGCTCGCCGCGGCGACCGGCGTCCCCCTCTCCCCCGGCCTGGTCTACGACCATCCCACCCCCCGCGCCGTGGTGGCGCACCTGCGGACGCTGACCGGCGGCGGACCGGCCGACCCGGAGCAGGAGAGCGGCTACCGCGACGAGCCGGTAGCCGTCATCGGCATGGCCTGCCGGTACCCCGGCGGGGTCGGCTCACCCGACGACCTGTGGCAGCTCGTGCGGGACGGGCGGGACGCCACCGGCCCGTTCCCCACCGACCGTGGCTGGGACCTCGACGCGCTCTACGACCCGGATCCCGGCACCCCGGGACGTACCTATGTGCGGCGGGGAGGATTCCTCGACGGCGCGGCCGAGTTCGACGCCGACTTCTTCGGCATCAGCCCGCGCGAGGCCAGCGCCATGGACCCGCAGCAGCGGCTGCTGCTGCACACCGCGTGGGAGGCGCTGGAACACGGCCGACTGAACCCGGAGTCGCTACGCGGCACCCGAACCGGGGTGTTCGTCGGCGTGGTGGACAACGACTACGGGCCGCGACTGCACGAGCCGGTCGAGGGCACGGAGGGTTACCTGCTCACCGGCACCACGGCGAGCGTCGCCTCCGGACGCGTCGCGTACGCCCTGGGGCTGACCGGCCCGGCGGTCACCGTCGACACCGCGTGCTCCTCGTCGCTGGTGGCGCTGCACCTGGCGGCGCAGGCGCTGCGGCAGGGAGAGTGCACCCTGGCGCTGGCCGGCGGGGCGACCGTACTCGCCACGCCGGGCATGTTCCTGGAGTTCAGCCGACAACGCGGCCTCGCACCGGACGGCCGCTGCAAGGCGTTCGCCGCCACGGCCGACGGCACCGCTTGGGCCGAGGGCGCCGGTCTCGTCGTGCTGGAACGCCTCTCCGACGCCCGTCGCAACGGCCACCCGGTCCTCGCCGTGCTGCGCGGCTCGGCGATCAACCAGGACGGCGCCTCCAACGGCCTGACCGCACCCAGCGGCCCCTCGCAGGAGCGGGTCATCCGCCGGGCGCTGGCCGTGGCCGGGTTGGCTCCCTCCGATGTGGACCTCATGGAGGCGCACGGCACGGGCACCGCCCTGGGCGACCCGATCGAGGCCCGGGCCATCCTGGCCACCTACGGGCAGCGGCGCGACACGCCGCTGCACCTCGGCTCGTTGAAGTCGAACATCGGCCACACCCAGGCCGCCGCCGGTATCGCCGGAGTCATCAAAGTCGTCCAGGCGATGCAACACGGCACCCTGCCGGCGACGCTGCACGTGGACGAACCCACCCCGCACGTCGACTGGGCCGAGGGTCAGGTCAGCCTGCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACACGGCGATCCGCAGCCGGCACCGCCGCGGCGTACGTCGACGGGGCACGTGGCCTGGCTGGTCTCGGCCCGGGAGCCGGAGCTGGTGGCCGAGCAGGCCGGCCGGCTACACCGGTTCGTGCGGGACAACCCGGAGCTGGACCCGGCGGACGTCGCGCTGTCGTTGGCCACCACCCGCCCCCTGCTGGAGCATCGCGCGGCCGTGGTGGGCGCCGACCGGGACGAACTGCTGGCCGGACTGGCGGAGCTGGAGTCGGGTCGCCGGCGCGCCGAGGCGATCCGGCCGGGGAAGGTGGCGTTTCTGTTCGCCGGACAAGGCACCCAACGCCTCAACATGGGCCGCCAACTCTACGACACCAACCCCACCTTCGCCCACGCCCTCGACACCGTCACCAACGCCCTCAACCCCCACCTCAACCAACCCCTCCTCGACATCATCTTCGGCACCGACCCCCACCTCCTCAACCGCACCGAAAACGCCCAACCCGCCCTCTTCGCCATCGAAACCGCCCTCTACCACCTCCTCACCCACCACGGCATCCACCCCGACTACCTCCTCGGCCACTCCCTCGGCGAAATCACCGCCGCCCACGCCGCCGGCATCCTCACCCTCACCGACGCCGCCACCCTCGTCACCACCCGCGCCAAACTCATGCAAACCGCCACCCCCGGCGGCGCCATGATCGCCATCGAAGCCACCGAAACCGAAATCCAACCCACCCTCCACCCCACCGTCACCATCGCCGCCATCAACACCCCCACCACCACCGTCATCAGCGGCGACCACCACCACACCCACGCCATCGCCCACCACTGGCGCCAACAAGGCCGACGCACCACCACCCTCACCGTCAGCCACGCCTTCCACTCCCCCCACATGGACCCCATCCTCGACACCTTCCACACCACCACCCAAACCCTCACCCACCACCCACCCCACACCCCCCTCATCACCAACCTCACCGGACAACCCCTCACCAACCCCACACCCGAACACTGGACCCACCACCTCCGCCAACCCGTCCGCTACCACGACGCCACCACCACCCTCACCCACCACGGCGTCACCCACACCATCGAAATCGGCCCCGACACCACCCTCACCACCCTCACCAAAACCAACCACCCCACCCTCACCACCACCCCCACCCTCCGCCCCCACCACAACGAAAACCACACCCTCACCCACACCCTCGCCACCACCCCCACCACCAACTGGGCCAGCCTGTACCCGCACGCCCGCCCGGTCCGGCTGCCCACCACGGCATTCCGGCGCGACCGGTACTGGCTCACCGGCGGCCGGGCCACCCCGGGCGCGGACTCGGGTGTGCGCGAGGTCGATCACCCGCTGCTGGGCGCCGCCGTGACGCTCGCCGACGACAGCACCGTCTACACCGGACGGCTGTCCCGGCGTACCGCCCCCTGGCTGGCCGACCACGTGGTGCTCGGCCGGGCGTTGCTGCCCGGCACCGCCCTGCTGGAGTACGCGCTGTGGGCGGGCCGGGACGTCGGGCTGCCCCGGGTGGCCGAGCTGACGCTGGAGGCCCCGCTGGTGCTGCCCGACGAGGGCGTGACGCAGGTGCGGGTCACCGTCGGCCCGCCGGGTGAGCAGCGGACCGTCGCCGTGCACGCGCGGGCCGACGACGCCGAGCAGTGGACCCGGCACGCCAGCGGCATGCTCACGGCGGCGCCCCCGGCGTCCCCGGTCCCCCCACGCGTGGACGGCCCGCCGGTCGACGTCGACGACCTGTACGAGCGGTTGGCCGGCAAGGGCTACGAGTACGGGCCCGCCTTCCGCCTCGCCACCGCCGCCCGGCACGGCCAGCACGTGGTGGCGCAACTCGCCGCGCCCGCCGGCCCCGACGGATTCGTGCTGCACCCGGCGCAGGTGGACGCCGCTCTGCACCCGATCGTGCTGGACGGCGACGAGACGCTCCTGCCGTTCAGCTGGAGCGGCGTCTCGGTCTTCCGCCGGCCCAGCGGGGCGCTGCACGCGTACTGGACGCCCGAGCGGGCGCTCGTCCTCACCGACGCCGACGGGGTGGTCGCCACCGCCGACAGCCTGCACCTGCGGCCCGCGCGCATGCCGGCCCCCACGGACCTGCACCGGATCCGGTGGGTGCCGGCCGAGGACGCCCGGCGGCAGATCCGCGTCGAACCGGTCGCCGACGCCACGGCCGCGCTCGCGATGCTCCACGAGCGCCTGGACGCCACCGAGCCGACCGCGCTGGTGGTGCCACACCTGGACCGCACCGGTGCGGCCGGGCTCGTCCGGTCGGCGCAGGCCGAACACCCCGGCCGGTTCGTGCTGATCCACGCCGACGACCCGGTCCGGACCGTACCGGACGGCGAACCCGAGGCGGCCTGGCGCGACGGTTCGTGGTGGGTCCCCCGGCTGGCCCGCGTCGCACCCGTCGATCCGGGGCTGCCGCTGTCCGGCACCGTGCTCGTCACCGGCGGGACCGGAGCCCTGGGCGCACTGGTCGCCCGGCACCTCGTCCGCGCCCACCGCGTGCGGGACCTCGTGCTGGTCAGCCGGCGCGGCGCGGACGCACCGGGTGCGGCCGCGCTGGCCGACGAGTTGGCGGGCCACGGCGCGCGGGTCGACCTGCGGGCATGTGACGTCGCCGACCGGGAGGCGTTGGCCTGCCTGCTCGCCGACCTGCCCACCCTCGACGCGGTCGTGCACGCGGCCGGGGTGGTCCGGGACGCGACGGTGTCCGCGCTGACCGTCGAGCAGGTACGCGCGGCCGCGACCAAAGCCGAGTCGGCCTGGCACCTGCACGAGCTGACCCGGGACCGTCCCCTGCGGGCGTTCGTGCTGTTCTCCTCGATCAGTGGGCTGCTGGGCACCGCCGGCCAGGGCGCGTATGCGGCCGCCAACGCCGCGCTGGACGCGCTGGCCGCGCACCGGCACGCCCTCGGCCTACCGGCGCTGTCCCTGGCCTGGGGTCTGTGGGAGGACACCGGGATGGGGGCGGGGCTGTCCGCTGCCGACGTGGCCCGGTGGCGGCGCGACGGGCTGCCGCCGCTGACCGTCGAGCAGGGCGTGGCGCTGTTCGACGCCGCGCTGTCGCACGAGGGTCCGGTCCTCGCACCGGTACGCCTGGACCTGGCGGCGCTGCGCGGCCGTGACGTGCTGCCCGCCGCGCTGCGGGGGCTGGTCACGCGTCGTGCCGTGCCGCCCGCCGGAAGCCGACCGCGTGACGAGGCCGAACTGCGGGAGGTGGTCCGTTCGGTGGTCGCCGAGGTGCTGGGGTACCCGTCGGCCGCCGGGGTGGACTCGGCCCGCCCGTTCCGCGACCTGGGGCTCGACTCGCTCGGCGGGGTGGAGCTGCGCAACCGCCTCGCCGCCGCGACCGGCCTGCCGGTGCCCGCCACGCTGGTGTTCGACCATCCGACGCCGGACGCCGTGGTGGCCCACCTGCTCGGCGCCACGACGAGCGCACAGCCGGCACCGACGCCCACAGTGGCCACCCGCACCGACGAGCCGATCGCGATCGTGGGGATGGCCTGCCGGTATCCCGGTGGTGTCTCCTCGCCGGAGGACCTGTGGCGGCTGGTGGCCGACGGTGTGGACGCGATCGGCGAGTTCCCCACCGACCGGGGCTGGGACCTGGGCCGGCTCTATGACCCCGACCCCGAACACGCCGGCACCTCGTACACCCGCCACGGCGGCTTCCTCTACGACGCGGCCGACTTCGACGCCGGGTTCTTCGCGCTGAGCCCGCGCGAGGCCACCGCCACGGACCCGCAGCAGCGGCTGCTGTTGGAGGTGGCGTGGGAGGCGTTCGAGCGGGCGGGAATCGACCCGACCGCGGTACGCGGCAGTCGGACGGGTGTGTTCGCGGGCGTCATGTACGGCGACTACGGGACGCGGTGGCGTACCGCCCCGGAGGGTTTCGAGGGGCACCTGCTCACCGGCAACACCTCCAGCGTGGTCTCGGGTCGGGTGGCGTACAGCTTCGGGTTGGAGGGTCCGGCGGTCACCGTGGACACCGCCTGCTCGTCCTCTCTGGTGGCCCTGCACCTGGCCGCCCAGTCACTGCGCAGCGGCGAGTGCGATCTGGCGCTGGCCGGCGGCGTCACGGTGATGGCGACGCCGCACACCTTCGTGGAGTTCAGCCGTCAGCGGGGGTTGTCCCCGGACGGGCGCTGCCGGTCGTTCTCGGCGGCGGCGAACGGTACGGGATGGAGTGAGGGTGCGGGCCTGCTGCTCGTCGAACGCCTCTCCGACGCCCGCGCCAACGGCCACCACGTCCTGGCCATCCTCCGCGGCTCCGCCGTCAACCAGGACGGCGCCTCCAACGGACTCACCGCACCCAACGGACCCGCCCAACAACGCGTCATCCGCACCGCCCTCACCAACGCCCACCTCCAACCCACCGACATCGACCTCGTCGAAGCCCACGGCACCGGCACCCGCCTCGGCGACCCCATCGAAGCCCAAGCCCTCATCGCCACCTACGGCCACCACCGCAACACCCCACTACACCTCGGCTCACTGAAATCCAACATCGGCCACACCCAAGCCGCCGCCGGCGTCGCCGGAGTCATCAAAGTCATCCAAGCCATGCAACACGGCACTCTCCCCGCCACACTGCACGTGAACGAACCCACCCCACACGTCAACTGGGCCGACAGCCAGGTCACCCTCCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACACGGCGATCCGCGGCCGGTGCCGCCGGAGGAGACGGATCCGCCCGCGCCGGTGCCGCTGGTGATCTCGGCCCGGTCCGCCGGCGCGCTACGCGACCAGGCCGCCCGGGTGCGCACGGCGTTGGGCTCGGGGCTGCCCGTGCGGGACGTGGCGTACACGCTGGGGGCGGCGCGCGCCCGGCACCCGCACCAGGCGGTGGTCGTGGGCGAGGGTCGGGCGGAGCTGCTGGCCGGACTCGACGCGGTGGCCGACGGCACCGTTCCCGGTGCGGTGGCCACCCCGGGGAAGGTGGCGTTCCTGTTCGCCGGACAAGGCACCCAACGCCTCAACATGGGCCGCCAACTCTACGACACCAACCCCACCTTCGCCCACGCCCTCGACACCGTCACCAACGCCCTCAACCCCCACCTCAACCAACCCCTCCTCGACATCATCTTCGGCACCGACCCCCACCTCCTCAACCGCACCGAAAACGCCCAACCCGCCCTCTTCGCCATCGAAACCGCCCTCTACCACCTCCTCACCCACCACGGCATCCACCCCGACTACCTCCTCGGCCACTCCCTCGGCGAAATCACCGCCGCCCACGCCGCCGGCATCCTCACCCTCACCGACGCCGCCACCCTCGTCACCACCCGCGCCAAACTCATGCAAACCGCCACCCCCGGCGGCGCCATGATCGCCATCGAAGCCACCGAAACCGAAATCCAACCCACCCTCCACCCCACCGTCACCATCGCCGCCATCAACACCCCCACCACCACCGTCATCAGCGGCGACCACCACCACACCCACGCCATCGCCCACCACTGGCGCCAACAAGGCCGACGCACCACCACCCTCACCGTCAGCCACGCCTTCCACTCCCCCCACATGGACCCCATCCTCGACACCTTCCACACCACCACCCAAACCCTCACCCACCACCCACCCCACACCCCCCTCATCACCAACCTCACCGGACAACCCCTCACCAACCCCACACCCGAACACTGGACCCACCACCTCCGCCAACCCGTCCGCTACCACGACGCCACCACCACCCTCACCCACCACGGCGTCACCCACACCATCGAAATCGGCCCCGACACCACCCTCACCACCCTCACCAAAACCAACCACCCCACCCTCACCACCACCCCCACCCTCCGCCCCCACCACAACGAAAACCACACCCTCACCCACACCCTCGCCACCACCCCCACCACCAACTGGAAGACCCTCCTCCCCCACGCCACCGTCATCGACCTGCCCACCTATCCGTTCCAGCGACAGCGGTACTGGCTGGACGGTCCCGCCGCCGACACCGGCCTCGACGGCAGCGGCCATCCCCTGCTGCCCGGCGTCGTCGACCTGGCCGACGGGGGGTTGGTCCTCACCGGCACGGTGAGCGCCGACAGCCACCCCTGGCTGGCGGGGCACCGGATCGGTGGCGCGACGCTGCTGCCCGCCACCGCCGTGGTGGAGGCGGTGGCGCACGCGGCCAGCCGCGTCGGCCTGGACGTCGACGAACTGGTCCTGACGGCCGCCGTGCCGGTCGATGCCCCGGTGCGCCTACGGCTCACCGTCGGGCCGGCGTCCGACGACGACAGCCGCGCTGTGCACCTGCACGGCAACACCGACGACGGCGAGTGGTTGCCGTACGCCACCGGGCGGCTCGCGGTCGTCACGCAGTCGCCCGCCGCCGACCTCGCCACCTGGCCGCCGACCGACGCCGAGCCGGTGGACGTGGTCGACCTCTACGACCGGCTGGCCGAGGGCGGCTACGGCTACCACGGCCTGTTCCAGGGGCTGCGGGCGCTGTGGCGCCGAGGCGACGAGACGTTCGCGGAGGTACGCCCCGACGAGTCGCCCACCGGCGGCTTCGCCCCGCACCCCGCCCTGTGGGACGCGGCGCTGCACCCGCTCGCCTGGGACGCCGCCGAGCGGGGGCAGGTGGAGATCCCGTTCGAGTGGCGGTCCGTTCGCCGGCACGGCCCCGGTGCTCCGGCACTGCGCGTGCGGCTCGCCCGCCGCGACGACGCGGTGAGCGTGGACGTGGCCGACGACGCGGGCCGCCCGATCGCCTCGGCCGGTGCGCTGCGGCTGCGGTCGACCGGCACCGCGCCCACCACCGTCCTCGAACCCGACTGGGAGCCGGTGCCCACCGACGGGGAGTGGACCGGCCGGTACGCGACGGTGGTGGCACCGCGCACCGGCGCGGACGCGAGCGCGGCGTACGCGGCCGTGACCTGGGCACTGGACGCGCTGCGGCAGCACGAGGGCGACGAGCCGCTGGTGGTCCGTACCGTCGACGACCCGGCCGGTGCGGCCGTCCGTGGCCTGGTGCGCACGGCGCAGACCGAGCAGCCGGGCCGCTTCGTGCTGTTCACCGGTTCCGGTGACCCGGAGCCGGCGCTGGTCCGCGCCGCGCTGGCCAGCGGCGAACCGGAGGTGGCGCTGCGCGACGGGACGCTGATGGCACCCCGGCTGTCGCGGATCCCCGTCGCGCCCGGTCCGCTGCCCTTCGCGTCCGGGTCGACGGTGCTGGTGACCGGCGGCACCGGCGCTCTCGGCGCGCTGGTCGCCCGGCATCTGGTCGTCCGGCACGGGGTACGGCGCCTGCTGCTGACCAGCCGGCGTGGCCCGGCCGCCGACGGCGCGGCCGAGCTGGTGGACGAGCTGACCGCGGCGGGCGCCGAGGTCGAGGTGGTGGCGTGCGACGTGGCGGATCGTCCGGCGGTGGCGGCGCTGTTGGCCAGCATCCCCGAGGAGCACCCGCTCACCGCCGTCATCCACACCGCCGGCGTGCTGGACGACGGCGCGCTCACCTCGCTCACCGAGGAGCGCCTGGCCCGGGTGCTGCGGCCCAAGGCGGAGGCGGCCTGGCACCTGCACGAGTTCACCCGGGACCGGCCCCTCACCGCCTTCGTGCTCTTCTCCTCGATCACCGGCATCACCGGCACGGCGGGACAGGCCAACTACGCCGCCGCGAACGCCTACCTGGACGCGCTGGCCCGGCACCGCCGCAACCTCGGCCTGCCCGGCGTCTCCCTGGCCTGGGGGCTGTGGGGGGCCACCGGCATGGCGTCGGGTCTCGGCGCGGCCGACCTCGACCGGCTGGCCCGCAGCGGGATCACCCCGCTGTCACCGCAGGAGGGCCTGGACCTCTTCGACGCCTGCCTGGTCGCGGACCGACCGGTCCTGGCACCGGCCCGGGTCGACCTGTCCACAACTCGCCGGCAGCGTCGCCGCGCGGCGTCCGCCGCCGCCACGGTCACCAGCCGGGAGGGCCTGCGGGAGCTGGTCCGCGCCCAGGTGGCCGCGGTGCTCGGGCACACCGACGCCACCGAGGTGTCCACCGACGTCGCGTTCACCGGGCTTGGCCTGGACTCCCTCACGGCGGTCGAGCTGCGCAACCGGATCGCCGAGCGTACCGGGCTGCGCCTGTCGAGCACGGTGGTCTTCGACCATCCCTCGGTGGACGCGCTCACCGACCACCTGGTCGCGGAACTGGCCGGCGCCCGTCCGGTGGAGACGCCGCAGCCCGTTACGCAGCCGGCCGACGAGCCGATCGCGATCGTGGGGATGGCCTGCCGGTATCCCGGTGGTGTCTCCTCGCCGGAGGACCTGTGGCGGCTGGTGGCCGACGGTGTGGACGCGATCGGCGAGTTCCCCACCGACCGGGGCTGGGGCGAGATCCACGACCCGGACCCGGACCGGCCGGGACACAGCTACACCCGGCACGGGGGCTTCCTCTATGCGGCGGGCGACTTCGACGCGGAGCTGTTCGGCATGAGCCCGCGCGAGGCGCTGACCACCGACCCGCAGCAACGGCTGCTGCTGGAGGTGGCGTGGGAGGCGTTCGAGCGGGCGGGGCTGCCACCGGGATCGCTGCGGGGCAGCCGGACCGGCGTGTTCACCGGCGTGATGTACAACGACTACGGCGCGCGGCTGCACCAGGCCGGCACGCCCGCCCCGGGCTACGAGGGCTACCTGGTCAGTGGCAGCGCGGGCAGCGTCGCCTCCGGTCGGGTGGCGTACAGCTTCGGGTTGGAGGGCCCGGCGGTCACCGTGGACACCGCCTGCTCGTCCTCCCTGGTGGCCCTGCACCTGGCCGCCCAGTCACTGCGCAGCGGCGAATGCGATCTGGCGCTGGCCGGCGGCGTCACAGTCATGGCCAGCCCGGCGACCTTCGTGGAGTTCAGCCGACAACGCGGCCTCGCACCCGACGGCCGGTGCAAACCATTCGCAGCCGCAGCCGACGGCACCGGATGGAGTGAGGGTGCGGGCCTGCTGCTCGTCGAACGCCTCTCCGACGCCCGCGCCAACGGCCACCACGTCCTGGCCATCCTCCGCGGCTCCGCCGTCAACCAGGACGGCGCCTCCAACGGACTCACCGCACCCAACGGACCCGCCCAACAACGCGTCATCCGCACCGCCCTCACCAACGCCCACCTCCAACCCACCGACATCGACCTCGTCGAAGCCCACGGCACCGGCACCCGCCTCGGCGACCCCATCGAAGCCCAAGCCCTCATCGCCACCTACGGCCACCACCGCAACACCCCACTACACCTCGGCTCACTGAAATCCAACATCGGCCACACCCAAGCCGCCGCCGGCGTCGCCGGAGTCATCAAAGTCATCCAAGCCATGCAACACGGCACTCTCCCCGCCACACTGCACGTGAACGAACCCACCCCACACGTCAACTGGGCCGACAGCCAGGTCACCCTCCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACACGGCGACGCCGTCGACACCGGGACCGGGACCGGGACCGTTGCACCGGGCACCGCCGTGGTGCCGTGGCTGCTGTCCGGGACCAGCCGGCAGGCGCTCACCGCGTACGCGCGGCTGCTCGGGGAGGTCGACGCCGCGCCCGTGGACATCGCCGCGACGCTGGCGCTGGGCCGCAGCCCGCTCGCCCTGCGGGCGTCCGTGGTCGGCCGGGACCGCCCGGAGTTTCCCACCGCGCGGCTGCAGCCGGTACAGCCGGTGGACGGGCCCACGGCGTTCGCGTTCACCGGCCAGGGCAGCCAGCGCGCCGGAATGGGGCTGGGACTGGCCGCCCGGTTCCCTCAGTTCGCCGACGCGCTCGCGTCCGTGGCAGAAGCCCTCGACCCGCACCTGCCGTCGCCGCTGCTCGACGTGCTCGCCGACGGCGACCTGCTGGAACGCACCGAGTACGCCCAACCGGCCATCTTCGCCGTGGAGGTGGCGCTGTTCCGGCTGCTGGCCCACTACGGAGTCACCCCGCACGTGCTGCTCGGGCACTCCGTCGGCGAGCTGGCCGCCGCGCACGTCGCCGGGGTGCTCGACCTACCCGACGCCGCCACGCTGGTCGCCGCGCGGGGACGCCTGATGGGAGGACTGGTTCCGGGTGGGGCCATGGCCGCCGTCCGGGCAGGCGAGGACGAGGTACTGGCGCTGCTGGTGCCCGGTGCGGAGATCGCCGCCGTCAACGCCGACGACGCGGTCGTCGTGTCCGGTGACGCGGAGGCCGTCGCAGCGGTCACCCAGGCCCTGCGCGACGCGGGCCGACGGGTCACCCCGTTACGGGTCAGCCACGCCTTCCACTCCGCCCGGATGGACCCGGTGCTGGAGGAGTTCCGGGCGGTGGCGGCCACGCTGCGGTTCTCCGAGCCCACCATCCCGCTGATCTCCCTGCTGCCCGGTTCCCCCACCGACCCCGGGTACTGGGTGCGGCACCTGCGCGAGGCGGTCCGCTTCGGCGACGGCGTACGGTCGCTGGCCGAGTGGGGCGTACGGCGCGTCCTGGAGGTGGGTCCGGACGCCGCGCTGACCCCGGTGACCGGGCCGACGGGAATCGCCACGCTGCGGCGCGACCACGACGAGGAGAGCGCCTTCGTCACGGCGCTGGCCGCGCTGCACGACACGGGCGCGACCGTGGACTGGGCGACCTTCTTCGGGGAGCTGGGCGCTCGGCGGGTGCCGCTACCCACCTACCCCTTCCAACGCCGCCGGTACTGGCTGACGCCCACCGCACCCCGCACCACCGGCGGGAGCGGTCATCCGCTGCTCGACGCGGCGGTGGAGCTGCCCGAGGGTGCCGTGCTGTTCACCGGCCGGGTGGCCGCCGAGGACGCCGACTGGCTGGCCGACCACGTGGTGCTGGGCCAGACCGTGGTCTCCGGCGCCACACTGCTGAGCCTGGTCCTGCATGCCGCGGCCGCGGCGGGACGACCCACGGTGCGGCGGCTGACGCTGCACGCGCCGCTGGTGCTGCCCGATGACGGCGGCGCGGCCGACCTGCGGGTCGGTGTCGACGAGCAGGGGCAGGTGACGGTGTACGCCCGGCCGGCCGGCGGCGGGTGGACCCGGCACGCCTCCGGCACGCTGGACACCGTCGAGCAGCCCGCCGAGGCGCTCGGGTCGTGGCCGCCGGCCGGTGCCGAGCCGCTCGACGTGGACTACACGCGACTGGCCGACGCGGGTTACGCGTACGGCCCCGGCTGCCGCCGGGTGCGCGCCGCGTGGCGCCTCGGCGACGACCTCTACGCCGAGGTGGGCCCGGTCGACGCCGACGGGCACGCCGCGCCGCATCCGGCGCTGCTCGACGCGGCGCTGCACCCGCTGGCCCTGGACCTGCTCGACGACGAGCAGACCCGGGTACCGCACGTCTGGTCGTCGGTGACGGTGCACGCGACCGGGGCGACGACGCTGCGGGCCCGGATCCGCCGGACCGGCACCGACCGTGTCGCCCTCACCCTCACCGACACCGACGACCGGCCGGTGGCCACGGCGGACCTCACCGTCCGGGCCGTTGCGCGCGGCCTGCCCGACCTGTACGCCGTCCGACTCACCCCGGTGCGGCCGGCCACCGGTGGGACGGTGTGGCCGAGCGTCGGCCGGGATGTCGGGCTGCCCCGCTACGCCGAGCTGTCCACCAGCACCGACGACATCGTCGAACGGGCGCACGACCGGGTCACCGAGGTGGCGGAGCTGCTTCGCCGCTGGCTGGCGCAGGGACCGCCGGAAGCCCGGCTGGTGGTCGCCACCGACCAGGTCACCGACCCGGCCGACGGGGTGCTGTGGGGCCTCGTACGGGCGGCCCAGACCGAGCATCCCGACCGGTTCGTGCTGCTCGACAGCGACGGCGACCCCCGGTCGCGGACCCTGGTCCCGGGGGCGCTGGCCACCGGCGAGCCGCAGCTCGTGGTGCGCGACGGGCGGATCACCGTGCCGAGACTCGCCCGCACCGCCGCCGCGCCGCAGCCACCCCGGCTCGATCCGGACGGGACGGTCCTGGTCACCGGTGCGGGTGGAGCCCTCGGCTCACTGACGGCCCGGCGCCTGGTCACCCACCACGGCGTACGGCGGCTCCTGCTGCTCGGCCGGCGCGGCGGGATGCAACCGCTGGCCGCCGAGCTGACCGCCCTGGGCGCCACGGTGCGGGTCGCGGCCTGCGACGCGGCCAACCGGGCGGCGCTGGCCCGGGTGCTCGACACCGTCCCCGCCGCGCACCCGCTCACCGCCGTGGTGCACGCGGCCGGGGTGGTGTCCGACGGGCCGCTGGCCACGTTGACGCCGCAGCGCTTCGCCGAGGTGCTGCGCCCGAAGGTGGACGCGGCGTGGCACCTGCATGAGCTGACCTGCGAGCAGGACCTGGCGGCGTTCGTGCTGTTCTCCTCCCTCGCCGGGCTGGTGGGCAACGCCGGCCAGGCCAATTACGCGGCCGCGAACACCGGCCTGGACGCCCTCGCCGCGTATCGCCGGGCCGCCGGGTTGCCGGCCGTGAGCCTGGCCTGGGGCCTGTGGGACGCGCCGGGCATGGGCGCCGCGCTGGACGAGACGCAGCGTGCCCGCATCGCGCGGACCGGTGTGGCGCCCCTGCCGGTCGAGCGGGGCCTGGCCCTCTTCGACGCCTGCCTCGGTGCCCGGGAGGCACTGTTGGTGCCCGCCGCGCTCCAGCCGGAGCGGGCGACGCGGGTCGCACCGGTGCTGGCCGGGCTGGCCCCGGCGACCACGGCGACCACGCCGCAGCAGGACTGGCCCCGACGGCTCGCCGGGCGGGGCGCCGCCGAGCAGCACCGGCTGCTGCTGGAGCTGGTCCGCAGCACGATCGTCGAGGTCCTCGGCCACTCCTCCGTCGCAGCCGTGGCACCCGACCGGGGGTTGATGGACCTCGGCTTCGACTCCCTCACCGCCGTCGAGCTGGCCGGGCGCCTCGGTGCCGACACCGGCGTCCGCACCCCGTCGACGGTGGTGTTCGACCATCCGACACCCACCGCGCTCGCCCACTACCTGCGACACGAGCTGGTGGGCGAGGAGGCGGCCGACGACGAGAAACCGCACGAGTTGGACGAGGTGTCCGACGAGGACCTGTTCGCCCTGATCGACACGGAGCTGGGAGAGCGATGA",
      "translation": "MSAPDEPVAVVGLACRLPGAADPEAFWALLRDGREAITDPPASRRDPDGRARRGGFLDAVDLFDAEFFGVPPREAAAMDPQQRLVLELSWEALEDARIRPDALAGSRTGVFVGAISDDYATLLRRRGPDAIGPHSLTGTNRGIIANRVSYHLGLHGPSITVDSAQSSALVAVHVAAESLRRGESELALAGGVNLNLAPESTLGAERFGALSPDGRCHTFDARANGYVRGEGGGLVVLKPLDRALADGDRVHAVLLGSAVNNDGVTDGLTVPGSDGQREVIRLAHERAGTTPGEVDYVELHGTGTVVGDPVEAAALGAELGQLRDTPLLVGSAKTNVGHLEGAAGIVGFVKAVLCVRHRTLPPSLNFATPNPRIPLNELNLRVVTESHTVPRPLVVGVSSFGMGGTNAHAVLTEAPLRTARKPAPAARPLTWVVSGHTPQALRAQAGQLTSLAADPADVAFSLATTRATLPYRAAVVGETAADLRAGMAAVATGTPHPGTVTGSPAGTLAFVFTGQGSQRAGMGRELAARFPVYAQAFAEVAAALDPHLGRPLDEVLDDADALDRTEFAQPALFAVEVALFRLLTHWGLRPDAVAGHSVGEIAAAHVAGVLDLPDAARLVAARGRLMQALPTGGAMVALSAGEEEVRPLLRPGADLAAVNAAESVVVAGDDDAVSAIEETVRGWGRRTSRLRVSHAFHSARMDPMRVSFAQALADIEFAQPTIPVVSALTDPDVTDAEHWVRHVRDTVRFADAVRDLRDRGVRTVLEVGPDAVLTALAHDVAELAAVAVLRRDRPEPDTAVTALATAFTRGAAVDWTALLGARQAVDLPRYAFQRSRHWLDQDNPAIAAPEVTRAPDGTPRRSDEELLDLVRTAVAVAHGRVGPAAIDPDTTFRDLGLDSVTSVEFRDRLAAATGVPLSPGLVYDHPTPRAVVAHLRTLTGGGPADPEQESGYRDEPVAVIGMACRYPGGVGSPDDLWQLVRDGRDATGPFPTDRGWDLDALYDPDPGTPGRTYVRRGGFLDGAAEFDADFFGISPREASAMDPQQRLLLHTAWEALEHGRLNPESLRGTRTGVFVGVVDNDYGPRLHEPVEGTEGYLLTGTTASVASGRVAYALGLTGPAVTVDTACSSSLVALHLAAQALRQGECTLALAGGATVLATPGMFLEFSRQRGLAPDGRCKAFAATADGTAWAEGAGLVVLERLSDARRNGHPVLAVLRGSAINQDGASNGLTAPSGPSQERVIRRALAVAGLAPSDVDLMEAHGTGTALGDPIEARAILATYGQRRDTPLHLGSLKSNIGHTQAAAGIAGVIKVVQAMQHGTLPATLHVDEPTPHVDWAEGQVSLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDPQPAPPRRTSTGHVAWLVSAREPELVAEQAGRLHRFVRDNPELDPADVALSLATTRPLLEHRAAVVGADRDELLAGLAELESGRRRAEAIRPGKVAFLFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPTLRPHHNENHTLTHTLATTPTTNWASLYPHARPVRLPTTAFRRDRYWLTGGRATPGADSGVREVDHPLLGAAVTLADDSTVYTGRLSRRTAPWLADHVVLGRALLPGTALLEYALWAGRDVGLPRVAELTLEAPLVLPDEGVTQVRVTVGPPGEQRTVAVHARADDAEQWTRHASGMLTAAPPASPVPPRVDGPPVDVDDLYERLAGKGYEYGPAFRLATAARHGQHVVAQLAAPAGPDGFVLHPAQVDAALHPIVLDGDETLLPFSWSGVSVFRRPSGALHAYWTPERALVLTDADGVVATADSLHLRPARMPAPTDLHRIRWVPAEDARRQIRVEPVADATAALAMLHERLDATEPTALVVPHLDRTGAAGLVRSAQAEHPGRFVLIHADDPVRTVPDGEPEAAWRDGSWWVPRLARVAPVDPGLPLSGTVLVTGGTGALGALVARHLVRAHRVRDLVLVSRRGADAPGAAALADELAGHGARVDLRACDVADREALACLLADLPTLDAVVHAAGVVRDATVSALTVEQVRAAATKAESAWHLHELTRDRPLRAFVLFSSISGLLGTAGQGAYAAANAALDALAAHRHALGLPALSLAWGLWEDTGMGAGLSAADVARWRRDGLPPLTVEQGVALFDAALSHEGPVLAPVRLDLAALRGRDVLPAALRGLVTRRAVPPAGSRPRDEAELREVVRSVVAEVLGYPSAAGVDSARPFRDLGLDSLGGVELRNRLAAATGLPVPATLVFDHPTPDAVVAHLLGATTSAQPAPTPTVATRTDEPIAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWDLGRLYDPDPEHAGTSYTRHGGFLYDAADFDAGFFALSPREATATDPQQRLLLEVAWEAFERAGIDPTAVRGSRTGVFAGVMYGDYGTRWRTAPEGFEGHLLTGNTSSVVSGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMATPHTFVEFSRQRGLSPDGRCRSFSAAANGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDPRPVPPEETDPPAPVPLVISARSAGALRDQAARVRTALGSGLPVRDVAYTLGAARARHPHQAVVVGEGRAELLAGLDAVADGTVPGAVATPGKVAFLFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPTLRPHHNENHTLTHTLATTPTTNWKTLLPHATVIDLPTYPFQRQRYWLDGPAADTGLDGSGHPLLPGVVDLADGGLVLTGTVSADSHPWLAGHRIGGATLLPATAVVEAVAHAASRVGLDVDELVLTAAVPVDAPVRLRLTVGPASDDDSRAVHLHGNTDDGEWLPYATGRLAVVTQSPAADLATWPPTDAEPVDVVDLYDRLAEGGYGYHGLFQGLRALWRRGDETFAEVRPDESPTGGFAPHPALWDAALHPLAWDAAERGQVEIPFEWRSVRRHGPGAPALRVRLARRDDAVSVDVADDAGRPIASAGALRLRSTGTAPTTVLEPDWEPVPTDGEWTGRYATVVAPRTGADASAAYAAVTWALDALRQHEGDEPLVVRTVDDPAGAAVRGLVRTAQTEQPGRFVLFTGSGDPEPALVRAALASGEPEVALRDGTLMAPRLSRIPVAPGPLPFASGSTVLVTGGTGALGALVARHLVVRHGVRRLLLTSRRGPAADGAAELVDELTAAGAEVEVVACDVADRPAVAALLASIPEEHPLTAVIHTAGVLDDGALTSLTEERLARVLRPKAEAAWHLHEFTRDRPLTAFVLFSSITGITGTAGQANYAAANAYLDALARHRRNLGLPGVSLAWGLWGATGMASGLGAADLDRLARSGITPLSPQEGLDLFDACLVADRPVLAPARVDLSTTRRQRRRAASAAATVTSREGLRELVRAQVAAVLGHTDATEVSTDVAFTGLGLDSLTAVELRNRIAERTGLRLSSTVVFDHPSVDALTDHLVAELAGARPVETPQPVTQPADEPIAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWGEIHDPDPDRPGHSYTRHGGFLYAAGDFDAELFGMSPREALTTDPQQRLLLEVAWEAFERAGLPPGSLRGSRTGVFTGVMYNDYGARLHQAGTPAPGYEGYLVSGSAGSVASGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMASPATFVEFSRQRGLAPDGRCKPFAAAADGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDAVDTGTGTGTVAPGTAVVPWLLSGTSRQALTAYARLLGEVDAAPVDIAATLALGRSPLALRASVVGRDRPEFPTARLQPVQPVDGPTAFAFTGQGSQRAGMGLGLAARFPQFADALASVAEALDPHLPSPLLDVLADGDLLERTEYAQPAIFAVEVALFRLLAHYGVTPHVLLGHSVGELAAAHVAGVLDLPDAATLVAARGRLMGGLVPGGAMAAVRAGEDEVLALLVPGAEIAAVNADDAVVVSGDAEAVAAVTQALRDAGRRVTPLRVSHAFHSARMDPVLEEFRAVAATLRFSEPTIPLISLLPGSPTDPGYWVRHLREAVRFGDGVRSLAEWGVRRVLEVGPDAALTPVTGPTGIATLRRDHDEESAFVTALAALHDTGATVDWATFFGELGARRVPLPTYPFQRRRYWLTPTAPRTTGGSGHPLLDAAVELPEGAVLFTGRVAAEDADWLADHVVLGQTVVSGATLLSLVLHAAAAAGRPTVRRLTLHAPLVLPDDGGAADLRVGVDEQGQVTVYARPAGGGWTRHASGTLDTVEQPAEALGSWPPAGAEPLDVDYTRLADAGYAYGPGCRRVRAAWRLGDDLYAEVGPVDADGHAAPHPALLDAALHPLALDLLDDEQTRVPHVWSSVTVHATGATTLRARIRRTGTDRVALTLTDTDDRPVATADLTVRAVARGLPDLYAVRLTPVRPATGGTVWPSVGRDVGLPRYAELSTSTDDIVERAHDRVTEVAELLRRWLAQGPPEARLVVATDQVTDPADGVLWGLVRAAQTEHPDRFVLLDSDGDPRSRTLVPGALATGEPQLVVRDGRITVPRLARTAAAPQPPRLDPDGTVLVTGAGGALGSLTARRLVTHHGVRRLLLLGRRGGMQPLAAELTALGATVRVAACDAANRAALARVLDTVPAAHPLTAVVHAAGVVSDGPLATLTPQRFAEVLRPKVDAAWHLHELTCEQDLAAFVLFSSLAGLVGNAGQANYAAANTGLDALAAYRRAAGLPAVSLAWGLWDAPGMGAALDETQRARIARTGVAPLPVERGLALFDACLGAREALLVPAALQPERATRVAPVLAGLAPATTATTPQQDWPRRLAGRGAAEQHRLLLELVRSTIVEVLGHSSVAAVAPDRGLMDLGFDSLTAVELAGRLGADTGVRTPSTVVFDHPTPTALAHYLRHELVGEEAADDEKPHELDEVSDEDLFALIDTELGER",
      "product": "type 1 polyketide synthase"
     },
     {
      "start": 32476,
      "end": 43413,
      "strand": 1,
      "locus_tag": "abyB2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyB2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75503.1</span><br>\n Gene: <span class=\"serif\">abyB2</span><br>\n \n Location: 32,476 - 43,413,\n (total: 10938 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: mod_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_N<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1021:malonyl CoA-acyl carrier protein transacylase (Score: 208.7; E-value: 2.9e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyB2 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (45..467)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (573..845)</dt>\n   <dd>\n   \n    Methylmalonyl-CoA specific<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (920..1073)</dt>\n   <dd>\n   \n    catalytic triad H,G,P inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (1304..1467)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (1642..2063)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (2160..2445)</dt>\n   <dd>\n   \n    Methylmalonyl-CoA specific<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (2512..2666)</dt>\n   <dd>\n   \n    catalytic triad H,G,P found: False<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_ER</strong> (2938..3228)</dt>\n   <dd>\n   \n    ER domain putatively catalyzing 2R-configuration product formation<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (3238..3417)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (3522..3594)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyB2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08990.14 (Erythronolide synthase docking domain): [11:39](score: 28.8, e-value: 7.8e-07)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [43:294](score: 306.1, e-value: 2.1e-91)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [301:417](score: 139.5, e-value: 5.2e-41)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [421:532](score: 58.1, e-value: 1.2e-15)<br>\n \n  PF00698.24 (Acyl transferase domain): [571:847](score: 295.4, e-value: 6.4e-88)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [920:1171](score: 51.8, e-value: 7.3e-14)<br>\n \n  PF08659.13 (KR domain): [1304:1468](score: 73.9, e-value: 1.6e-20)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [1552:1620](score: 51.6, e-value: 9.7e-14)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [1640:1890](score: 291.1, e-value: 8.3e-87)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [1897:2013](score: 144.8, e-value: 1.2e-42)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [2015:2114](score: 51.5, e-value: 1.3e-13)<br>\n \n  PF00698.24 (Acyl transferase domain): [2158:2466](score: 282.9, e-value: 4.3e-84)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [2512:2772](score: 179.7, e-value: 8.1e-53)<br>\n \n  PF13602.9 (Zinc-binding dehydrogenase): [3107:3229](score: 53.2, e-value: 6.5e-14)<br>\n \n  PF08659.13 (KR domain): [3238:3417](score: 202.4, e-value: 5.6e-60)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [3523:3590](score: 47.5, e-value: 1.8e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyB2 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08990.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016740' target='_blank'>GO:0016740</a>: transferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyB2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyB2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75503.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCACACCGAGCAAGGGGACGGACAGCATTGCCGACCAGCAGAAGCTGCGCGAGTACCTCCGGCGGGTCACCGACGACCTGCTGCGGACCCGCCGGCGCCTGACCGAGGTGGAGTCGGCCGACCGGGAGCCGGTGGCCATCGTCTCGATGGCCTGCCGCTTCCCCGGCGGGGTGGCTTCGCCGGAGGACCTGTGGCAGCTGGTGGCGTCCGGCACCGACGCGATCAGCGGGTTCCCCGATGACCGGGGCTGGCCACTGGACGAGCTGTACGACCCGGACCCGGAGCACCCGGGCACGTCCACCACCCGGCAGGGGGGTTTCCTGCACGACGCCGCCGACTTCGACCCGGAGTTCTTCGGGATCAGCCCCCGTGAGGCGTTGACCATCGACCCGCAGCAGCGGCTGCTGTTGGAGACCGCCTGGGAGGCGGTGGAGCGGGCCGGGATCGCACCGGACTCGCTGCGTGGCAGCCGGACCGGCGTGTTCGCCGGGGTCATGTACGGCGACTACGGTGCCCGCCTGCGCCCGATCCCGGCGGGCTTCGAGGGGTACATGGGCACCGGCAGCGCGGGCAGCGTGGCCACCGGCCGGATCGCGTACACCCTCGGCCTGGAGGGGCCGGCGGTGAGCGTCGACACGGCGTGCTCGTCGTCGCTGGTGGCGCTGCACCTCGCGGCGCAGGCGCTGCGGCGCGGCGAGTGCGACCTGGCGCTGGCCGGCGGCGTGACGGTCATCGCCACGCCGGAGCTGTTCGTGGAGTTCAGCCGCCAGCGGGGGTTGTCGCCGGACGGGCGGTGCAAGGCATTCGCGGCCTCGGCCGACGGCACGGGCTGGGCCGAGGGCGTCGGCCTGGTGCTTGTCGAACGGCTCGCCGACGCCCGCCGCAACGGTCACCCGGTGCTCGCGCTGCTGCGCGGCAGCGCCGTCAACCAGGACGGCCGCAGCAGCCAGCTCTCCGCGCCCAACGGCCCGGCGCAGCGGCGGGTCATCCGGGCGGCGCTGGCCAGTGCCGGCCTGGAGCCCGCCGAGGTCGACCTGGTGGAGGCACACGGCACCGGCACCCGGCTCGGTGACCCGATCGAGGCCCAGGCACTGCTGGCCGAGTACGGGCAGGGGCGCACGGAGCCGCTCTGGCTGGGCTCGCTCAAGTCGAACATCGGGCACACCCAGGCGGCGGCCGGCGTCGGCGGGGTGATCAAGGTGGTGCAGGCCATGCGGCACGGGCTCCTGCCCGCCACCCTGCACGCCGACGAGGCCACCCCGCACGTCGACTGGAGCGTCGGTGACGTCCGTCTGCTCACCGAGGCCCGCGACTGGCCGGCGCGGGAGCGGCCCCGGCGGGCGGCCGTGTCCTCCTTCGGCATCAGCGGCACCAACGCGCACGTGATCCTGGAGGAGGGCGACCCCGACGGGGTCGCCGACGCGCCACCGGACGACGTGCTCGCGCGCAAGCCGGTGCCGGTGGTGCTGTCGGCGCACACCGCGTCGGCTCTCGGGCCGCAGGCGGCCCGGCTCCGCGCGCACCTCGACGCCCACCCCGACCTCACGGTGGCCGACGTCGCGCACTCGCTGGCCACCACCCGTACCCCGCTCGCCGAGCGGGCCGTCCTCGTTGCCGCCGACCTCGACGAGCTGCGCACCGCCCTGGACGCCGTCGCGGACGGCGACGAGCCGCCGGTGCGCGGCACGGCCGGGCACCCCGGCGGGGTCGTGTTCGTCTTCCCCGGCCAGGGCGCCCAGTGGGCGGGCATGGCCCTGGACCTGTACCGCGAGGACGAGGTGTTCCGCGCGGCGCTGGACGACTGCGAGCGGGCCCTGGCCCCGCACGTCGACTGGTCGCTGCGGGCCGTGCTGGCCGACGCCGACGCCCTCGGACGCGTCGACGTCGTCCAGCCCGCCCTGTGGGCGGTGATGGTGTCACTGGCGGCGCTGTGGCAGCACCACGGCGTGACCCCCGACGCGGTCGTCGGCCACTCCCAGGGCGAGATCGCCGCCGCCTGTGTCGCGGGTGCCCTGTCGCTGGAGCAGGCCGCGGCCGTGGTGGCGCTGCGGGCGCGGGCCATCACCGCCGTCGCGGGTCGCGGTGCCATGGCGTCGGTTTCTGTGCCCGCACAGCAGATCACCGAGCGGTGGGGCGACCGGATCACCGTGGCCGTGACGAACTCCGCCGACGCGACGGTCGTCGCCGGTGAACCAGAGGCCGTCGCCGAGGTGGTCGCCGCGTACGACGCCGAGGGAGTCCGGGCCCGGGTCCTGCCGGTGGACTACGCCTCCCACTCGGCGCACGTGGAGCCCGTGCGGGAGCCGATCCTCGACGCGCTGCGCGACCTCACCCCGACCGAGGCCCGGGTCCCGTTCCACTCCACCGTCACCGGTGCGGAGTTCGACACCCGGGGCCTGACCGCCGACTACTGGTACACCAACCTGCGCAGCACCGTCCGGTTCGACCAGGCGGTGACCCGGCTACGCGAACAGGGCCACCGGATCTTCGTCGAGATCAGCCCGCATCCGGTACTGACGCCGGTGCTCGGCGAGGGCGCGTTCGGCACGCTGCGCCGCGACGAGGGCGACCGTCGACGTTTCATCACGTCACTGGGTGCGGTGCATGCCGTGGGCGTACCGGTGGACTGGTCCGCCGCGATCGGCCCGGCGCGCCGTGTGCCCCTGCCGACGTACGCCTTCCAGCGGTCCCGCTACTGGCTGGACGCGCCCGCGCGGACCGGCGACGCATCCGGGGTGGGGGTGGGCCCGACCGACCACCCGCTGCTCGGCGGTGCCGTCGACGTGGCCGGCGACGGCACGCTGGTGCTCACCGGGCGGCTGGTGCCCGGAGCGGACCGGGCCGCCGCCGAGCTGCGGGTCGGCGGCGTACCCGTGCTGTCCGGCACCGCGCTGCTCGACCTCGCCCTACGGGCGGGCGAGCTGGCCGGTCTGGGTGCGGTCGGCGAGTTCAGCGTGGAGACGCCTTTGGTGCTGTCCGCCACCGCCGGTTGGTTGCAGGTCGTGGTGGCGCCGGCCGGCGCCGACGGCGACCGGGAGATCGGCGTGTACGCCCGGCCCGACCACGAGGCGCCCTGGACCCGGCACGGTCACGGTGTGCTCGTCCCGGCCACGGCGCAGGACCTCCCGCCGCACCGGCCGGTGCCGGGCGCACCGCTCGCCCCGGACGAGGCGGTGGAGCGGCTCGCCGCGGCCGGTGTGGAACTGGCCTCGGCGCCCACGGCGGTGTCCGGCGACGCCGACGGGTACGTCGCCGACCTCGCGTCGCCGCCGGAGGGACGCTTCACGCTGCACCCGGCGCTGCTCGACGCCGCCCTGCTGCCCGCCTTCGGCCGGGGCGACGCCCGGCTGCCGAGCCGGTGGCGCGGGGTACGGCTGCCGCAGCCGGACGGCCAGCCGACCCGCGCGTCGGTACGCCGCCGCGACGGCGACTCGTGGGCCGTGTCGCTGACCGACTCCGCCGGTGCGCCGGTGGTCGAGATCGCCGAGGTGGTGCTGGGTCCGGTGCCGGTGGTGTCGGCCGCCGGGCACCACGACCCCCTGTTCACGCTGGAGTGGGCCCCCGTGGCCCGGCCCCGGGGTGCCGCCGCAACCGAGCCGGTGCCGCACGAGCTGCCCGGCGACGCCGGTCCCGCCGCGCTGGCCGTGCTTCGCGGCGGGCTGGCCGAGCCGGACGGGCCGCGCCAGGTGGTGGTGGCCCGCGGGGCGGGCACGGTGACGGGTCTGGTCCGGTGCGCGCAACTGGAGGAGCCCGGGCGGGTCGGCCTCGTCGAGTGGGACGGGCGCGACGCCGACGCGCTGCGCGACGCCGTGGCCGCCGGGCTGCCGCAGGTGGCGGTCCATGGTGCGGAGCTGCGTACGCCCCGGCTCGCGCCGCTCACCGCGCCGGGCCGCCCCGTCGAGTTGGACGGCACGGCCCTGATCGTCGGGGAGGCCGGAGCGCTGCGCGACGCCGTGCTGCGCACGCTGGCGCGCCACGGCGTGGACCGGCTGGTGGTGGTGGACGTGGACGGCACGGCACCAGCCGACGTGGGCGTACCCACCGAGGTGCTCACCGGTGATCCCACCGACCGTGCCGTGCTCGCCGAGGCGGTCCACCGCGCCGCGAACCTGCGCACGGTCGTGCACGCCGTGCAGCCCACGGCCGACGCGCCGCTGGCCGCGCTGAGCCCCGAGGACCTCACGGCCCTGGTCGAGCGGATCGTGGCGCCGGCCCGGCACCTGCACGAACTGACCGCGCACCTGCCGCTGACCCGGTTCGTGCTGTCCGGCTCGGCGGCGGGTGTGCTGGGCGGCATCGGGCAGGCCGCCGTGGCGGCGGCCACCACCGGGTTGGGCGCGCTCGCGGCCCGCCGTCGCGCCGACGGGCTGCCCGCCCAGGTCGTCGCCTGGGGTCCGTCGGCCGGCACCCGCCGGCTCGGGCTGGTGTCCCTCGACGACGCCCGCCTGGCCGCACTGTTCGCGCAGGTCTTGGCGCACGACGTCGACGTGGTGGCCGCGCCCCTGGTCCGGGCGGGGCTGCGGGGGCAGGCGCGGGCGGGCACGCTGCCCGTGGCGCTGCGGGCCCTCGTGCCGGCGCTGCCCGGCGGTGCCACCGGCCTGGCGGCCCGGCTGGCCGGCGCCTCCCCCGCCGAGGGGCGCCGTCTGCTGCTGGACACCATCCGTACCCATGTCGCCGGGGTGCTGGGCCACGACGACGCCAGCGGCATCGACGAGCGCCGCGCCTTCAAGGACCTCGGGTTCGACTCGCTCACCGCCATCGAGCTGCGCAACCGTCTCAACACCGCGCTGGGGCGGACCCTGCCCGCGACGCTGATCTTCGACCACCCCAGTCCCGGCGCTCTGGCCGAACACCTGCGCGACGACCTGCTCGGCCGTGCCGCCGTGGCCGCTGCCCCGGTGGCGGTCGCCAGCGACGAACCGATCGCCATCGTCGCGATGGGCTGCCGCTATCCGGGCGGCATCGCCGACCCCGAGGCGTTGTGGCAGGCGGTGGTGTCGGAACTCGACGCGGTGGGACCGTTCCCGACCGACCGGGGCTGGCCGGCGGACCTGTACGACCCCGACCCGGAGGCCACCGGCCGCACGTACGCGCGTGAGGGCGGCTTCCTCTACGACGCCGCCGGGTTCGACCCGGAATTCTTCGGCATCAGCCCCCGCGAGGCCACCGGCATGGACCCGCAGCAGCGGCTGCTGCTGCAGACCGGCTGGGAGGTGTTCGAGCGGGCCGGGATCGACCCCACGGCGCTGCGCGGCAGCCGTACCGGGGTCTTCGCGGGGGTCGTCTACACCGACTACGGCTCCCGGGCCGACCCGATCCCCGCCGACCTGGAGGGATACCTCGGCATCGGCAGCGCCGGCAGCATCGCCTCCGGCCGCATCGCCTACACCCTCGGCCTGGAGGGCCCGGCGGTCACCGTGGACACCGCGTGCTCCTCGTCGCTGGTGGCGCTGCACCTGGCCGTGCAGTCGCTGCGCCGCGGCGAGTGCGACCTGGCCCTGGCGGGCGGTGCGACGGTGCTGTCCAACCCGGACATCTTCGTCGGCTTCTCGCGCCAGCGGGGCCTGTCCCCGGACAGCCGTTGCAAGGCGTTCGCCGCCGCCGCCGACGGCACCGCCTTCGCCGAGGGTGTCGGCCTGCTGCTGGTGCAGCGGCTCGCCGACGCGCGGCGCGATGGTCGGCCGGTGCTGGCCGTCATCCGGGGCACCGCCATCAACCAGGACGGCGCGTCCAACGGGCTCACCGCACCCAACGGGCCGTCGCAGCAGCGGGTCATCCTGGGTGCGCTGGCCGACGCGGGGCTGCGCCCGTCCGACGTCGACGTGGTGGAGGCGCACGGCACCGGCACCACCCTGGGCGACCCGATCGAGGCGCAGGCGATCATCGCCACCTACGGGCAGGGCCGCGACGAGCCGCTGCTGCTCGGCTCGCTGAAGTCGAACATCGGCCACACCCAGGCCGCAGCCGGTGTCGGCGGCGTGATCAAGATGGTCGCCGCCATGCGACACGGGCTGGTGCCCCGGACCCTGCACGTCGACGAGCCGACCCCGCACGTGGACTGGTCGGCGGGTGCGGTCCGGCTGGTCACCGAGGCGCGGCCCTGGCCGGAGTCGAACCGGCCGCGCCGCGCCGGGGTGTCCTCGTTCGGCATGAGCGGCACGAACGCCCACGTCGTCGTCGAGCAGGGCGACCCGCTCGAGGTGCCGCCGGTGCGCGCCGGCCGCCTCGTACCGGTGCCGGTGTCCGCCGCCAACCCGGCGGCGCTGCGCCGACAGGCCGCCCGTCTGCTCCCCGCCGTGGCCGACCGGCATCCCGCCGACGTGGCCCGTACCCTCGCGGCCCGCACCTCCCTCGCCACCCGGGCCGTCGTGCTCGCGGACGACGCCGACGAGCTGGCCGAGGGCCTACGGGCGCTGGACGACGCGACGTTCACCGGTCCGGTGGGCGACGCCGACGAGCCGGGCAAGGTGGTCTTCGTCTTCCCCGGGCAGGGCGGGCAGTGGACCGGCATGGCTCTGGACCTGTACCGCGACGAGCCCACCTTCCGCGAGTCCCTGGACGCCTGCGCCGCCGCGCTGGCACCGCACGTGGACTGGGCGTTGCTCGACGTGCTCGCCGACGAGGAGGCCCTGCGGCGGGTGGACGTCGTGCAGCCCGCGCTCTGGGCGGTGATGGTGTCGGTGGCCCGGCTCTGGCAGCACCACGGCGTCACGCCCGACGCGGTGGTCGGCCACTCCCAGGGTGAGATCGCCGCCGCCCACGTGGCCGGCGCGCTCAGCCTGGCCGACGCCGCCGCCGTGGTGGCGCTGCGGGCCAGGGCGATCACGGCGATCGCCGGGACCGGCGGCATGGCCTCGGTCGCACTCGGTGTCGGAGAGGTCACCCGGCGCTGGGGCCACACGGTGGCCGTCGCCGCGACCAACGGTCCGGACACCGCGGTGATCGCCGGCGACCCGGGCGTGCTGGACCACATCGCCGCCACGTGTGCCGCCGAGGAGGTCCGGGTGAAGATCCTGCCGGTCGACTACGCCTCACACTCCGCGCACGTGGAGGCACTGCGTGAGGAACTGCTGGCTGCGTTGGAGACCGTGCAACCCCGGGCCGCCGAGATCGCGTTCTGTTCCACGGTCACCGCCGAGGCGCTGGACACCACCACGCTCACGGCCGACTACTGGTACACGAACCTGCGCAGCACCGTGCGCTACGACGAGACGGTCCGCCGGCTGCACGCCGAGGGGCACCGCACCTTTCTGGAGATGAGCCCTCACCCGGTGCTGACCACCGTCACCGAGCAGGTCACCGGGGCGGTCGCGCTGGGCACGCTGCGCCGGGACGAGGGCGACCGCCGCCGCTTCCTCACCGCGCTGGCCGAGGCGTACGTGACCGGCGTGGCGGTGGACTGGCGTCCGGCCGTGGGCGCCGACGCACGGCTGGTGGACCTGCCCACGTATGCGTTCGCCAGCGACCGCTACTGGCTCGACGCGACGACGCGGCCGGTCGACGCCACCGGGCTCGGGCTGGCTGCCACCGCGCACCCACTGCTCGGCGCGGCCGTCGACCTGGCCGACGACGAGGGCGTGCTGCTCACCGGCCGACTGTCGCTCGACAGCCACCCGTGGCTGGCCGACCACACGGTGGCGGGCGTGCCGTTGCTGCCGGGCGCGGCGTTCGTCGAGCTGTGCGCCCAGGCCGCGGAGGCCGCCGGCGCTGCCGGGGTGGCGGAGCTGACCCTGGAGACGCCCTGCGTGCTGCCCGAGCGCGGGGGCGTGGACGTGCAGGTCCAGGTCCGCGACGGCGGGCTGCGCGTGTACTCGCGCAGCGTCGGCGACGCCTGGGTACGCAACGCCTCCGGCGTCCTGCTTCCCACCGAGCCGCCCGCGCCGGCCGGTTGGGGCGCCTGGCCGCCACCCGGGGCGCAGGCCGTCGACGTCGAGGGCCTGTACCCGCAGCTGGCCGCGTCCGGCTACGGGTACGGCCCGGCCTTCCGGGGGCTGCGGGCCGCCTGGCGGCGCGGCGAGGAGGTCTTCGCCGAGGTCCGGCTGCCCGAGGGCCTCGAACCGGAGGGGTACGGTCTGCACCCGGCGCTGCTCGACGCGGCCCTGCACGCGCTGGCGTTCGGGGACTTCCTCGGCGCGGGTGTCCGCCTGCCGTTCGCCTTCACCGGCGTACGGGTGTTCGCCACCGGCGCCGACATCCTGCGCGTACGGCTCAGCCCGCGGGGCGAGGACACCGTGGCGGTGGCGCTGGCGGACTCCACCGGGGCACCGGTCGCCGAGATCGAGTCGCTGGTGCTGCGCGCGGCACCGTCCCTGGAGGCCACCGCGCCGCACGCCCCCGACGTGCTGGTCCTCGACTGGACCCCACTGGCCCTGCCGGACACCCCGGTGACCGAACCGGACCTGCTGGTGGTGGCACCGTCGGATGCGCACGACCCGGTGGCGGCCACCGGCCGGCTGGTGACGTCCACGATCGCCGAACTCGCCGGCCGGCTGGCCGACGACCGGGGCGCGGTCGTCGTGACCCGCGACGCGGTGGCCGTGCGCCCCGGCGATCCTGCCGCCGACCTGGCGCACGCCGCCCTGTGGGGCCTGCTGCGCAGCGCGCAGACGGAGAACCCGGACCGGTTCACGCTCGTCGACACCGACGGGCGGCCCGAGTCGGCAGCCGTGGTGGCGGCGGCCGTGGCGACCGGAGAGCCGCAGATCGCCGTCCGCGAGGGACGCGGGTACGTGCCGCGCCTGGCCCGCGCCGCCGCCAACCGGGGCCTCGTCCCGCCGCCGGGCGCCTGGCGGCTGGAGGCGGCCGGCACCACTGTGGACGAGCTGCGCCTGACGGAGGTGACCGAAGCGCCGCTGCCGGCCGGGCACGTCCGGGTCGCGGTACGCGCCTGCGGGCTGAACTTCCGCGACGTGCTGGCCACCCTGGGCGTCGTACCCCGCGACGCCCCGCTGGGCGCGGAGGGTGCGGGCGTGGTGGTCGAGGTCGGCGTCGGTGTCACCGGCTTCGCCCCCGGTGACCGGGTGTACGGCTTCCTCCAGGGCGCCATCGGCCCGCGCGCCGTCGTGGACGCGCGGCTGCTCGCCCACCTGCCCGCCGGATGGTCCTTCGCGCAGGCGGCCACAGCGCCGGCGGTCTGCACCACCGCCTACTACGCGCTGGTCACCCTGGCGGACCTGCGCCCCGGGGAGCGGGTGCTGATCCACTCCGCCGCCGGCGGGGTCGGTCTGGCCGCCGGGCACCTCGCCCGGCACCTGGGCGCCGAGGTGTTCGGCACGGCGAGCCCGGCCAAGTGGGCGGCGCTGGACCTGGACGAGGCGCACCTGGCGTCGTCGCGGAACACCGACTTCGCCGACCGGTTCGGCCCGGTCGACGTGGTGCTCAACTCGCTGACCGGGGAGTTCATCGACGCGTCCCTGCGCCTGCTGGGTCCGGGCGGTCGGTTCGTGGAGATGGGTGTGGCGGACCTGCGGTCGTCCGAGCAGATGCCCACCGGCGTCGACTACCACGCGTTCGAGCTGCTCGACCTGGCCCCCGCGCGGGTGGGCGAGCTGTTCGCCGAGGTGGTCCGGCTGATCGACCAGGGGGTCTTTCCGCCGCTGCCGGTCACCGCCTGGGACGTCCGGCGGGCGCCGGAGGCGCTGCGCTACTTCAGCCAGGCCCGGCAGATCGGCAAGATCGCCCTGACCGCCCCGGTCCCGCTCGACCCGAACGGCACGGTCCTGGTCACCGGCGGCACGGGCAGCCTCGGCGGCCTCGTCGCCCGGCACCTGGCGCGCGCCCACGGGGTACGTCACCTGCTGCTGGTCAGCCGGTCCGGTCCGGCCGCGCCCGGCGCGACGGAGCTGGTCGGTGAGTTGACCTCCCTGGACGTACGGGTGGACGTGGTGGCGGCCGACCTGGCCGACCGGGCGGCGGTCGCCGGGGTGTTGGCGGCGGTGCCGCCGGAGCACCCGCTCACCGCCGTCGTGCACACTGCCGGTGTCCTGGACGACGGCGTCCTGGAGTCGTTGACCCCGCAGAAGATCGCCCGGGTGCTCGCACCGAAGGTAGACGCCGCGTGGCACCTGCACGAGCTGACCCGGGACCTGGACCTGTCGGCGTTCCTGCTGTTCTCCTCGGCGTCGGGTCTGCTGGGCGGTGCGGGGCAGGCCAACTACGCGGCGGCCAATGCGTTCCTGGACGCGCTGGCCACGGCGCGGCGCCGCGCCGGCCTGCCCGCCGTGTCGCTGGCCTGGGGCATGTGGGCGCGGGCCACCGGCCTGACCGCCCACCTGGGCGGCACGGACCTGGGCCGCATCGAACGCGGCGGCCTGCTGCCGATGACCGACGAGCAGGGCCTGGCTTTGTTCGACGCCACCTGGACGGCCGACCGTCCGGTGCTGGTGCCGGCGCCGCTGCGCCTGGACCGGGGCCGCACCGGATCCGGTGTGGTGCCGGCCGTGCTGCGCGCGCTGGTGCGGCCGGTGCGCCGGGTGGCCCGCTCGGCGGGGACGGCGTCGCCGGACTCGCTGCGCGAGCGGCTGCTGCCGCTGTCCCCGACGGAGCGCACGGCCCTGCTGGTGGACCTGGTCCGTACACAGGTCGCGGCGGTCCTGGGCCACACCGACACCGACGCCGTGGTGGTGGACCGGGCGTTCAAGGACAGCGGTTTCGACTCGTTGACGGCGGTGGAGCTGCGCAACCGGGTGTCCCGCGCCACCGGGCTGCGGCTGCCACCCACCGTGGTGTTCGACCGCCCCACGCCGGCGGAGTTGGCCGCGCACCTTCTCGACCAGCTCGTGCCGCCTGCCGACGGGCCGGCCGGCGCGGCGACGCCCGCCCGCAAGACCCGAAAGCAACTCGACTCGGCCACGGTCGAGGAGATCTTCGACTTGATCGACTCCCAGCTCGGCCGGGGGTCTCGCAGCGACTATCAGGAGGTCGACGCCGGGTGA",
      "translation": "MTTPSKGTDSIADQQKLREYLRRVTDDLLRTRRRLTEVESADREPVAIVSMACRFPGGVASPEDLWQLVASGTDAISGFPDDRGWPLDELYDPDPEHPGTSTTRQGGFLHDAADFDPEFFGISPREALTIDPQQRLLLETAWEAVERAGIAPDSLRGSRTGVFAGVMYGDYGARLRPIPAGFEGYMGTGSAGSVATGRIAYTLGLEGPAVSVDTACSSSLVALHLAAQALRRGECDLALAGGVTVIATPELFVEFSRQRGLSPDGRCKAFAASADGTGWAEGVGLVLVERLADARRNGHPVLALLRGSAVNQDGRSSQLSAPNGPAQRRVIRAALASAGLEPAEVDLVEAHGTGTRLGDPIEAQALLAEYGQGRTEPLWLGSLKSNIGHTQAAAGVGGVIKVVQAMRHGLLPATLHADEATPHVDWSVGDVRLLTEARDWPARERPRRAAVSSFGISGTNAHVILEEGDPDGVADAPPDDVLARKPVPVVLSAHTASALGPQAARLRAHLDAHPDLTVADVAHSLATTRTPLAERAVLVAADLDELRTALDAVADGDEPPVRGTAGHPGGVVFVFPGQGAQWAGMALDLYREDEVFRAALDDCERALAPHVDWSLRAVLADADALGRVDVVQPALWAVMVSLAALWQHHGVTPDAVVGHSQGEIAAACVAGALSLEQAAAVVALRARAITAVAGRGAMASVSVPAQQITERWGDRITVAVTNSADATVVAGEPEAVAEVVAAYDAEGVRARVLPVDYASHSAHVEPVREPILDALRDLTPTEARVPFHSTVTGAEFDTRGLTADYWYTNLRSTVRFDQAVTRLREQGHRIFVEISPHPVLTPVLGEGAFGTLRRDEGDRRRFITSLGAVHAVGVPVDWSAAIGPARRVPLPTYAFQRSRYWLDAPARTGDASGVGVGPTDHPLLGGAVDVAGDGTLVLTGRLVPGADRAAAELRVGGVPVLSGTALLDLALRAGELAGLGAVGEFSVETPLVLSATAGWLQVVVAPAGADGDREIGVYARPDHEAPWTRHGHGVLVPATAQDLPPHRPVPGAPLAPDEAVERLAAAGVELASAPTAVSGDADGYVADLASPPEGRFTLHPALLDAALLPAFGRGDARLPSRWRGVRLPQPDGQPTRASVRRRDGDSWAVSLTDSAGAPVVEIAEVVLGPVPVVSAAGHHDPLFTLEWAPVARPRGAAATEPVPHELPGDAGPAALAVLRGGLAEPDGPRQVVVARGAGTVTGLVRCAQLEEPGRVGLVEWDGRDADALRDAVAAGLPQVAVHGAELRTPRLAPLTAPGRPVELDGTALIVGEAGALRDAVLRTLARHGVDRLVVVDVDGTAPADVGVPTEVLTGDPTDRAVLAEAVHRAANLRTVVHAVQPTADAPLAALSPEDLTALVERIVAPARHLHELTAHLPLTRFVLSGSAAGVLGGIGQAAVAAATTGLGALAARRRADGLPAQVVAWGPSAGTRRLGLVSLDDARLAALFAQVLAHDVDVVAAPLVRAGLRGQARAGTLPVALRALVPALPGGATGLAARLAGASPAEGRRLLLDTIRTHVAGVLGHDDASGIDERRAFKDLGFDSLTAIELRNRLNTALGRTLPATLIFDHPSPGALAEHLRDDLLGRAAVAAAPVAVASDEPIAIVAMGCRYPGGIADPEALWQAVVSELDAVGPFPTDRGWPADLYDPDPEATGRTYAREGGFLYDAAGFDPEFFGISPREATGMDPQQRLLLQTGWEVFERAGIDPTALRGSRTGVFAGVVYTDYGSRADPIPADLEGYLGIGSAGSIASGRIAYTLGLEGPAVTVDTACSSSLVALHLAVQSLRRGECDLALAGGATVLSNPDIFVGFSRQRGLSPDSRCKAFAAAADGTAFAEGVGLLLVQRLADARRDGRPVLAVIRGTAINQDGASNGLTAPNGPSQQRVILGALADAGLRPSDVDVVEAHGTGTTLGDPIEAQAIIATYGQGRDEPLLLGSLKSNIGHTQAAAGVGGVIKMVAAMRHGLVPRTLHVDEPTPHVDWSAGAVRLVTEARPWPESNRPRRAGVSSFGMSGTNAHVVVEQGDPLEVPPVRAGRLVPVPVSAANPAALRRQAARLLPAVADRHPADVARTLAARTSLATRAVVLADDADELAEGLRALDDATFTGPVGDADEPGKVVFVFPGQGGQWTGMALDLYRDEPTFRESLDACAAALAPHVDWALLDVLADEEALRRVDVVQPALWAVMVSVARLWQHHGVTPDAVVGHSQGEIAAAHVAGALSLADAAAVVALRARAITAIAGTGGMASVALGVGEVTRRWGHTVAVAATNGPDTAVIAGDPGVLDHIAATCAAEEVRVKILPVDYASHSAHVEALREELLAALETVQPRAAEIAFCSTVTAEALDTTTLTADYWYTNLRSTVRYDETVRRLHAEGHRTFLEMSPHPVLTTVTEQVTGAVALGTLRRDEGDRRRFLTALAEAYVTGVAVDWRPAVGADARLVDLPTYAFASDRYWLDATTRPVDATGLGLAATAHPLLGAAVDLADDEGVLLTGRLSLDSHPWLADHTVAGVPLLPGAAFVELCAQAAEAAGAAGVAELTLETPCVLPERGGVDVQVQVRDGGLRVYSRSVGDAWVRNASGVLLPTEPPAPAGWGAWPPPGAQAVDVEGLYPQLAASGYGYGPAFRGLRAAWRRGEEVFAEVRLPEGLEPEGYGLHPALLDAALHALAFGDFLGAGVRLPFAFTGVRVFATGADILRVRLSPRGEDTVAVALADSTGAPVAEIESLVLRAAPSLEATAPHAPDVLVLDWTPLALPDTPVTEPDLLVVAPSDAHDPVAATGRLVTSTIAELAGRLADDRGAVVVTRDAVAVRPGDPAADLAHAALWGLLRSAQTENPDRFTLVDTDGRPESAAVVAAAVATGEPQIAVREGRGYVPRLARAAANRGLVPPPGAWRLEAAGTTVDELRLTEVTEAPLPAGHVRVAVRACGLNFRDVLATLGVVPRDAPLGAEGAGVVVEVGVGVTGFAPGDRVYGFLQGAIGPRAVVDARLLAHLPAGWSFAQAATAPAVCTTAYYALVTLADLRPGERVLIHSAAGGVGLAAGHLARHLGAEVFGTASPAKWAALDLDEAHLASSRNTDFADRFGPVDVVLNSLTGEFIDASLRLLGPGGRFVEMGVADLRSSEQMPTGVDYHAFELLDLAPARVGELFAEVVRLIDQGVFPPLPVTAWDVRRAPEALRYFSQARQIGKIALTAPVPLDPNGTVLVTGGTGSLGGLVARHLARAHGVRHLLLVSRSGPAAPGATELVGELTSLDVRVDVVAADLADRAAVAGVLAAVPPEHPLTAVVHTAGVLDDGVLESLTPQKIARVLAPKVDAAWHLHELTRDLDLSAFLLFSSASGLLGGAGQANYAAANAFLDALATARRRAGLPAVSLAWGMWARATGLTAHLGGTDLGRIERGGLLPMTDEQGLALFDATWTADRPVLVPAPLRLDRGRTGSGVVPAVLRALVRPVRRVARSAGTASPDSLRERLLPLSPTERTALLVDLVRTQVAAVLGHTDTDAVVVDRAFKDSGFDSLTAVELRNRVSRATGLRLPPTVVFDRPTPAELAAHLLDQLVPPADGPAGAATPARKTRKQLDSATVEEIFDLIDSQLGRGSRSDYQEVDAG",
      "product": "type 1 polyketide synthase"
     },
     {
      "start": 43410,
      "end": 46388,
      "strand": 1,
      "locus_tag": "abyB3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyB3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75504.1</span><br>\n Gene: <span class=\"serif\">abyB3</span><br>\n \n Location: 43,410 - 46,388,\n (total: 2979 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: mod_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 270.7; E-value: 3.7e-82)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyB3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (36..451)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (550..838)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (915..986)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyB3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08990.14 (Erythronolide synthase docking domain): [5:32](score: 31.3, e-value: 1.2e-07)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [34:278](score: 272.3, e-value: 4.3e-81)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [285:401](score: 147.6, e-value: 1.6e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [403:513](score: 58.0, e-value: 1.2e-15)<br>\n \n  PF00698.24 (Acyl transferase domain): [549:858](score: 178.8, e-value: 2e-52)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [917:984](score: 48.2, e-value: 1.1e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyB3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08990.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016740' target='_blank'>GO:0016740</a>: transferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyB3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyB3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75504.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCGAGACACGCGAGGAGAAGCTCGTCGAGTACCTGAAGTGGGTCACCGGTGAGCTGCAGGAGACCAAGGCCCAACTCGCCAGGGCGAGGGCGGAACGCGAACCGATCGCGATCGTCTCGGCCGCCTGCCGGCTGCCCGGCGACGTCCACTCCCCCGAGGACCTGTGGCGCGTCGTGGTCGACGGTGTCGACGCCATCGGCGACGTCCCCACCGACCGGGGTTGGGCGGTGCATGAGGTGTACGCCGACGCGCCCGCGCACCGCCCGCTGGGCGGGTTCCTGTCCGACGCGGCCGGCTTCGACGCCGCGTTCTTCGGTATCGGCCCGCACGAGGCCACCGCCATGGACCCGCAGCACCGGCTGCTGCTGGAGTCGTCGTGGGAGGCGGTGGAGCGCGCCGGCATCGACCCGACCACCCTGCGCGGCAGCGCCACCGGGGTGTACGCGGGCCTGGTGTCGCAGAACTACGCCGCGTACGGCACCCCACCGGAGCTCAACGGCCACCTCATGACCGGCACGGCCACCAGCGTGGCGTCCGGCCGGATCGCCTATCTGCTGGGGCTGCGCGGCCCGGCGGTCACCCTGGACACCGCCTGCTCGTCGTCGCTGGTGGCCCTGCACCTGGCGGCGCAGGCGCTGCGCCGGGGCGAGTGCGATCTCGCGCTGGCCGGCGGGGCCACGGTCATGGCCACCCCGGCGTTGCTGGCGGAGTTCGTCACCCAGGGCGGGCTCTCGCCCGACGCCCGGTGCAAGGCGTTCGCGGCGGCGGCCGACGGAACGGGTTTCGCCGAGGGGGTCGGGGTGCTCGTGCTGGAACGCCTGGCCGACGCCCGGCGCCACCACCGGCGCGTGCTCGCGGTGCTGCGCGGCTCGGCGGTGAACCAGGACGGCGCGTCCAACGGGCTGACCGCGCCGAGCGGCCCCGCGCAGGAGGAGGTGATCCGCGCCGCGCTGGCCGACGCGGGCCTGCGACCGTCCGACGTGGACCATGTGGAGGCGCACGGCACCGGCACCCGGTTGGGCGACCCCATCGAGGCGGCGGCCCTGCTCGCCACCTACGGTCAGGACCGCGCCGAGCCGCTGTGGCTGGGTTCGGTGAAGTCCAACATCGGGCACACCCAGACCGCCGCCGGTGTGGCCGGGGTGATCAAGGTGATCGAAGCCCTGCGCCACGAGCGCCTGCCGCGCACCCTGCACGTCGACGAGCCCACTCCGCACGTCGACTGGGCGGCGGGGAAGGTACGGCTGCTCACCGAGGAGCAGCCGTGGCCGCGCGGGAAACGCCGCCGGGTGGCGGGGGTGTCGTCGTTCGGCATCAGCGGCACCAACGCCCACGTGCTCATCGAGGAGGGCGACCCGGAGCCGCCGCCCACGCCGCCCACGCCCTCCGCCCACCCGGTCGCCTGGCTGCTCGGCGCCAAGACCGACAGCGCGCTGCGCGCGCAGGCCGCGCGCCTACGCCAACGGTTCGCCGTCGCGTCGCACGACCCGCTGGACGTGGCGGTCGCGCTGGCCACCACCCGCACCGCGTTCGACCGGCGGGCGGCCGTGGTGGCGGCCGACCACGACGGCCTGCTGCGCGGTCTCGACGCGCTGGCCGCCGGGGAGACGACACCGGGACGGGCGGTACGGGGACCCACCGCCTTCCTCTTCTCCGGGCAGGGCAGCCAGCGCGTCGGCATGGGTACCGAGCTGCGGCGGGTCTTCCCTGCCTTCCGCGACGCCTGGCGGGAGGTCGCCGACGAGGTCGACCGGCACCTGGACCAGCCCCTGGACCGCGTGCTGGCCGACGAGGACCTGCTGCTGCGCACCGAGTACGCCCAGCCCGCGTTGTTCACCCTGGAGGTGGCCCTGGTCCGCTTGCTGGGCGGCTGGGGTCTGCGGCCGGACCTGCTGCTCGGTCACTCGCTCGGCGAACTGGTCGCGGCGCACGTCGCGGGGGTCCTCGACCTGCCCGACGCCGTCGCGCTGGTCGCGGCGCGGGGTGCGGCCATGCAGGCGGCCCCGGCCGAGGGCGCCATGGTTGCGATCCGGGCCGCCGCCGACGAGGTACGGGCCAGCCTCGCCGGCCGCGAGCACGAGGTGTCCGTCGCGGCGGTGAACGGCCCCCGCTCGACAGTCGTCTCCGGCGATGCCGGTGCGGTGCAGGAGGTCGCGGCCCACTGGGCGGCCACCGGGCACCGGACGTCGCGATTGCGGGTCAGCCACGCCTTCCACAGCCCGCACCTGGACGGGGTGCTGGACGGGTTCCGCGCGGTCGCCGCCGGCGTACGCCACCACCCGCCGAGCATCCCGGTCGTGTCGAACCTGACCGGCACGGTCGTCGAGGCGTTCACCGCCGAGCACTGGGTGCGGCACGTGCGCCAGGAGGTCCGCTTCGCCGCCGGCGTGTCCGCGCTCACCTCGGCGGGCGTACGCCGTTTCGTGGAGGTCGGCCCGGACGCGGTGCTGGCTGCCCTGGCCGGCGAGAACGCCCCTGGGACACCCGTCGTGGCGACCCTGCGCCGCGACGAGTCCGAGGCGTTGACCGTCGTCCGGGCGCTGGCGGCGAGCCACGTCACCGGCGCTCGGGTGGACTGGCGGGCGTTCCACGACGAGCGGACGGCGGCGGTGCCGCTGCCCACGTACCCCTTCGAGCACCGCCGCTACTGGGTGTCCCCGCCGACCGGCCCGGCGCCCACCGCCCCGCCGCCGGTGGCCGACGAGCCGCCGCGGGAGTCGACGCCACACGAGGAGCGGTTGCTCGACCTGGTCCGCACGCACGCGGCGGCGGTGCTGGGCCACGACACGCCGGAATCGGTGGGCCCGGACGACAACTTCGTGGAGATCGGGCTGTCGTCGTTCACCGCGCTGGAGGTGCGCAACCGGCTCTGCGAGGGCACCGGCCTGGAACTGTCGCCGCTGGCGCTGTTCGAACACCCCACCCCTGCCGCGCTGGCGGAGCACCTGCGGGCCGTACGGGCCGCGCGGACGTGA",
      "translation": "MSETREEKLVEYLKWVTGELQETKAQLARARAEREPIAIVSAACRLPGDVHSPEDLWRVVVDGVDAIGDVPTDRGWAVHEVYADAPAHRPLGGFLSDAAGFDAAFFGIGPHEATAMDPQHRLLLESSWEAVERAGIDPTTLRGSATGVYAGLVSQNYAAYGTPPELNGHLMTGTATSVASGRIAYLLGLRGPAVTLDTACSSSLVALHLAAQALRRGECDLALAGGATVMATPALLAEFVTQGGLSPDARCKAFAAAADGTGFAEGVGVLVLERLADARRHHRRVLAVLRGSAVNQDGASNGLTAPSGPAQEEVIRAALADAGLRPSDVDHVEAHGTGTRLGDPIEAAALLATYGQDRAEPLWLGSVKSNIGHTQTAAGVAGVIKVIEALRHERLPRTLHVDEPTPHVDWAAGKVRLLTEEQPWPRGKRRRVAGVSSFGISGTNAHVLIEEGDPEPPPTPPTPSAHPVAWLLGAKTDSALRAQAARLRQRFAVASHDPLDVAVALATTRTAFDRRAAVVAADHDGLLRGLDALAAGETTPGRAVRGPTAFLFSGQGSQRVGMGTELRRVFPAFRDAWREVADEVDRHLDQPLDRVLADEDLLLRTEYAQPALFTLEVALVRLLGGWGLRPDLLLGHSLGELVAAHVAGVLDLPDAVALVAARGAAMQAAPAEGAMVAIRAAADEVRASLAGREHEVSVAAVNGPRSTVVSGDAGAVQEVAAHWAATGHRTSRLRVSHAFHSPHLDGVLDGFRAVAAGVRHHPPSIPVVSNLTGTVVEAFTAEHWVRHVRQEVRFAAGVSALTSAGVRRFVEVGPDAVLAALAGENAPGTPVVATLRRDESEALTVVRALAASHVTGARVDWRAFHDERTAAVPLPTYPFEHRRYWVSPPTGPAPTAPPPVADEPPRESTPHEERLLDLVRTHAAAVLGHDTPESVGPDDNFVEIGLSSFTALEVRNRLCEGTGLELSPLALFEHPTPAALAEHLRAVRAART",
      "product": "type 1 polyketide synthase"
     },
     {
      "start": 46457,
      "end": 47149,
      "strand": -1,
      "locus_tag": "abyC",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyC</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75505.1</span><br>\n Gene: <span class=\"serif\">abyC</span><br>\n \n Location: 46,457 - 47,149,\n (total: 693 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1057:TetR family transcriptional regulator (Score: 94.7; E-value: 1.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyC collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00440.26 (Bacterial regulatory proteins, tetR family): [19:65](score: 54.3, e-value: 9.3e-15)<br>\n \n  PF14246.9 (AefR-like transcriptional repressor, C-terminal domain): [94:210](score: 88.6, e-value: 3e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyC collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00440.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyC\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyC\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75505.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyC.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyC\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyC\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGAGCGCGACACCCGAAACGCACCGCGCGGCAGGTTGGACAAGCGGCAGGCGATCATCGCCGCGGCCCTGCGCGTGTTCGCCCGCGAGGGCTACGGCCAGGCCAGCCTGGACACCATCGCGGCCGAGGCCGGGGTGGCGAAGCCGACCATCTACAACCACCTGGGCGGCAAGGAGAACCTGTTCCGGCACGTCCTCGCCGAGATTGCCGCGCGGTCGAACGCCAAGACCCTCGCAGCTCTCCAGACGTTCCCCACCGACCCTCAGGAGCTGCGCGACCACCTCAACACCGTCGGCCTGCGGCTGGCCGAATGCTTCGTCGACGAGCAGTCCTCGGCGCTGCGCCGGCTGCTGCACGCAGAGATCGCGCGCTTTCCCGACCTGTTCGACGTCGTGCTCGACAGCGGGCCGAACCAGGCCACCGAGGCGCTCGCGGGCCGGCTTGCACGGCTGGCCAACGCCGGCTACCTGACGATCGAGGACCCGATCCGCGCCGCCCGCCAATTCGTCGCCCTGCTGACCGACGAGCTGCCCGCGATGACCGCGCTCGGCACCCGCCCGATCAACCCGGACGACCTGGAACGCGCGGTGACCGCCGGGGTGGACACGTTCCTGCGGGCCTTCGCCACACCGACCGACGCCCCGGCCGACCCGCCCGCGCGCGAGGCGGTCGGGCCGCTGCCAGGCTGA",
      "translation": "MTERDTRNAPRGRLDKRQAIIAAALRVFAREGYGQASLDTIAAEAGVAKPTIYNHLGGKENLFRHVLAEIAARSNAKTLAALQTFPTDPQELRDHLNTVGLRLAECFVDEQSSALRRLLHAEIARFPDLFDVVLDSGPNQATEALAGRLARLANAGYLTIEDPIRAARQFVALLTDELPAMTALGTRPINPDDLERAVTAGVDTFLRAFATPTDAPADPPAREAVGPLPG",
      "product": "TetR regulatory protein"
     },
     {
      "start": 47233,
      "end": 48660,
      "strand": 1,
      "locus_tag": "abyD",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyD</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75506.1</span><br>\n Gene: <span class=\"serif\">abyD</span><br>\n \n Location: 47,233 - 48,660,\n (total: 1428 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 355.1; E-value: 7.5e-108)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyD collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07690.19 (Major Facilitator Superfamily): [20:413](score: 187.5, e-value: 3.5e-55)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyD collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00711 (efflux_EmrB: drug resistance MFS transporter, drug:H+ antiporter-2 (14 Spanner) (DHA2) family): [13:422](score: 342.6, e-value: 8.5e-103)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyD collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyD\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyD\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75506.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTQSPSDRIDGPLLRLLGVMVLGGVMSYFDATIINVSVETLTAHFDATLGTISWVATGYLLAVAVAIPLAGWAVARFGARRVWLAALTLFLVASALCALAWDVGSLIAFRVFQGFAGGLLEPIMLTVVATAAGPSRMGRAMGLISIPITLGPVLGPIIGGLILQNLTWQWIFLVNVPIALLAIALALLIMRDDRPEPGAAPPLDLIGVALLSPGFAALIYALSQAGTAGFGATRVIVGLAVGVVLVAAYVAHALRSAQPLIDLRLFRSSGFTSSVLTMFLLGGMLFSLLFLLPLFYQQVRGQGVLAAGLLLVPLGLGTMVGMPVAGKLADTFGPRRLVPTGALLIALSALVYTQAGPDTSQVLLTAAQLVTGFGLGLVGAPTMGSVYRTVAPEAVGGATGTLFILNQIGASLGVAVVALIVQSGLTDGRTPADSFDQAFWWTVAGGVIVALASRFLPGRPQPVTPTPADAETAAA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyD.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyD\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyD\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCCAATCCCCATCCGACCGCATCGACGGCCCACTGCTTCGCCTGCTCGGCGTCATGGTCCTCGGCGGGGTGATGTCCTACTTCGACGCCACGATCATCAACGTGAGCGTCGAGACGCTGACCGCTCACTTCGACGCCACACTGGGCACGATCTCGTGGGTCGCCACCGGTTACCTGCTCGCCGTGGCCGTCGCCATCCCGCTCGCCGGGTGGGCGGTGGCCCGCTTCGGCGCGCGCCGCGTGTGGCTGGCCGCGCTGACCCTCTTCCTGGTTGCCTCGGCGCTGTGCGCCCTGGCCTGGGACGTGGGCAGCCTGATCGCCTTCCGCGTGTTCCAGGGCTTCGCCGGCGGCCTGCTCGAACCCATCATGCTCACCGTGGTCGCCACGGCGGCCGGCCCGAGCCGGATGGGCCGCGCGATGGGCCTGATCTCCATCCCGATCACCCTGGGACCGGTGCTCGGCCCGATCATCGGCGGTCTGATCCTGCAGAACCTGACCTGGCAGTGGATCTTCCTGGTCAACGTGCCGATCGCGCTGCTGGCCATCGCCCTGGCGCTGCTGATCATGCGCGACGACCGGCCCGAGCCGGGCGCCGCGCCGCCGCTGGACCTGATCGGTGTCGCCCTGCTCTCCCCCGGCTTCGCCGCCCTGATCTACGCGCTGTCGCAGGCCGGCACGGCCGGGTTCGGCGCCACCCGGGTCATCGTCGGGCTCGCCGTGGGGGTGGTGCTGGTCGCCGCGTACGTGGCGCACGCGCTGCGTTCCGCACAGCCGCTCATCGACCTGCGCCTGTTCCGCAGCAGCGGCTTCACCTCCAGCGTGCTCACCATGTTCCTACTCGGCGGCATGCTGTTCTCGCTGTTGTTCCTGCTGCCGCTGTTCTACCAGCAGGTGCGCGGGCAGGGCGTGCTCGCCGCCGGACTGCTGCTCGTACCGCTCGGGCTGGGCACGATGGTCGGCATGCCGGTGGCCGGCAAGCTCGCCGACACCTTCGGCCCCCGCCGGCTGGTACCGACCGGCGCCCTGCTGATCGCGCTCAGCGCCCTCGTCTACACCCAGGCCGGACCGGACACCTCGCAGGTCCTGCTCACCGCCGCCCAACTCGTGACCGGCTTCGGCCTCGGCCTCGTCGGCGCACCGACGATGGGCTCCGTCTACCGCACCGTCGCGCCCGAGGCGGTGGGCGGCGCGACCGGCACCCTGTTCATCCTCAACCAGATCGGCGCGTCGTTGGGCGTGGCGGTGGTCGCGCTCATCGTGCAGAGCGGCCTCACCGACGGCCGGACGCCCGCCGACTCCTTCGACCAAGCCTTCTGGTGGACCGTCGCCGGTGGCGTGATCGTCGCACTGGCCAGCAGGTTCCTGCCCGGACGCCCGCAGCCCGTCACCCCCACACCGGCCGATGCGGAGACCGCCGCGGCCTGA",
      "translation": "MTQSPSDRIDGPLLRLLGVMVLGGVMSYFDATIINVSVETLTAHFDATLGTISWVATGYLLAVAVAIPLAGWAVARFGARRVWLAALTLFLVASALCALAWDVGSLIAFRVFQGFAGGLLEPIMLTVVATAAGPSRMGRAMGLISIPITLGPVLGPIIGGLILQNLTWQWIFLVNVPIALLAIALALLIMRDDRPEPGAAPPLDLIGVALLSPGFAALIYALSQAGTAGFGATRVIVGLAVGVVLVAAYVAHALRSAQPLIDLRLFRSSGFTSSVLTMFLLGGMLFSLLFLLPLFYQQVRGQGVLAAGLLLVPLGLGTMVGMPVAGKLADTFGPRRLVPTGALLIALSALVYTQAGPDTSQVLLTAAQLVTGFGLGLVGAPTMGSVYRTVAPEAVGGATGTLFILNQIGASLGVAVVALIVQSGLTDGRTPADSFDQAFWWTVAGGVIVALASRFLPGRPQPVTPTPADAETAAA",
      "product": "EmrB/QacA drug resistance transporter"
     },
     {
      "start": 48731,
      "end": 49738,
      "strand": 1,
      "locus_tag": "abyE",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyE</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75507.1</span><br>\n Gene: <span class=\"serif\">abyE</span><br>\n \n Location: 48,731 - 49,738,\n (total: 1008 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1251:luciferase family protein (Score: 100.5; E-value: 1.8e-30)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyE collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00296.23 (Luciferase-like monooxygenase): [16:299](score: 132.6, e-value: 2.1e-38)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyE collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03558 (oxido_grp_1: luciferase family oxidoreductase, group 1): [6:328](score: 388.8, e-value: 4.6e-117)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyE collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00296.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyE\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyE\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75507.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyE.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyE\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyE\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGACACACCGCCCGTATCCGTCCTCGACGTCGTTCCGGTCTGGAGCGGCTCCACGGCGACGCGCGCCCTGCGCGACTCCGTGCAGCTCGCCGTCGAGGTCGAGCGGCTCGGTTACACCCGCTACTGGGTGGCCGAGCACCACAACACCCCGTGCCTGGCCACCGCCACGCCTCCCGTCCTGGTCGGCGCCCTGCTGGCGGCCACCTCGACGCTGCGGGTGGGCTCCGGCGGGGTCCTGCTGCCCAACCACCCCCCGCTGGTGGTCGCCGAGCAGTTCGGCACCCTCGCCGCGCTGTACCCGGGCCGCGTCGACCTCGGGGTCGGTCGCGCCCCCGGCACCGACGCCGCCACGGCCCGTGCCCTGCGCCGGGCACCCGACGGCGCCGACCAGTTCCCGACGGAGCTCGCCGAGCTGATCGACCACTTCGGCCCGGCACCGCGTCCCCGGCAGATCACCGCCGTGGCCGCTGCCGAGTCCGAGGTACCGGTCTGGATCCTGGGCTCCAGCCCCGGCAGCGCCCGCCTGGCCGGCTCGCTCGGGCTGCCGTACGCGTTCGCCCACCAGATCAACCCGACCCTCACCGCCACCGCGCTGCAGCTCTACCGGAAGTCGTTCCGCCCCTCGGCACACCTCGCCGATCCGCACGCGATCCTGTCGGCCGTGGTCGTGGTCGGCGAGAACGACGAGCACGCCGAGCGGCTGATCGCGCCGTACCTGCTCGGTCAGATCGGGCACCGCACCGTCGGTCGACTGGACCCCTTTCCGAACGCGGCGCAGGCTCAGCAGCACTCGTACACCGACGCCGAACGGGCCTTCGTCGCCGAGCGGATCACCAGCCAGATAGTGGGCGGCCCCGAAACGGTGCGCGAGCGGGTCCAGCGGTTGCACGCGGAGACCGGCGCGAACGAGCTGATGGCGCTGACCATCCTGCCCGAGCTGGAGGACCGCGTGCGCTCTTACGCCCTGCTGGCCGACGCCGTCCGGGCCAGCATCGCCGTGTAG",
      "translation": "MTDTPPVSVLDVVPVWSGSTATRALRDSVQLAVEVERLGYTRYWVAEHHNTPCLATATPPVLVGALLAATSTLRVGSGGVLLPNHPPLVVAEQFGTLAALYPGRVDLGVGRAPGTDAATARALRRAPDGADQFPTELAELIDHFGPAPRPRQITAVAAAESEVPVWILGSSPGSARLAGSLGLPYAFAHQINPTLTATALQLYRKSFRPSAHLADPHAILSAVVVVGENDEHAERLIAPYLLGQIGHRTVGRLDPFPNAAQAQQHSYTDAERAFVAERITSQIVGGPETVRERVQRLHAETGANELMALTILPELEDRVRSYALLADAVRASIAV",
      "product": "luciferase/monooxygenase"
     },
     {
      "start": 49826,
      "end": 51442,
      "strand": 1,
      "locus_tag": "abyF1",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75508.1</span><br>\n Gene: <span class=\"serif\">abyF1</span><br>\n \n Location: 49,826 - 51,442,\n (total: 1617 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1068:extracellular solute-binding protein family 5 (Score: 373; E-value: 4.4e-113)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF1 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00496.25 (Bacterial extracellular solute-binding proteins, family 5 Middle): [79:446](score: 239.3, e-value: 7.4e-71)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75508.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMRTTTRSTAILLLLVAATAACGTSAAQTGDAQPTTGGALTFATAVEPDCLDPAVSARDVTGVINRNIFDSLVRQAPDGSFHPWLAERWETAPDGRAYTFHLRSGVRFHDGTTLDAAAVKATLDHAVDPATESRFAAGLLAAYRSAEVTDASTVTVRLSRPDAALLQTLSTPYLGIQSPRSLRENKDGLCEQPIGSGPFRFVRWEKKVGIDLSRYPDYAWSPSGATHQGPARLDTLRITFVAEDSVRLGSLTSGQVQVSDVPASKARTVQGSAHLLKTEVPGAPYTIFLNSSRDAILADIRVRQALRRAVDLDQLVKSIYFGQNQRAWSPLTPATPLYDDSTRDAFTFDQAEANRLLDEAGWTQRDSAGYRLKDGRRLTLRWPHTAAMERDQRNLIGQGLQSQAKQVGIEIQYTLVDQGTIGDLIGKRALDLFDVSFTRSDPDILRYFFGTKSTLAEGGGNIFGLDIPELDKLLTDGVSTLDPAQRQRIYSDAQRYVVENAVSLPVYVPTSLLGVARHVHGVEFGANATPLFAGAWIAG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF1.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCGCACGACAACCCGCTCGACAGCCATTCTGCTGCTCCTGGTCGCCGCCACCGCGGCCTGCGGCACCTCCGCGGCCCAGACCGGCGACGCCCAGCCCACCACGGGCGGCGCCCTGACCTTCGCCACCGCCGTGGAACCGGACTGCCTCGACCCCGCGGTCAGCGCACGGGACGTCACCGGCGTCATCAACCGCAACATCTTCGACTCGCTCGTGCGGCAGGCCCCGGACGGGAGCTTCCACCCCTGGCTGGCCGAGCGGTGGGAGACGGCGCCGGACGGGCGGGCCTACACCTTCCACCTGCGATCGGGAGTACGGTTCCACGACGGCACCACCCTCGACGCCGCGGCGGTGAAGGCCACCCTGGACCACGCCGTCGATCCCGCCACCGAGTCCCGCTTCGCGGCGGGCCTGCTGGCCGCCTACCGCAGCGCCGAGGTCACCGACGCGTCCACCGTCACCGTCCGGCTGAGCCGTCCGGACGCCGCACTGCTCCAGACGCTGAGCACCCCCTACCTGGGCATCCAGTCCCCCCGGTCACTGCGGGAGAACAAGGACGGGCTCTGCGAACAGCCGATCGGTTCCGGGCCGTTCCGCTTCGTCCGGTGGGAGAAGAAGGTCGGCATCGACCTGAGCCGCTACCCCGACTACGCCTGGTCGCCCAGCGGGGCAACCCACCAGGGACCGGCCCGCCTGGACACGCTACGGATCACGTTCGTGGCAGAGGACAGCGTCCGGCTCGGGTCGCTGACCAGCGGTCAGGTGCAGGTCTCCGACGTGCCGGCGAGCAAGGCGCGCACGGTGCAGGGCAGCGCCCACCTGCTCAAGACCGAGGTCCCCGGGGCCCCGTACACCATCTTCCTCAACTCCTCCCGCGACGCGATCCTGGCCGACATCCGGGTCCGCCAGGCCCTGCGTCGGGCGGTGGACCTCGACCAGCTCGTCAAGAGCATCTACTTCGGGCAGAACCAGCGCGCGTGGAGCCCACTGACCCCGGCCACCCCGCTGTACGACGACTCGACCCGGGACGCGTTCACCTTCGACCAGGCCGAGGCGAACCGCCTGCTGGACGAGGCGGGGTGGACCCAGCGCGACAGCGCCGGTTACCGACTCAAGGACGGCCGCCGGCTCACCCTGCGCTGGCCGCACACCGCCGCGATGGAACGCGACCAACGGAACCTGATCGGGCAGGGCCTGCAGTCGCAGGCCAAGCAGGTGGGTATCGAGATCCAGTACACGCTGGTCGACCAGGGCACGATCGGCGACCTGATCGGCAAGCGGGCGCTGGACCTGTTCGACGTCAGCTTCACCCGCTCCGACCCGGACATCTTGCGCTACTTCTTCGGCACGAAGTCGACGCTCGCCGAGGGCGGCGGCAACATCTTCGGCCTCGACATCCCCGAGCTGGACAAGCTGCTCACCGACGGCGTGAGCACCCTCGACCCGGCACAGCGCCAGCGCATCTACAGCGACGCGCAGCGGTACGTGGTCGAGAACGCCGTCTCCCTGCCGGTCTACGTGCCCACCAGCCTGCTCGGGGTGGCCCGCCACGTACACGGCGTCGAATTCGGCGCGAACGCCACCCCGCTGTTCGCCGGTGCCTGGATCGCCGGATGA",
      "translation": "MRTTTRSTAILLLLVAATAACGTSAAQTGDAQPTTGGALTFATAVEPDCLDPAVSARDVTGVINRNIFDSLVRQAPDGSFHPWLAERWETAPDGRAYTFHLRSGVRFHDGTTLDAAAVKATLDHAVDPATESRFAAGLLAAYRSAEVTDASTVTVRLSRPDAALLQTLSTPYLGIQSPRSLRENKDGLCEQPIGSGPFRFVRWEKKVGIDLSRYPDYAWSPSGATHQGPARLDTLRITFVAEDSVRLGSLTSGQVQVSDVPASKARTVQGSAHLLKTEVPGAPYTIFLNSSRDAILADIRVRQALRRAVDLDQLVKSIYFGQNQRAWSPLTPATPLYDDSTRDAFTFDQAEANRLLDEAGWTQRDSAGYRLKDGRRLTLRWPHTAAMERDQRNLIGQGLQSQAKQVGIEIQYTLVDQGTIGDLIGKRALDLFDVSFTRSDPDILRYFFGTKSTLAEGGGNIFGLDIPELDKLLTDGVSTLDPAQRQRIYSDAQRYVVENAVSLPVYVPTSLLGVARHVHGVEFGANATPLFAGAWIAG",
      "product": "BC transporter oligopeptide binding protein"
     },
     {
      "start": 51439,
      "end": 52374,
      "strand": 1,
      "locus_tag": "abyF2",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75509.1</span><br>\n Gene: <span class=\"serif\">abyF2</span><br>\n \n Location: 51,439 - 52,374,\n (total: 936 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1118:binding-protein-dependent transport systems (Score: 303; E-value: 3.5e-92)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF19300.2 (Binding-prot-dependent transport system membrane comp, N-term): [4:105](score: 35.8, e-value: 8.1e-09)<br>\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [119:307](score: 105.9, e-value: 2.3e-30)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyF2 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75509.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSPALRWLARKLALAVLVVLGAATVAFAALHLAPGDPVRAVIGTLAPSDDLVAQVRADLDLDKPLATQYAHMLGGLARGDLGESYQLRRPVVEVIVADLGWTVQLAVASLLLALVVSTALAVATAGRRPTLRRVSILLELVTASSPTFWVGTILLAVLSFQLHLFPAAGAGGLEGLVLPAVTQAIGLVGIFTQVLRQSMEQALDEPFALSARARGTTETALRLRHAARHALIPVLTLSGWILGALLSGAVVVETLFSRPGLGRTLVTAILGRDLPVVIGVVVVAAALFTVINLVVDLLYRVVDPRLREWAA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF2.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCCTGCCCTCCGGTGGCTGGCGCGCAAGCTGGCCCTGGCCGTCCTGGTCGTCCTCGGGGCCGCGACCGTGGCGTTCGCGGCGCTGCACCTCGCACCGGGCGACCCGGTCCGCGCGGTGATCGGCACGCTGGCCCCGAGCGACGACCTGGTGGCCCAGGTCCGCGCCGACCTCGACCTCGACAAGCCGCTGGCCACCCAGTACGCGCACATGCTGGGTGGCCTCGCGCGCGGCGACCTGGGTGAGTCCTACCAGCTGCGCCGCCCGGTCGTCGAGGTGATCGTGGCGGACCTCGGCTGGACCGTCCAGCTCGCGGTCGCCTCCCTGCTGCTCGCGCTGGTGGTGTCGACGGCACTCGCGGTCGCCACCGCCGGCCGGCGGCCCACCCTGCGCCGGGTCAGCATCCTGCTGGAACTCGTGACCGCCTCCAGCCCGACATTCTGGGTGGGCACCATCCTGCTCGCGGTGCTGTCGTTCCAGCTGCACCTCTTCCCCGCCGCCGGCGCCGGCGGTCTGGAAGGGCTCGTGCTGCCGGCCGTCACGCAGGCGATCGGGTTGGTCGGCATCTTCACCCAGGTGCTGCGGCAGAGCATGGAGCAGGCCCTCGACGAGCCCTTCGCGCTCAGCGCGCGGGCCCGAGGCACCACCGAGACGGCCCTGCGGCTGCGGCACGCCGCGCGGCACGCCCTCATCCCGGTGCTCACCCTGTCCGGTTGGATCCTGGGGGCGCTGCTCAGCGGCGCGGTCGTGGTGGAGACGCTGTTCAGCCGGCCGGGCCTCGGGCGCACGCTGGTCACCGCCATCCTCGGCCGCGACCTGCCGGTGGTGATCGGCGTGGTGGTGGTCGCCGCCGCGCTGTTCACCGTGATCAACCTGGTCGTCGACCTGCTGTACCGCGTCGTCGACCCCCGGCTGCGGGAGTGGGCGGCATGA",
      "translation": "MSPALRWLARKLALAVLVVLGAATVAFAALHLAPGDPVRAVIGTLAPSDDLVAQVRADLDLDKPLATQYAHMLGGLARGDLGESYQLRRPVVEVIVADLGWTVQLAVASLLLALVVSTALAVATAGRRPTLRRVSILLELVTASSPTFWVGTILLAVLSFQLHLFPAAGAGGLEGLVLPAVTQAIGLVGIFTQVLRQSMEQALDEPFALSARARGTTETALRLRHAARHALIPVLTLSGWILGALLSGAVVVETLFSRPGLGRTLVTAILGRDLPVVIGVVVVAAALFTVINLVVDLLYRVVDPRLREWAA",
      "product": "ABC transporter oligopeptide permease"
     },
     {
      "start": 52371,
      "end": 53222,
      "strand": 1,
      "locus_tag": "abyF3",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75510.1</span><br>\n Gene: <span class=\"serif\">abyF3</span><br>\n \n Location: 52,371 - 53,222,\n (total: 852 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1085:binding-protein-dependent transport systems (Score: 256.5; E-value: 4e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [96:267](score: 91.8, e-value: 4.5e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyF3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75510.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTTVLTPVTAPVARARPALVLAWVGLGLLALAAAWPALLATAAPDTVDPASALAPISPHHPFGTDQLGRDVYSRVVYGTRMSLLIGLGATTLAVTAGALLGVLAAAAGRAVDELFMRITDILLAFPGLLLALLVIAVLGPGAVNTTIALACAAVPGYVRLARGQALVVRRSGYVSAAVVMGRSRVGIFFGHVLPNALPPVLAFAAVDVGTALMASASLSFLGLGAQPPAPEWGSMLAEGRDYLDSTWGLTVFPGLVVTAAVIACYVVGADLRARFEGRGTGGR\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF3.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGACCGTCCTCACCCCGGTCACCGCGCCGGTGGCCCGTGCCCGTCCCGCCCTGGTGCTGGCCTGGGTCGGGCTCGGGTTGCTCGCCCTGGCCGCCGCCTGGCCCGCGCTGCTCGCCACCGCCGCGCCGGACACGGTCGACCCCGCCTCGGCGCTCGCGCCGATCAGCCCGCACCACCCGTTCGGCACCGACCAGCTCGGGCGTGACGTCTACAGCCGGGTGGTGTACGGCACCCGCATGTCGCTGCTCATCGGGCTCGGCGCGACCACGCTGGCCGTGACCGCAGGCGCGCTGCTCGGGGTGCTGGCCGCCGCCGCCGGGCGAGCCGTCGACGAACTGTTCATGCGGATCACCGACATCCTGTTGGCGTTCCCGGGACTGCTGCTGGCGCTGCTGGTGATCGCCGTGCTCGGTCCGGGCGCGGTGAACACCACCATCGCCCTGGCCTGCGCCGCCGTACCCGGCTACGTGCGCCTGGCCCGGGGGCAGGCGCTGGTGGTCCGCCGGTCGGGCTACGTGTCGGCGGCGGTGGTGATGGGCCGGTCCCGGGTCGGGATCTTCTTCGGTCACGTGCTGCCGAACGCGCTGCCGCCGGTGCTCGCCTTCGCGGCGGTGGACGTCGGTACGGCGCTGATGGCCAGCGCCTCGCTGAGCTTCCTCGGCCTGGGCGCGCAGCCACCCGCGCCGGAGTGGGGCTCGATGCTCGCCGAGGGACGGGACTACCTGGACAGCACCTGGGGGCTGACGGTGTTTCCCGGCCTGGTGGTCACCGCCGCGGTGATCGCCTGCTACGTCGTCGGCGCCGACCTGCGCGCCCGGTTCGAGGGACGGGGCACCGGTGGACGATGA",
      "translation": "MTTVLTPVTAPVARARPALVLAWVGLGLLALAAAWPALLATAAPDTVDPASALAPISPHHPFGTDQLGRDVYSRVVYGTRMSLLIGLGATTLAVTAGALLGVLAAAAGRAVDELFMRITDILLAFPGLLLALLVIAVLGPGAVNTTIALACAAVPGYVRLARGQALVVRRSGYVSAAVVMGRSRVGIFFGHVLPNALPPVLAFAAVDVGTALMASASLSFLGLGAQPPAPEWGSMLAEGRDYLDSTWGLTVFPGLVVTAAVIACYVVGADLRARFEGRGTGGR",
      "product": "binding-protein dependent ABC transporter"
     },
     {
      "start": 53212,
      "end": 54831,
      "strand": 1,
      "locus_tag": "abyF4",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75511.1</span><br>\n Gene: <span class=\"serif\">abyF4</span><br>\n \n Location: 53,212 - 54,831,\n (total: 1620 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 202.4; E-value: 1.4e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF4 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [25:183](score: 83.4, e-value: 2.2e-23)<br>\n \n  PF08352.15 (Oligopeptide/dipeptide transporter, C-terminal region): [233:274](score: 26.0, e-value: 1e-05)<br>\n \n  PF00005.30 (ABC transporter): [308:448](score: 109.2, e-value: 2.4e-31)<br>\n \n  PF08352.15 (Oligopeptide/dipeptide transporter, C-terminal region): [499:529](score: 27.6, e-value: 3.4e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyF4 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF08352.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF08352.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF08352.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015833' target='_blank'>GO:0015833</a>: peptide transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75511.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMDDEVVSVAGLHVTYRVGRAEVFAVRGVDFHLRAGECLAIVGESGSGKSTVARALVGLTGPGARLRSDRLVVSGQELSRLGDREWRRIRGAQVGLVLQDALTALDPLRTVGAEVAEAARNHGLVRRGEVARRVHRLLTDVQVPQPELRARQYPQQLSGGLRQRALIAAAMAADPPVLVADEPTTALDVTLQAKLLDLLAARKAAGTAVLLISHDLSVVARLADRVAVMRDGEFVETGCTTDVLRAPEHPYTRQLLAATPSAHARGARLAGPRSTPARTRTPRPSGVLARVREVSKTFRGPGGARLAAVSEVSFSLSAGEILGVVGESGSGKSTLAHLLLGLLEPDTGTIELFGQPWSGVPEARRQRGRVQWVQQDPLGSFDPRYRVGRLIAEAGVDRARVRELLDQVGLDPAMADRHPRTLSGGQRQRVAIARALARDPEVIVCDEPVSALDVSVQAQILDLFADIRADLGTALVLISHDLAVVHHVADRVLVMRAGTVVESGPVTEVFARPTHPYTAQLIAALPRPGDAYAAYPEGVA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF4.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGACGATGAGGTCGTGTCCGTCGCCGGGCTGCACGTGACGTACCGCGTCGGCCGCGCCGAGGTGTTCGCCGTGCGCGGGGTGGACTTCCACCTGCGCGCCGGGGAGTGCCTGGCCATCGTGGGCGAATCCGGGTCGGGCAAGAGCACGGTGGCTCGCGCGTTGGTCGGCCTCACCGGACCCGGCGCACGGCTGCGCAGCGACCGGCTCGTGGTGTCCGGCCAGGAACTCAGCAGGCTGGGCGACCGCGAGTGGCGGCGGATACGTGGCGCCCAGGTGGGGCTGGTGTTGCAGGACGCGCTCACCGCGCTGGATCCACTGCGTACCGTCGGCGCCGAGGTCGCCGAGGCGGCGCGCAACCACGGTCTGGTCCGTCGGGGTGAGGTGGCGCGACGGGTCCACCGACTGCTCACCGACGTCCAGGTGCCGCAGCCCGAGCTGCGTGCCCGGCAGTACCCGCAGCAGCTCTCCGGTGGTCTGCGCCAACGCGCGCTGATCGCCGCCGCGATGGCCGCGGATCCGCCGGTGCTGGTGGCCGACGAGCCCACCACCGCGCTGGACGTCACCCTGCAGGCCAAGCTGCTCGACCTGCTGGCGGCACGCAAGGCAGCCGGCACCGCCGTGCTGCTGATCAGTCACGACCTGTCCGTGGTGGCCCGGCTCGCCGACCGGGTCGCGGTGATGCGCGACGGAGAGTTCGTGGAGACCGGCTGCACGACCGACGTGCTGCGCGCGCCGGAGCACCCGTACACCCGGCAGTTGCTCGCGGCCACACCCTCCGCGCACGCCCGCGGCGCCCGACTGGCCGGGCCGCGCAGCACACCGGCGCGAACCCGTACGCCGCGTCCGTCCGGTGTCCTGGCGCGGGTCCGGGAGGTCTCCAAGACGTTCCGCGGGCCGGGCGGGGCACGGCTCGCGGCCGTGTCGGAGGTGTCGTTCTCACTTTCGGCCGGTGAGATCCTCGGCGTGGTCGGCGAGTCGGGCTCGGGCAAGAGCACCCTCGCGCATCTGCTGCTCGGGCTCCTCGAACCGGACACCGGCACCATCGAGCTGTTCGGGCAGCCCTGGTCGGGGGTGCCGGAGGCGCGGCGGCAGCGGGGCCGCGTGCAGTGGGTGCAGCAGGACCCGCTCGGCTCGTTCGACCCGCGCTACCGGGTGGGACGGCTGATCGCCGAGGCGGGGGTCGACCGGGCCCGGGTCCGCGAGCTGCTCGACCAGGTCGGTCTCGACCCGGCCATGGCCGACCGGCACCCGCGCACATTGTCCGGCGGGCAGCGGCAGCGGGTCGCCATCGCCCGCGCGCTCGCCCGCGACCCGGAGGTCATCGTGTGCGACGAACCGGTCTCCGCGCTGGACGTCTCGGTGCAGGCACAGATCCTGGACCTCTTCGCCGACATCCGCGCCGACCTGGGTACCGCGCTGGTGCTGATCAGCCACGACCTCGCGGTGGTGCACCACGTGGCGGACCGGGTCCTGGTGATGCGGGCCGGGACGGTCGTGGAGAGCGGGCCGGTGACCGAGGTCTTCGCCCGGCCGACGCACCCCTACACCGCGCAGCTCATCGCCGCCCTCCCCCGGCCGGGGGACGCCTACGCCGCCTACCCCGAAGGAGTCGCATGA",
      "translation": "MDDEVVSVAGLHVTYRVGRAEVFAVRGVDFHLRAGECLAIVGESGSGKSTVARALVGLTGPGARLRSDRLVVSGQELSRLGDREWRRIRGAQVGLVLQDALTALDPLRTVGAEVAEAARNHGLVRRGEVARRVHRLLTDVQVPQPELRARQYPQQLSGGLRQRALIAAAMAADPPVLVADEPTTALDVTLQAKLLDLLAARKAAGTAVLLISHDLSVVARLADRVAVMRDGEFVETGCTTDVLRAPEHPYTRQLLAATPSAHARGARLAGPRSTPARTRTPRPSGVLARVREVSKTFRGPGGARLAAVSEVSFSLSAGEILGVVGESGSGKSTLAHLLLGLLEPDTGTIELFGQPWSGVPEARRQRGRVQWVQQDPLGSFDPRYRVGRLIAEAGVDRARVRELLDQVGLDPAMADRHPRTLSGGQRQRVAIARALARDPEVIVCDEPVSALDVSVQAQILDLFADIRADLGTALVLISHDLAVVHHVADRVLVMRAGTVVESGPVTEVFARPTHPYTAQLIAALPRPGDAYAAYPEGVA",
      "product": "ATP-binding ABC peptide transporter"
     },
     {
      "start": 54828,
      "end": 56015,
      "strand": 1,
      "locus_tag": "abyV",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyV</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75512.1</span><br>\n Gene: <span class=\"serif\">abyV</span><br>\n \n Location: 54,828 - 56,015,\n (total: 1188 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1007:cytochrome P450 (Score: 399.5; E-value: 2.6e-121)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyV collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [268:364](score: 74.9, e-value: 5.9e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyV collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyV\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyV\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75512.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyV\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyV\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGAGATCCCGTCTGCGGCGACCGCGTCGCCGCAGTATCCGCAGCGGCGCGCCTGCCCCTATCGTCCGGCAGGGGGTTACGAGCGGCCGGTGACCCGCGTACGGCTGTACGACGGCCGGCCGGCGTGGCTGGTCACCGGCCACGAGACGGCACGGCAGGTGCTGCTGGACGCCGCGACCTTCTCCTCCGACCGGCAGCACCCCGCGTTCCCGGCGCTCGCCGCGCGGTTCGAGGCCGCCCGCGCGGTCCGCAACTTCATCGGGATGGACCCGCCCGAGCACACGGCGCAGCGGCGCATGCTCATCTCCGGTTTCACCGCCAAGCGGGTGGCCACACTCCGGCCGGCCATCACCGAGATCGTGGACTCCCTCCTCGACGAGGTGGTTCGGCGCGGGCCCGGAGTGGACCTCGTTGCGACCTTCACGCTCCCGGTGCCGTCGGTCGTGATCTGCCGCCTACTCGGCGTCCCGTACGCCGACCACGAGTTCTTCGAGCACCAGTCCCGGCGCATCGCGGCGGGCACCTCGACGGCCGCCGAGAGCGCGGACGCCTTCGGCCAACTGAAGCGCTATCTGCTCGGTCTGATCGAAACGAAGGGCAGAGGCGGCGAGGACATGCTCGACGTGCTCGTCGACGAGCAGGTGGCCACCGGCACAGTCACGACCCCTGACCTGGTCGACCTGGCACTGTTGCTGCTCGTGGCGGGGCACGAGACCACGGCCAGCACGTTGGCGCTCGGAGTGGCTCTCCTGCTGGAGCAGGACGGCGGCGCCGTCGCCGCCGACCCGACGCGAGTCGGCGCGGTGGTGGAGGAGATCCTGCGGCACACCGCCGTGGCCGACGGCGTGGCCCGCTTCGCCACCCGCGACACCGAGGTGGCCGGCGTCCGGATCGCCGCCGGCGACGCGGTGGTGGTCGCTCTCTCGGCGGCCAACCGGGACCCGGGCCCGTTCCCCGACCCGGACCGCTTCGACCCTCGTCGTGGCGGTCGCCAGCACGTGACCTTCGGGCACGGCCCCCACCAGTGCATCGGTGCGAACCTGGCCCGCGCCGAGTTGGAGATCGCCCTGTCCCGTCTGTTCACGCGGCTGCCGACGCTGGCGCTCGCGGTGCCCGTCGAGGAGCTGGGCGGCAAGGAGGCGGGGGGTGTGCAGGGTGTCCAACGCCTTCCGGTCACCTGGTGA",
      "translation": "MIEIPSAATASPQYPQRRACPYRPAGGYERPVTRVRLYDGRPAWLVTGHETARQVLLDAATFSSDRQHPAFPALAARFEAARAVRNFIGMDPPEHTAQRRMLISGFTAKRVATLRPAITEIVDSLLDEVVRRGPGVDLVATFTLPVPSVVICRLLGVPYADHEFFEHQSRRIAAGTSTAAESADAFGQLKRYLLGLIETKGRGGEDMLDVLVDEQVATGTVTTPDLVDLALLLLVAGHETTASTLALGVALLLEQDGGAVAADPTRVGAVVEEILRHTAVADGVARFATRDTEVAGVRIAAGDAVVVALSAANRDPGPFPDPDRFDPRRGGRQHVTFGHGPHQCIGANLARAELEIALSRLFTRLPTLALAVPVEELGGKEAGGVQGVQRLPVTW",
      "product": "cytochrome P450"
     },
     {
      "start": 55978,
      "end": 56229,
      "strand": 1,
      "locus_tag": "abyW",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyW</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75513.1</span><br>\n Gene: <span class=\"serif\">abyW</span><br>\n \n Location: 55,978 - 56,229,\n (total: 252 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1265:ferredoxin (Score: 76.5; E-value: 2.2e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyW collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13459.9 (4Fe-4S single cluster domain): [16:75](score: 44.2, e-value: 2.5e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyW\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyW\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75513.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyW.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyW\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyW\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTGCAGGGTGTCCAACGCCTTCCGGTCACCTGGTGACCCGGTCCACGTCAACATCGACGCGGCACGGTGCGTCGGCGCCGGGCAGTGCGTGCGGACCGACCCGACGGTCTTCGGCCAGTCCGACGAGGGCACCGTCCGGCTGTTGCGCGGCAGCCTCCCCGGCTCCCTGCGGTCCGTGGTGACCGAGGCGGCGGCGCTGTGCCCGGCCCAGGCGATCACCGTGACCGGCACGGCCGATCCGCCCCACTGA",
      "translation": "MCRVSNAFRSPGDPVHVNIDAARCVGAGQCVRTDPTVFGQSDEGTVRLLRGSLPGSLRSVVTEAAALCPAQAITVTGTADPPH",
      "product": "alcohol dehydrogenase"
     },
     {
      "start": 56230,
      "end": 56808,
      "strand": -1,
      "locus_tag": "abyZ",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyZ</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75514.1</span><br>\n Gene: <span class=\"serif\">abyZ</span><br>\n \n Location: 56,230 - 56,808,\n (total: 579 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyZ collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03358.18 (NADPH-dependent FMN reductase): [2:143](score: 103.1, e-value: 1.3e-29)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyZ collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03567 (FMN_reduc_SsuE: FMN reductase): [2:172](score: 206.0, e-value: 8.8e-62)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyZ collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03358.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyZ\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyZ\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75514.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyZ\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyZ\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCACCGTGCTCTCCGTCTCCGGCAGCCCGTCGGCGACCTCGCGTACCGCTGGCCTGCTTCGTCACCTCGACCGGCAGTTGGTCGCCGACGGGCACGAGGTGATCCCGCTGGACGTGCGGACCCTGCCCGCGCACGTGCTGGTCGGCGCCGACCCACGCCACCCGGCGATCACCGGCGTGGCGGCGCTGGTCGCGGAGGCCGACGGGCTGGTGATCGGCACACCGATCTACAAGGCCGCCTACTCCGGCCTGTTGAAGTGCCTGTTCGACCTGCTGCCGCAGTACGCCCTGGCGGGCAAGACGGTGCTGCCGCTGGCCACCGGTGGCAGCAGGGCCCATGTGCTGGCCATCGACTACGCGCTGCGTCCCGTCCTGACCGCGATGGGCGCGGGGCACGTCCTGCCCGGCTGGTTCACCCTCGACACCGACCTGGTCGTCGGCGACGACGGCACACTTGTCGTCGCGCCGGCTGCCGCCGACGCGCTCTGCGAGGTCGTCGACCGGTTCGCGGCGGCGCTGCACCGCGCGGTGACCAGCGCGCCCCCGGACGGCACGGGGCGGCCGGGAATGCGCTGA",
      "translation": "MPTVLSVSGSPSATSRTAGLLRHLDRQLVADGHEVIPLDVRTLPAHVLVGADPRHPAITGVAALVAEADGLVIGTPIYKAAYSGLLKCLFDLLPQYALAGKTVLPLATGGSRAHVLAIDYALRPVLTAMGAGHVLPGWFTLDTDLVVGDDGTLVVAPAAADALCEVVDRFAAALHRAVTSAPPDGTGRPGMR",
      "product": "NAD(P)H-depedent FMN-reductase"
     },
     {
      "start": 56933,
      "end": 57829,
      "strand": 1,
      "locus_tag": "abyT",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyT</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75515.1</span><br>\n Gene: <span class=\"serif\">abyT</span><br>\n \n Location: 56,933 - 57,829,\n (total: 897 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Abhydrolase_6<br>\n \n  biosynthetic-additional (smcogs) SMCOG1004:thioesterase (Score: 197.7; E-value: 2.7e-60)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyT collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>Thioesterase</strong> (26..240)</dt>\n   <dd>\n   \n    active site serine inconclusive<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyT collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00975.23 (Thioesterase domain): [26:237](score: 118.4, e-value: 5.4e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyT collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00975.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyT\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyT\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75515.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyT\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyT\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGCGGACAGCGCGGGCGGGCACGCAACGATCGACCGGTTACCTGGACCGGACGCCGGATCCGGCGGACCGGGTGCGGCTGTTCTGTTTCCACCACGCCGGCGCCGCAGCGTCCACCTTCGCCGGCTGGGCGGAGGCGTTGCAGCCACGGGTCGCGGTCTACCCGGTGCAGCTGCCCGGCCGGGAGAACCGCGTGCGGGAGGCGCCCATCACCGATTTCGGCCGTCTGCTCGACGCCGTCGTGGACGCTGTCGAGCCGTCACTGGAACGTCCGTACGCTCTCTATGGACACAGCATGGGTGCGGCCCTGGCCGCCGCGGTGGCCCGACGGCAGGTCGAGCGGGGACGACCGCCGGTGGCGTTGTTCGTCGGCGGCTACCCGGACCCGCGCTGCGGGCCACCGCTCGCGGTGTCGGCGCTGTCCGACGACGAGGTCGCCGACCTGCTGGTGCGCATCGGGGGCATGTCCGAGGTGGTACGCCGGTATCCCGCGTGGGTGCGGACGGCGGTCCGGCTGCTGCGCGGCGACCTCGCGGCCCTGCACTCCCAGCCTCCGACCGGGCCCGATCCGGTGCCGGTGCCGGTGCGCGCCTACGTCGGCGACTCCGATCCGCTGGTGGGGCGCGCCGACGCGGTCGGGTGGGCGGCGTACACCTCGTCGTCGTTCCGGCTGCGGGTGCTGCCCGGCGGTCACCTGTTCCACCTCCGGTCGGGCGATCGGCTCCGGGCGGACATCGCGGCCTGCCTGGGCGAGCTGACCTCGCTGCCGGGCGGCAGGCCCGACGGTGGGGCGTCAGTCGATGTCGAGGACCGCCTTGCCGGCCACGCGGCGGCCGAGCAGCGCCTCGATCGCGTCGTCGACGCGCTTCCAGGAGTCCCGCCAGCCGACCGGTAG",
      "translation": "MGRTARAGTQRSTGYLDRTPDPADRVRLFCFHHAGAAASTFAGWAEALQPRVAVYPVQLPGRENRVREAPITDFGRLLDAVVDAVEPSLERPYALYGHSMGAALAAAVARRQVERGRPPVALFVGGYPDPRCGPPLAVSALSDDEVADLLVRIGGMSEVVRRYPAWVRTAVRLLRGDLAALHSQPPTGPDPVPVPVRAYVGDSDPLVGRADAVGWAAYTSSSFRLRVLPGGHLFHLRSGDRLRADIAACLGELTSLPGGRPDGGASVDVEDRLAGHAAAEQRLDRVVDALPGVPPADR",
      "product": "type II thioesterase"
     },
     {
      "start": 57728,
      "end": 58636,
      "strand": -1,
      "locus_tag": "orfU",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">orfU</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75516.1</span><br>\n Gene: <span class=\"serif\">orfU</span><br>\n \n Location: 57,728 - 58,636,\n (total: 909 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase (Score: 205.3; E-value: 2.1e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-orfU collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13602.9 (Zinc-binding dehydrogenase): [175:299](score: 47.7, e-value: 3.3e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"orfU\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"orfU\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75516.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfU\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfU\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCAAGCCCTGATCGCCGCCCCCGACACCGCCGAGGGACACCGCTTGGCCGAGGTGCCCGAGCCGGTCCCGACGCCCGGCCAGTTGCTCGTCGAGGTGAGACAGTCCTCGGTGAACTTCGGCGAGGCCCGCTTCCGTGCCGGGATGCCCGCCGGCACGGTGCTCGGTTACGACGCCGCGGGTTACGTCGTGCGGGCCGCCGAGGACGGCAGCGGTCCGGCCGTCGGCGACCGGGTGGTCGCCTTCGGTCCGGGAACGTGGGCCGAACGTGCCGTCTTCGACGTCGACAGCGTGGCGCGGATCCCCGACGGGCTCGATCTCGCCGCCACGGCGGCCCTGCCGATGGTGGGCCTCACCGCCCTGCGGACCCTGCGAGGCGCCGGCCCACTGCTGGGCCGTCGGGTGCTGGTCACCGGCGCGTCCGGAGGCGTCGGACGGCTGGCGGTTCAACTCGCCCGCCTCGGCGGAGCCACGGTGGTGGCGTCGGTCGGCTCGCCGGCGCGGGGGGAGGGGCTGCGCGACCTGGGCGCAGCCGAGGTGGTGGTCGGGCTGGACGACGTCCGCGAGCCGGTCGACGTGGTGGTGGAGACAGTCGGTGGTGACCACCTCACCCGCGCGTGGTCGCTGCTCAAGCCGGGCGGGATCTGCCAGAGCATCGGCTGGGCGTCGGGTGCGGCGGCCGTCTTCGCGCCCAACTCGACCTTCGCATTGGGCGAACCCCGGCGTCTGCAGTCCTTCGGTGACACCTCCCGCCCCGGAGCCGACCTGGCTACCCTCCTGGCCTTCGTGGCCGCCGGGGACATCTCCCTACCGGTCGGCTGGCGGGACTCCTGGAAGCGCGTCGACGACGCGATCGAGGCGCTGCTCGGCCGCCGCGTGGCCGGCAAGGCGGTCCTCGACATCGACTGA",
      "translation": "MQALIAAPDTAEGHRLAEVPEPVPTPGQLLVEVRQSSVNFGEARFRAGMPAGTVLGYDAAGYVVRAAEDGSGPAVGDRVVAFGPGTWAERAVFDVDSVARIPDGLDLAATAALPMVGLTALRTLRGAGPLLGRRVLVTGASGGVGRLAVQLARLGGATVVASVGSPARGEGLRDLGAAEVVVGLDDVREPVDVVVETVGGDHLTRAWSLLKPGGICQSIGWASGAAAVFAPNSTFALGEPRRLQSFGDTSRPGADLATLLAFVAAGDISLPVGWRDSWKRVDDAIEALLGRRVAGKAVLDID",
      "product": "Zn-dependent alcohol dehydrogenase"
     },
     {
      "start": 58727,
      "end": 59320,
      "strand": 1,
      "locus_tag": "orfS",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">orfS</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75517.1</span><br>\n Gene: <span class=\"serif\">orfS</span><br>\n \n Location: 58,727 - 59,320,\n (total: 594 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1057:TetR family transcriptional regulator (Score: 72.3; E-value: 1.1e-21)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-orfS collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00440.26 (Bacterial regulatory proteins, tetR family): [14:61](score: 34.0, e-value: 2e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-orfS collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00440.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"orfS\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"orfS\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75517.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/orfS.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfS\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfS\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGACTGAACGCGCCGACGCGGCCCGCAACCGGGCGATGATCCTGCGCGCCACCGAGGATCTATTGACGTACCGCGAAGCTATGCCGATCTCCGTCGACTCGATCGCCGCCCGGGCGGGCGTCGGCAAAGGCACCGTCTTCCGCCGCTTCGGCAGCCGGTCCGGCCTGTTCCGGGAACTCCTCGCCGAACGCGCGACGCGAATCGGAGAGCAGATCAGCCACGGTCCACCACCGCTGGGGCCCGGAGCACCGCCCGGGGACCGGCTCCTGGCCTTCCTCGATGCACTGGCCGACCTCGCCGCGACCAACGCGACCCTCCTCGCCGCCCACGCAATGGCCTGCGCCGCCGGACGGCACGACGACCCCACCTACCGACGCTGGCACGAACACCTGCGCCAGCTCGTCGGGCAACTCCGCCCGGACCTCGACGCCGGATACGTCGCCCACGTCCTGCTCGGGGCATTCGACGCCGAACTGGTCCGCCGAACCATCGCCGACGGCGGCGGCGACCGGCTCCGCGCAGCCGTAAGGGCACTCGCACGGTGCCTGCTGCCACCCGGGCCCGAGCGATCATGCCGCCCGGGCCCGTAA",
      "translation": "MTTERADAARNRAMILRATEDLLTYREAMPISVDSIAARAGVGKGTVFRRFGSRSGLFRELLAERATRIGEQISHGPPPLGPGAPPGDRLLAFLDALADLAATNATLLAAHAMACAAGRHDDPTYRRWHEHLRQLVGQLRPDLDAGYVAHVLLGAFDAELVRRTIADGGGDRLRAAVRALARCLLPPGPERSCRPGP",
      "product": "TetR transcriptional regulator"
     }
    ],
    "clusters": [
     {
      "start": 15053,
      "end": 46388,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 59320,
      "product": "T1PKS",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 6964,
       "end": 6966,
       "strand": 1,
       "containedBy": [
        "abyI"
       ]
      },
      {
       "start": 29571,
       "end": 29573,
       "strand": 1,
       "containedBy": [
        "abyB1"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "T1PKS",
    "products": [
     "T1PKS"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS T1PKS",
    "anchor": "r1c1"
   }
  ]
 }
];
var all_regions = {
 "order": [
  "r1c1"
 ],
 "r1c1": {
  "start": 1,
  "end": 59320,
  "idx": 1,
  "orfs": [
   {
    "start": 1,
    "end": 1083,
    "strand": 1,
    "locus_tag": "orfP",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">orfP</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75490.1</span><br>\n Gene: <span class=\"serif\">orfP</span><br>\n \n Location: 1 - 1,083,\n (total: 1083 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PCMT<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-orfP collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01135.22 (Protein-L-isoaspartate(D-aspartate) O-methyltransferase (PCMT)): [23:143](score: 89.4, e-value: 2.9e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"orfP\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"orfP\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75490.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfP\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfP\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCGAGCTCGACCGGGCCTTCGACGCCGTACCGGCCCCGATCTACACCCACCATGAACGGCACGGCGAAACGGTGCACCGCTCGGCACCGGAGTCGATCCGCCGCGAGCTGGCCGCCCTGCAGGTCCGCGCCGGGGACCGGGTGCTCGAGATCGGTACGGGCTCCGGGTACAGCGGCGCGCTGCTCGCGCACCTGTGCTGCCCGGACGGCCAGGTCACCAGCATCGACATCAGCGACGAACTCGTCCGCCGCGCGGCAGCCATCCACGCCGAGCGCGGGGTAACCAGCGTCGACTGCCATGTTGGCGACGGACTGGCCGGCTACCCGGCCGCAGCGCCCTTCCATCGAGCTGTTTCGTGGTGTGCTCCGCCGCGGCTGCCGAGGGCGTGGACGCAGCAGGTCGTGAACGGTGGGCGGATCGTCGCGTGCCTGCCGATCACGGCCCTGCCGTCGACCACGTTGATCGCCACCATCACCGTTGCGGCCGGGAAACCTCGTATCGAAGCCCTCGCCGGAGGCGGCTACGCCCAGAGCACGCCCGTCGCGGTCGACGATGCCCTGACCGTCCCCGGCCGCTGGGTCGACTACTGCGACCGCCAGCCCGATCCGTCCTGGATCGGCATCTGCTGGCGTTCTGCCGACGACGCCCAGCACACCGGCGCTCGCTCCGCCCTCGGCCAGCTGCTGCATCCCGGGTACACCGACACGTATCGGCAGATGGAGCCGCACTGGCGCTCCTGGTACACCTGGACGTCCGCGCTCGGCGACCCGCAGCTGAGCCTGGTGTCGCTGCGCAACGAGATCCGCGGACTCGGTCACACCACACCAAGTTCGGCGGCGGTGATCCTGACCGATGGCAGGGTCATCGCGGACCGGCCGGACTCGCCGTCCCTGCGCTCCTTGCGGACCTGGCTGCAACGGTGGGAACACGTCGGCCGTCCGGCACCCGAGTCCTTCGCCCGCACCCTGGTGCCGCACGACTGCCCTGATCTCGCCGGCTGGGACCTGCAGGTCGGCCATGGCTCCGTGACCACCGACCGGCAGCCGCCGCGGCGCGTCGATGAGCCTCGCCGCCCTTGA",
    "translation": "MTELDRAFDAVPAPIYTHHERHGETVHRSAPESIRRELAALQVRAGDRVLEIGTGSGYSGALLAHLCCPDGQVTSIDISDELVRRAAAIHAERGVTSVDCHVGDGLAGYPAAAPFHRAVSWCAPPRLPRAWTQQVVNGGRIVACLPITALPSTTLIATITVAAGKPRIEALAGGGYAQSTPVAVDDALTVPGRWVDYCDRQPDPSWIGICWRSADDAQHTGARSALGQLLHPGYTDTYRQMEPHWRSWYTWTSALGDPQLSLVSLRNEIRGLGHTTPSSAAVILTDGRVIADRPDSPSLRSLRTWLQRWEHVGRPAPESFARTLVPHDCPDLAGWDLQVGHGSVTTDRQPPRRVDEPRRP",
    "product": "protein methyltransferase"
   },
   {
    "start": 1208,
    "end": 1834,
    "strand": 1,
    "locus_tag": "AEK75491.1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AEK75491.1</span></strong><br>\n \n  putative hydrolase<br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75491.1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,208 - 1,834,\n (total: 627 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"AEK75491.1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"AEK75491.1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75491.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"AEK75491.1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"AEK75491.1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAGCCGCCGGCCAGCTCTGTCTGCCCGGTGGACACCTCGAAGATGGGGAATCGGTCGTCGCCGGCGCGATACGGGAGACGGCCGAGGAAACGGTGTGTCGAGCTGTCCGAGACGAATCTGGAGTTCGTTCATGTCGTGCACCGCCGCCACGGCCACGACGACCCGCGGCTCGGCTTCTTCTTCCTCGCCACCGCCTGGCAAGGCCAGCCGGTCAACCGGGAACCCCACAAATGCGCAGGCCTGGTCTGGACGGACCCGGCGCAGCCACCCGCCACCACGATCGCGTACACCGTGGCCGCCCTGGAACAGATCCATAGCGGGCGACCCTTCTCCCTGGACGGCTGGGCAGAGCACTCGCCCTCCGCCACGGGCTGCGGAATCGTTGATGTGGCATGGGAACCTCCCGTTCGACGAGGGCAGCGTGAACCGCGCCACCAGCATGACGACGGAGGTCGCCACGGATACACGGTCGGTCAGCCCGACCCCTGCCGTCCGCTGCTCGGGTGTCGCTCGACGGCCCACCCCACCGGTTGCCGTCCTCGCAGGAACGTCTCGTCCTGGCTGCAGCTGTCACCACGCACCCCGGGTCCGTACGCAATTTCTCTGATGTCCCGGGAACGGTGA",
    "translation": "MKPPASSVCPVDTSKMGNRSSPARYGRRPRKRCVELSETNLEFVHVVHRRHGHDDPRLGFFFLATAWQGQPVNREPHKCAGLVWTDPAQPPATTIAYTVAALEQIHSGRPFSLDGWAEHSPSATGCGIVDVAWEPPVRRGQREPRHQHDDGGRHGYTVGQPDPCRPLLGCRSTAHPTGCRPRRNVSSWLQLSPRTPGPYAISLMSRER",
    "product": "putative hydrolase"
   },
   {
    "start": 1887,
    "end": 2633,
    "strand": 1,
    "locus_tag": "abyR",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyR</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75492.1</span><br>\n Gene: <span class=\"serif\">abyR</span><br>\n \n Location: 1,887 - 2,633,\n (total: 747 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1041:transcriptional regulator, SARP family (Score: 257.8; E-value: 4.2e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyR collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00486.31 (Transcriptional regulatory protein, C terminal): [17:87](score: 36.8, e-value: 3.3e-09)<br>\n \n  PF03704.20 (Bacterial transcriptional activator domain): [93:238](score: 126.3, e-value: 1.3e-36)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyR collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyR\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyR\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75492.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyR.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyR\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyR\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGCTCGGAGCATTGCGGATCGCCGATCCCGCACCTCGCACGATTACCGCGCCGAAGGTGGAAACGCTGTTCGCCACGCTCCTCATCCGGGCCAACCACACCGTCACCACCGACGAACTCATCGCTGAGCTGTGGGGCGAGAACCCTCCCCGCCACGCCCGCACCGCGCTGCACGTCTACGTTTCGCAGATCCGCAAGCAGATCCCGAGCCCGCGCCCCGGCGCAGCGGTGCTGCACACGAAGCCGCAGGGCTACCAGATGGAGGTCGACGAGAACCTCGTCGATGCTGTCGAGTTGCAGCGGATGCACGCGCTGGGCAGGTCGTTGCTGGTAACCGACCCGGAGGCGGCCCTGGTCCCGCTGCGCCGCGCGGTCGGGCTGTTCCGGGGTCCCGTGCTCGCCGGCATCCGCAACGGCCTCGTGGTCGGTAACTTCGCCGAATGGGCCGAGGAGGTCCGCGTGGACTGCCTGCACGCCATTGGGCGGGCGGCACTGGCCACGAACCGGCATCGGGAGCTCATCGGCGAACTCGTGCAGTGGGTCGAGGAGCACCCACTGCACGAGCCGCTGCGGGAGGTGTTGATGGTGGCGCTCACCCGGGCCGGTCGCCGCGCCGAGGCGTTGGCGGCGTACCAGTCGACGCGGCGGGTGCTGCACGAGGAGCTGGGGCTTGAGCCTGGTGAGGCGATGCGCCGGCTTCAACTCGCGATCCTGAGTGCCGATGTGGGCCTGGTGCCGGCTGCCTGA",
    "translation": "MLGALRIADPAPRTITAPKVETLFATLLIRANHTVTTDELIAELWGENPPRHARTALHVYVSQIRKQIPSPRPGAAVLHTKPQGYQMEVDENLVDAVELQRMHALGRSLLVTDPEAALVPLRRAVGLFRGPVLAGIRNGLVVGNFAEWAEEVRVDCLHAIGRAALATNRHRELIGELVQWVEEHPLHEPLREVLMVALTRAGRRAEALAAYQSTRRVLHEELGLEPGEAMRRLQLAILSADVGLVPAA",
    "product": "pathway-specific SARP activator"
   },
   {
    "start": 2646,
    "end": 3836,
    "strand": -1,
    "locus_tag": "abyX",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyX</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75493.1</span><br>\n Gene: <span class=\"serif\">abyX</span><br>\n \n Location: 2,646 - 3,836,\n (total: 1191 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1007:cytochrome P450 (Score: 422.2; E-value: 3.1e-128)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyX collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [29:365](score: 95.3, e-value: 3.6e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyX collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyX\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyX\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75493.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyX\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyX\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGACGTCCAGCTGCCCGCGTTCCCGATGACCCGCACCTGTCCCCACCAGCCGCCGGAGGGCTACGCCGCCCTGCGCGAGAATGGGCCACTGGCCCAGGTCCGGCTGGTGGGCGACCGTACGGCGTGGGTGGTGACCGACCACGACGTCGCCCGGACGTTGCTGGTCGACCCGCGACTCTCCTCCGACCGGCTACGACCGGACTTCCCGGTGCTGGTGCCCCGGATGTCCGCCGCCAAGCTGGTACCACTGGTCGGCATGGATCCGCCGGTGCACACCCAGCGGCGGCGCATGCTGATCGCGGCGTTCACTGTCCACCGGACCCAGCAGATGCGCCCAGAGATAGAAGAGATCGTCAGCGCCCGTCTCGACGCGGTGCTGCAGGAGGGCCCGCCGGTGGACCTGGTGCCCACCCTGGCCCTGCCCGTACCGTCCACCGTGATCTGTCGGCTGCTGGGCGTCCCGTACGCCGACCACGACTTCTTCGAGAGCCAGACCCAGCGCATGGTGCTGGGTTCGAGCACCGCACAGGAGGCGGCCGGCGCGGCCGCCGCCCTGACCGAGTACGTCGACACGTTGATCGGGGAGAAGCAGACCAAGCCGGGGGAGGGGCTGCTGGACGAACTCATCGCGAGCCACCTCGACACAGGGCAGATCACCCGGCGGGACCTGGCAGAGACCGTCATGTTCCTACTCGTGGCAGGGCACGAGACCACAGCCAATATGATCACGATGAGCATCGTCGGCCTGCTGGAGAACCCGGAACAACTCGACCGCCTACGCTCCGACTGGAGTCTGCTCCCGAACGCGGTGGAGGAGCTGCTGCGCTACCTGTCCGTCGCCGACGAGATCCAGCGGGTGGTCGCCGAACCCATCGAGGTCGCCGGCCATGTCCTGCGCGTCGGCGACGCGGTCTACCTACCCGCCGCCGCCAGCAACCGGGATCCGGCCGCCTTCCCCGACCCGGACGCGCTGGATGTCTCCCGCCGCGCCCGTCACCACCTGGCCTTCGGCTACGGCATCCACCAGTGCCTGGGCCAGAACCTCGCCCGGGCCGAGCTGGAGGTGACGCTGCGGGCCCTGTTCGAACGACTGCCCACCCTGGCGCTGGCGGAGCCACTGTCGTCGCTGCCGGTGAAACCGGGCGGCTCGGTGCAGGGCGTGTACCGGCTGCCAGTCACCTGGTAG",
    "translation": "MTDVQLPAFPMTRTCPHQPPEGYAALRENGPLAQVRLVGDRTAWVVTDHDVARTLLVDPRLSSDRLRPDFPVLVPRMSAAKLVPLVGMDPPVHTQRRRMLIAAFTVHRTQQMRPEIEEIVSARLDAVLQEGPPVDLVPTLALPVPSTVICRLLGVPYADHDFFESQTQRMVLGSSTAQEAAGAAAALTEYVDTLIGEKQTKPGEGLLDELIASHLDTGQITRRDLAETVMFLLVAGHETTANMITMSIVGLLENPEQLDRLRSDWSLLPNAVEELLRYLSVADEIQRVVAEPIEVAGHVLRVGDAVYLPAAASNRDPAAFPDPDALDVSRRARHHLAFGYGIHQCLGQNLARAELEVTLRALFERLPTLALAEPLSSLPVKPGGSVQGVYRLPVTW",
    "product": "cytochrome P450"
   },
   {
    "start": 3927,
    "end": 6596,
    "strand": -1,
    "locus_tag": "abyH",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyH</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75494.1</span><br>\n Gene: <span class=\"serif\">abyH</span><br>\n \n Location: 3,927 - 6,596,\n (total: 2670 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1149:LuxR family transcriptional regulator (Score: 204; E-value: 7.1e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyH collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00196.22 (Bacterial regulatory proteins, luxR family): [828:884](score: 57.3, e-value: 9.6e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyH collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00196.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyH\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyH\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75494.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyH.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyH\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyH\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCGCGACACGGCAGAGCATCGGATCGGCACATCCGGGCGTCACACACCGCAGGCCCAGGCCACACCCGCAGATCGGCTGTCGCAGGCGCTCGCCCGGGCCCGCTCCGGGCGCGGTGGCGTAGTGGAACTGGTCGGTGAGCCGGGGATCGGCAAGACGCAGGCACTGACCGAGCTGACCCGGCTCGCCCGCGTGGCGGGCATCCCGATCGCCGCCGGTCGGTGCACCGAGGTGACACCGGACAGCCCGCTGACCCTCGCCGCCGCGGTGACCGGAGCCACGGGGAGTCCCGGCGAACTGGCCGATGCGTTGCGGCAGGCCGCCGATCCGGCCGGGTTGCTGGTCGCCGTCGACGACTTCCACTGGGCCGGCGAGGATTCGGTACGGCTGGTGCGGGCGCTGACCCAGACGGCGCTGGACGTCGGGCTCCTGGTCGTCATCGCACTGCGACCGACGCAGACCCACACCGGGCTGCTCGCGGTGCTGGCCGACGGCCGCGACGTCGGTGTCGTCGAGCGCGTGGAGGTGGGTCCGCTGACGCTGCCGGAGTCCGCCCGGCTGCTCGGCTGCAGCATCAAGGACCCACAGGTCCGCAGGCTGCACGAGCGGGCCGAGGGCAATCCCCGGTACCTGCTGGCACTGGCCGCTCCGCGCGGTGCCGCCGCGACGGCGCTGCTCGGCGAGAAGGCGTCACTCGGGCCGGACGCGACGCGCGTCCTGGAAGCCGCCGCCGTGCTGGGTGGCTCGGTGGACGTCGCCGGCGTCGCCGAGGTGGCCGGTCTGCCGCGCGAGCGCGCCTGCGCGGCCACCAGCGTGCTGGTCCGCCGTGACCTGCTGCGCCCGTCCGACCGGCCGCGGGAGTACGTCTTCCGACATCCGGTGCTGCACACGCTCTACTACGACGACATCGACATCTGCTGGCGGGCGGCGGCGCACCGCCGGGCGCGGACCCTGCTGTTGTCACGTGGCGCCCCGCACAGCGTGGTGGCTCCGCACGTCGAGCGGGCACCGCAGGGCTCCGACGAGGATCTGACCGTGCTGGCCGGCGCGGCACAGGAGGCCATGGCGGGCACTCCCGCACAGGCCGTGCGCTGGCTACGGGTGGCGTTGGATCTCGCGCCGGCCGGTGCCCACGCCCGCAACGAGCTTGCCTCCGCCCTGGTCGGCGCGCTGCTCGCGTCGGGGCAGCCCACCGCCAGCAGCGTTCTGCTGCACCAGATCCTGCGGTCCGACCCGCCGCTGTCCTGGGAGGCGCGAGCCCACGCGCTGGTGCCCGGCGCCCTGGCCGAGTGCCTGCTGGGGCGGGCCCGCGAGGGCGGCAGCCTCATCGCCGCCGCACTGGCCGAGGCCCCCGAGGATCCGCCTGCGGTGCTGGTACGCCTCGCGGTCGTGCAGGGCGTGCTGGCGAGCCTGGAGGGAGTTGCGCTGACTCCCGGCGTGGCGGACGTCGCGCTGCGGGTGGCACGCGTACACGGCGACCGGCTCGGCGAGATGGGCGTCCTGTCCGTCCGCGCCTTCGGCGCCGGTGGCGGCGCCGCCAGCGCGGCGGACCTGTCGGCGGCCGCCGCCATCGCGGACGCGGCGGCCGACCCTGACCTGGCCGCAGATCCCGAGTGCCTGGTCATGCTGGCCTCGGCCGAGTCGTACAGCGGCCGATACCGCGACGCACGCCGTCACGCCGCACGCGGCGTGACGGTGATCCGGCGCAGCGGGGGCCGCCACCTGCTCCCGCTGCTCTACAACACGCTGAGCAACAGCTGCCGAAGGCTGGGCGAGTTGGACGCCGCGCAGGAGGCGGCCGCCGAGGCCGCGCGGATCGCGGAGCAGATGGGTGCGTGGCGACTGCACGGGCTGGCGCTGGCGCTGCGTTCGCTCAGTCTCGCCTGGCTGCTGCCGCAGGGCGACCGGGAGCCGGTCGACCTGGCGGAGCAGGCAGCGGCGATCCTCCCACCGGGCAGCTCGACGTGGAGCGCCACGGCCGGGCTGGCGTTGGCACAGGCGGCCCTGGCCGGCGGCGACCCCCGTCGGGCCGTGACCGTCATCCTGGACTTCGGTGGTGGTCCGGGCCTGGACGACATCCCCGACGTGCTGCGTCCGTGGAGCTACGAACTCCTGGCCGCCGCCTCCGGCCGGGCCGATCTTCCCCTGGCGGAGTGGGCGAGCCGCGCCGCGGCGGTCGTGGACCGGATGGGCGTGCCCTACCTACGGCCCTACGCCGTCTCCGCCCGCGCCCACCTGCTGCGCTCGCGCAACGACCTGGCCGGCGCGACCGCGCTCTTCCGCGAGGCCGCCGCGCTCTTCCACACCGCCGGTCTGGCCTTCTCCCAGGCCGTCGCCCTGGCCGAAGCGGCCCGTTGCCAACCCGGCGCGGGCCGGGCTGACCTGGCCCTCGCCCGGGAGGTGGCCCGGCGCTGCGGCGCAGGCCGAGCCCTGGCCGAATACCGCACCCGCCCGTCGGTGACGGAGGTGACCCACCCGATGCTGTCCGTCCTCACGCGACGCGAGCAGGAGATCGCGTCGATGGCGGGCACCGGTCGCAAGACCAAGGACATCTCCAACAGCCTGGCGATCAGCCCCCGCACCGTTGACGTCCACCTCACCCGCATCTACCGCAAGTTGAACATCGCCACCCGCGCCGAGCTGGCCCGGCTCATGGCGAGCATCGCCTGA",
    "translation": "MRDTAEHRIGTSGRHTPQAQATPADRLSQALARARSGRGGVVELVGEPGIGKTQALTELTRLARVAGIPIAAGRCTEVTPDSPLTLAAAVTGATGSPGELADALRQAADPAGLLVAVDDFHWAGEDSVRLVRALTQTALDVGLLVVIALRPTQTHTGLLAVLADGRDVGVVERVEVGPLTLPESARLLGCSIKDPQVRRLHERAEGNPRYLLALAAPRGAAATALLGEKASLGPDATRVLEAAAVLGGSVDVAGVAEVAGLPRERACAATSVLVRRDLLRPSDRPREYVFRHPVLHTLYYDDIDICWRAAAHRRARTLLLSRGAPHSVVAPHVERAPQGSDEDLTVLAGAAQEAMAGTPAQAVRWLRVALDLAPAGAHARNELASALVGALLASGQPTASSVLLHQILRSDPPLSWEARAHALVPGALAECLLGRAREGGSLIAAALAEAPEDPPAVLVRLAVVQGVLASLEGVALTPGVADVALRVARVHGDRLGEMGVLSVRAFGAGGGAASAADLSAAAAIADAAADPDLAADPECLVMLASAESYSGRYRDARRHAARGVTVIRRSGGRHLLPLLYNTLSNSCRRLGELDAAQEAAAEAARIAEQMGAWRLHGLALALRSLSLAWLLPQGDREPVDLAEQAAAILPPGSSTWSATAGLALAQAALAGGDPRRAVTVILDFGGGPGLDDIPDVLRPWSYELLAAASGRADLPLAEWASRAAAVVDRMGVPYLRPYAVSARAHLLRSRNDLAGATALFREAAALFHTAGLAFSQAVALAEAARCQPGAGRADLALAREVARRCGAGRALAEYRTRPSVTEVTHPMLSVLTRREQEIASMAGTGRKTKDISNSLAISPRTVDVHLTRIYRKLNIATRAELARLMASIA",
    "product": "LuxR family transcriptional regulator"
   },
   {
    "start": 6952,
    "end": 7710,
    "strand": 1,
    "locus_tag": "abyI",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyI</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75495.1</span><br>\n Gene: <span class=\"serif\">abyI</span><br>\n \n Location: 6,952 - 7,710,\n (total: 759 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1041:transcriptional regulator, SARP family (Score: 257.6; E-value: 4.6e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyI collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00486.31 (Transcriptional regulatory protein, C terminal): [22:83](score: 34.9, e-value: 1.4e-08)<br>\n \n  PF03704.20 (Bacterial transcriptional activator domain): [94:240](score: 136.6, e-value: 8.4e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyI collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyI\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyI\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75495.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyI.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyI\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyI\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCTACGAATTACTCGGACCACTACGACTGGTGGGCGTGGACACCCGTACACCGGTCAACGCGCCCAAACAGCAGGCGTTGTTGACCACGCTGCTGATTCGCTCCGACCAGGTCGTCGGCAGTGAGCACCTCGGCACCGAACTCTGGGGCGAGCGCCCTCCGCGGCGCGCGCAGGCCGCCCTGCACGTGCACGTGTCCCAGGTGCGCCGCCTGCTCCCGGCAGGTCGGCTCGCGACCGTCACAGGCGGCTACACGCTGCGGATCCGGGCCGGTGACGAGGTCGACGCCCACGAGTTCCGCGCGCTGTCCGAGCGGGGGCGGGCGCATCTGCGCGCGCGCCGGTACCGGGAGGCGGTGGCGTGCTTGGAACGGGCATTGACGCTGTGGCGGACCGGCCCGGTGCTGACGTTGGCCGGCGGGCGGACCGTCGCCGTCTTTGCCCGCTGGCTGGAGGAGACCCGGTTGGAGTGCCTGGAGATGCTCGTGGAGGCGCGACTCGCGCTGGGCGGGCACCAGGAGGTGGTCGACCTGCTGACCGCGGTGCTGGCCGACCATCCACTGCACGAGAACTTCCACCGGCAACTGATGGTCGCGCTGGTCCGCGCCGGACGATGGACCGACGCGTTGCGCGCCTACCAACACACGCACCGGCTGCTCCGCGAGGAACTCGGGTTGGAGCCGGACCGGTCGCTGCGCGAGTTGCACCACTGGATCCTGCGGGCCTACCGGCGGCGGGAGGTAGCCCAAGCCTGCTGA",
    "translation": "MRYELLGPLRLVGVDTRTPVNAPKQQALLTTLLIRSDQVVGSEHLGTELWGERPPRRAQAALHVHVSQVRRLLPAGRLATVTGGYTLRIRAGDEVDAHEFRALSERGRAHLRARRYREAVACLERALTLWRTGPVLTLAGGRTVAVFARWLEETRLECLEMLVEARLALGGHQEVVDLLTAVLADHPLHENFHRQLMVALVRAGRWTDALRAYQHTHRLLREELGLEPDRSLRELHHWILRAYRRREVAQAC",
    "product": "pathway-specific SARP activator"
   },
   {
    "start": 8175,
    "end": 10034,
    "strand": -1,
    "locus_tag": "abyK",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyK</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75496.1</span><br>\n Gene: <span class=\"serif\">abyK</span><br>\n \n Location: 8,175 - 10,034,\n (total: 1860 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyK collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05593.17 (RHS Repeat): [131:167](score: 26.5, e-value: 7.4e-06)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyK collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [90:119](score: 19.2, e-value: 0.00031)<br>\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [131:167](score: 31.0, e-value: 5.4e-08)<br>\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [238:280](score: 33.4, e-value: 9.6e-09)<br>\n \n  TIGR01643 (YD_repeat_2x: YD repeat (two copies)): [309:335](score: 18.6, e-value: 0.00048)<br>\n \n  TIGR03696 (Rhs_assc_core: RHS repeat-associated core domain): [501:572](score: 40.1, e-value: 9e-11)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyK\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyK\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75496.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyK\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyK\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCGCTCCGTCGACGCCATGCGTTTTGCTGTCCGCGCCGCGGCGAGTTGCCCGAGACCACCCGACCGAGAGGTCCTCGCATGACCCTTGCCCATGAACGAGCGGACGGGCGGAGCCTGGTGTCTCGCCACCCGGACCGCCCGGACCTGCCCCTGTCGCTGGCCGACGCCGCCGGCAACCGGGTGGACTACAGCTACGACGACGGCGGGCGGCTGCTGCGCGCCTACTCCCGGGCCTTCGACCGCGACATCGAGACCCGGACCTACCACCCGGACGGATCGCTCGCCTCGGCCACCGACGGTCGGGGCGCGACCACGGGGTACCACTACGACGGGCGTGGACGCCTGGTCGCCATCGACCCGCCCGAGCCGCTCGGCCAGATCCGCTTCGCCTACGACGACGATTCCCGCGTCGTCCGGGTCACGCACGGTAACGGCCAGCGCGTCGGCTTCACGTACGACGCGTCGGGTCGACTGGTCGAGGTCCGTGACGACGACACCGGCCAGGTGCTCGGGGACTTCGCCCACGACTCCGCCGGCAACCTGACCCACCGGTCCGGCCCGGGCTGGTCGGAGTCGATCCAGTGGCGTGACGGCCGGCGCATCGGCTCGGTCCGGCGCGAGGGCCGCGAGATGGAACAGGTCGGCTACCGCCACACCGCCTCCGGTGCGCTGGCCGCCCAGTTGGACCTCAACGGCACCACCACCTACGGTTACGACGCCGCCGGTCGGCTCGCGGTGCTCGACGACCCGTTCGGTGGCCGGACGAGCTTCGAGTACGACGGCGCCGGGCGGCGTACGGCCACGGTCTTCGCGGGCGGGGGCAGCCAGCGCACGGAGTACGACGCGCTGGGCCGGCCGGTGCGCCTCGTGGTGGCCGACGGGCGGGGCGACCCGGTCCACACGGTGTCGTACGACTACGGCGGTGGTGCCCTGCTCGCCGCCCGCACCGTCGACGGCGTGACCACCGAGTACGCCTACGACGGCCTGGGCCGGGTGGTCCGCGCCGGTGACGAAGAGTTCGGCTACGACCTGGCGAACAACCTGATCCGACTCGGTGGCACCACGTTCGACGTCAACGACGCCGGGCAGCACGTGCGCTTCGGTGAGACGGTCCTCGGCTACGACCGGTCGGGCAACTTCGTCGACGAGGTGAATCCGACGGTGCGCTTCACCTACAGCCCGACCAACCAGACCCGTACCGGGTCGGTCGACGGCCGGCAGGTGGTCGACATCCGCTACGACGGTCTGGACAATCGCGAGCCACGCCGGATCCACGAGACCACGCTGGACGGGCGGTCGGTGACCCACGTTCTGCACCGCACGTCGCTGGGCATCGTCCGGGTCACCGACGACGTACCCACGGCGTTCGTCAGGGAGCCCAGCGGCCGGCTGATCGGGTTGCGCACGGCGGACGGGACCCGCTACCAGGCGGTCACCGACCACCAGGGATCGGTGTTGGCGCTGCTGGCCACGGACGGGACGCTGGCCGCCACCTACACCTACAGCGCGTTCGGCGCGGTCACCGCGACCAGCGGCGTCGCGGCCGTCAACCCGTTCCGCTACCTGGGCGCCTACCAGTTGCTGCGGGGCGCCCACTTCCTGGAGTGCCGCATCTACAACGGGGCATGGGGGCGGTTCACCCAGCCGGATCCGCGGCACCAGGCCCGCGCCCCGTACACCTTCGCAGACAACGACCCGGTGAATTTGGGCAACCCGGCCCGCACCAATTTCTGGGCGACGCTGTCGCGGCCGCCGCGGGAGGCGGTCGCGGCGTTCCACGGCACCCCGCCCCCGCCGACGACGTTTCTCGGCACCGGCATTCCGTTCATCACCCGACGAGGAGACGACAATGACTGA",
    "translation": "MALRRRHAFCCPRRGELPETTRPRGPRMTLAHERADGRSLVSRHPDRPDLPLSLADAAGNRVDYSYDDGGRLLRAYSRAFDRDIETRTYHPDGSLASATDGRGATTGYHYDGRGRLVAIDPPEPLGQIRFAYDDDSRVVRVTHGNGQRVGFTYDASGRLVEVRDDDTGQVLGDFAHDSAGNLTHRSGPGWSESIQWRDGRRIGSVRREGREMEQVGYRHTASGALAAQLDLNGTTTYGYDAAGRLAVLDDPFGGRTSFEYDGAGRRTATVFAGGGSQRTEYDALGRPVRLVVADGRGDPVHTVSYDYGGGALLAARTVDGVTTEYAYDGLGRVVRAGDEEFGYDLANNLIRLGGTTFDVNDAGQHVRFGETVLGYDRSGNFVDEVNPTVRFTYSPTNQTRTGSVDGRQVVDIRYDGLDNREPRRIHETTLDGRSVTHVLHRTSLGIVRVTDDVPTAFVREPSGRLIGLRTADGTRYQAVTDHQGSVLALLATDGTLAATYTYSAFGAVTATSGVAAVNPFRYLGAYQLLRGAHFLECRIYNGAWGRFTQPDPRHQARAPYTFADNDPVNLGNPARTNFWATLSRPPREAVAAFHGTPPPPTTFLGTGIPFITRRGDDND",
    "product": "YD repeat protein"
   },
   {
    "start": 10118,
    "end": 11143,
    "strand": 1,
    "locus_tag": "abyA1",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75497.1</span><br>\n Gene: <span class=\"serif\">abyA1</span><br>\n \n Location: 10,118 - 11,143,\n (total: 1026 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) fabH<br>\n \n  biosynthetic-additional (smcogs) SMCOG1084:3-oxoacyl-(acyl carrier protein) synthase III (Score: 291; E-value: 1.7e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA1 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08545.13 (3-Oxoacyl-[acyl-carrier-protein (ACP)] synthase III): [118:198](score: 43.0, e-value: 3.4e-11)<br>\n \n  PF08541.13 (3-Oxoacyl-[acyl-carrier-protein (ACP)] synthase III C terminal): [253:325](score: 29.7, e-value: 6e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyA1 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08545.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004315' target='_blank'>GO:0004315</a>: 3-oxoacyl-[acyl-carrier-protein] synthase activity<br>\n  \n   PF08545.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006633' target='_blank'>GO:0006633</a>: fatty acid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75497.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyA1.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCAGGACCGTCTCGGTACTCTCGGCGGCCTCGGCGCTGCCCGGGCCGACGGTGGACAACGCGACGCTGGGCCGGCGGCTGGGCATGGACCGCCTGTGGGAGCAGTGGGTCGACGCCTTCATCGGCACCCGTACCCGCCACCTCGCCGTCGATCTGGACAGTGGCGAGATCCGGCACACGCTGGCCGACCTGGCCCACCAGGCCGGAAGCCGGGCTCTCGACGCCGCGGGTGTCACGCCCGAGGAGGTCGACCTGGTGGTGCTGGGCACCGCCACACCGGACCGCCTGATGCCGACGACAGCCACCGTGGTAGCCGACCGGTTGGGCATCGACGGGGTGCCCGCCTACCAGCTCCAGTCCGGCTGCTCGGGTGCCGTGCAGGCCCTGGCCGTCACCCGCAGCCTGCTGCTCGGCGGCACCGCACGCACCGCCCTTGTGCTCGGCGGGGACGTGGTGGCCCGGTTCTACGACCTGACCGCCGACCTGCGGAAGCTGCCGCCCGCGGAGTTCGTCAACTACGTCCTGTTCGGCGACGGCGTCGGGGCCGCGGTCCTGCGGGTCGGCGAGGTCGCAGGCGCGGCGGCGCTGCGCTCGGTCTTCACCCGGCTGGTCGGCCTCGGTCGGGAACCCGGCGCGACACTGGAGTGGTTCGGGCCGACCGAGGACCGCAACCGGCCCGCGGCGACCGAGGACTACAAGGCCATCGAGCGCCACGTGCCGGACCTGGCCGCCGAGGTCGTCGAGGAGCTGCTCGGCGAGTTGGGCTGGGCGCGCGACGACCTCGACTACGTGCTGCCGCCACAACTGTCCGGCCGGATGACCGCGCTGATCGTGGAACGCCTGAAGCTGCCGCAGGCCACCGAGGTGAGCTGTGTGGCGGAGACCGGCAACAACGGCAACGGAATCGTCTTCCTCCAGCTCGAACGGGCGCTCGCCCGACTCGCCGGGGGACAGCGGGCGCTGGGTGTGTCCATCGAGTCCAGCAAGTGGATCAAGTCGGGCTTCGCGTTGGAGGGCCTGTGA",
    "translation": "MTRTVSVLSAASALPGPTVDNATLGRRLGMDRLWEQWVDAFIGTRTRHLAVDLDSGEIRHTLADLAHQAGSRALDAAGVTPEEVDLVVLGTATPDRLMPTTATVVADRLGIDGVPAYQLQSGCSGAVQALAVTRSLLLGGTARTALVLGGDVVARFYDLTADLRKLPPAEFVNYVLFGDGVGAAVLRVGEVAGAAALRSVFTRLVGLGREPGATLEWFGPTEDRNRPAATEDYKAIERHVPDLAAEVVEELLGELGWARDDLDYVLPPQLSGRMTALIVERLKLPQATEVSCVAETGNNGNGIVFLQLERALARLAGGQRALGVSIESSKWIKSGFALEGL",
    "product": "3-oxoacyl-ACP synthase III"
   },
   {
    "start": 11140,
    "end": 13008,
    "strand": 1,
    "locus_tag": "abyA2",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75498.1</span><br>\n Gene: <span class=\"serif\">abyA2</span><br>\n \n Location: 11,140 - 13,008,\n (total: 1869 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1256:FkbH like protein (Score: 445; E-value: 2.5e-135)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyA2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01686 (FkbH: FkbH domain): [262:589](score: 293.8, e-value: 3.5e-88)<br>\n \n  TIGR01681 (HAD-SF-IIIC: HAD phosphatase, family IIIC): [264:386](score: 60.0, e-value: 9.8e-17)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75498.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACGGCGGGTGCCGCGGCCCCGTCCGCCACCGGGTCGGACGCGGCGGCTGAGCTGTCCGAGCTGTACCGCAGCGGCCGGCTGCCCACCGAATTCCCCCGCCTGCGCGCGCTGCTCGCCGAGCTGCCCGACACCGAGCTGCACCGGGCGGGTCGGCTGCTCGAACGGGTGGGCCCCGACGCGGTACGGGCGGCGCACCCGGACGTGCCGGTCGTGCCGATCACCGTCAGCGGGTACGGCACGGTGGCCCCGCTGGTCCCGCTGCTCACCGTGGAGTTGGCCCGGCACGGCCTGCTGCTCGATCCCCGGCTCGGGGACTTCGGCGGCTACCTGGACGCACTCGCCGCCCCGGACGACTCGTCGCTGCTGCTGACCCTGCTCGACGCCCAGGTCGTCTTCGACCAGGTGCCGACACCGTGGCGTCCCGAGGACGTGGCCCACACCTTCACCGCGAAGATCGACCTGATCGAGGGGCTGCTGGCCCGCTCGACCACCCCCGTGGTGCTCAACACGATCCCCCTGCCGAGGATCTTCCCCGCCCAACTGATCGACCACCGGTCCCGCGCCCTGCTCGGCGCCGTGTGGCGGGAGGCGAACGCCCGCCTGCTGCGGCTGTCGCAGGACCACCCGACCGTCGTGGTCGTGGACCTCGACCCCTGGGCGGCGACCGGGCTCGCGGTCCGCGACGCCCGGCTCAGCGTCTACGCCAAGGCGCACCTGACACCGCCGCTGCTGCACGCCTACGCCCGCGAGGTCGCCCACCTGGCCCGGGCCCGTGCCGGCGCGGCCCGCAAGGTGCTCGCCCTGGACCTGGACGAGACCGTCTGGGGAGGGGTCGTCGGCGAGGTCGGCCCGCTCGCCGTCGAGGTGGCCGACAGCCACCGGGGCGAGGCGTTCCGCGAGTTCCAGCGGGTCGTCCGCCAGCTCGGGTCGCAGGGTGTGCTGGTCGCCGCGGTGAGCAAGAACGACCCCGAGCCGGTACGCGAGGCGCTGCGCGCGCACCCAGGCATGACACTGCGGGAGGACGACTTCGTCCGGGTCGTGGCGAACTGGCGGCCCAAGCACGAGAATCTGCGCACCCTCGCCGAGGACCTCAACCTCGGGCTCGACAGCGTCGTCTTCGTCGACGACAGCCCGTTCGAGCAGGGCCTGGTCCGCCGCGAACTGCCCGAGGTGGCGGTGGTCGCCGTCGACGACGAGCCGGCCGATCACGTCGGACGGCTGCTCGCCGACGGCTGGTTCGACACCGTGACGCTGACGGCGGAGGACCGGCAACGACCCGGTCTGTACCGCGCGGAGGTGGAGCGCCGCGACTTCTTGCACTCCTTCGACTCGCTGCGCGACTACCTGGCGGAGCTCAAGGTACGGGTGGACCTGGCCGTCGCCGACGAGACCGACGTGCCCCGCGTCTCGCAGTTGACGCTGCGGACCAACCAGTTCAACCTGACCACCCGGCGACTGGCGCCCGCCGACGTGCTCGCTCTGCTGCGCCACCCCGCCGCAACCGTGCTCACGGTGCGCTGCGCCGACCGTTTCGGCGACATCGGGCTCGTCGGCGCGGTCGTCCTCCGCCACGACGACGACGTCCTGCACGTCGACAACTTCGTGCTGAGCTGCCGGGCCTTCTCCCGCGGGGTGGAGACGGCGACGCTGGCCGAGATCCTGCGCCACGCACGCGGCAGCAGCGCGTCCGCCGTCACCGCCGAGTACCTGCCCAGCCGTCGCAACGCCAAGGTGGCCGACTTCTACCCCCGCAACGGGTTCACGCGTCTCGACGCCACCCACTTCCGGCACGACCTGACCGACATGCCCCGACCGCCGGAACACGTCCAGTTGACCGGCTCCTGGCCCCCCGGAGGAACCCCGTGA",
    "translation": "MTAGAAAPSATGSDAAAELSELYRSGRLPTEFPRLRALLAELPDTELHRAGRLLERVGPDAVRAAHPDVPVVPITVSGYGTVAPLVPLLTVELARHGLLLDPRLGDFGGYLDALAAPDDSSLLLTLLDAQVVFDQVPTPWRPEDVAHTFTAKIDLIEGLLARSTTPVVLNTIPLPRIFPAQLIDHRSRALLGAVWREANARLLRLSQDHPTVVVVDLDPWAATGLAVRDARLSVYAKAHLTPPLLHAYAREVAHLARARAGAARKVLALDLDETVWGGVVGEVGPLAVEVADSHRGEAFREFQRVVRQLGSQGVLVAAVSKNDPEPVREALRAHPGMTLREDDFVRVVANWRPKHENLRTLAEDLNLGLDSVVFVDDSPFEQGLVRRELPEVAVVAVDDEPADHVGRLLADGWFDTVTLTAEDRQRPGLYRAEVERRDFLHSFDSLRDYLAELKVRVDLAVADETDVPRVSQLTLRTNQFNLTTRRLAPADVLALLRHPAATVLTVRCADRFGDIGLVGAVVLRHDDDVLHVDNFVLSCRAFSRGVETATLAEILRHARGSSASAVTAEYLPSRRNAKVADFYPRNGFTRLDATHFRHDLTDMPRPPEHVQLTGSWPPGGTP",
    "product": "phosphatase and glyceryl transferase"
   },
   {
    "start": 13005,
    "end": 13241,
    "strand": 1,
    "locus_tag": "abyA3",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75499.1</span><br>\n Gene: <span class=\"serif\">abyA3</span><br>\n \n Location: 13,005 - 13,241,\n (total: 237 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00550.28 (Phosphopantetheine attachment site): [9:73](score: 34.8, e-value: 1.6e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75499.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCACCCTGCGATCCGTCCACGACTTCGTCACCCTGGTCCGCGACGAGCTTGGGCTGCCCATCGAGGAGAGCGACCTCGACCGCCACCTCGACGACGTCGCCGGATGGGACTCCGTCCACCTGCTCGCGCTCTGCTCGGCGCTGGAGCGCGCCACCGGGCGGTCCATCTCGCTCCCGGCCGTCCTGACCGCCGACAGCCTGGGCGGGATCTACGCGACGGCGGTGGATCGGTGA",
    "translation": "MSTLRSVHDFVTLVRDELGLPIEESDLDRHLDDVAGWDSVHLLALCSALERATGRSISLPAVLTADSLGGIYATAVDR",
    "product": "acyl-carrier protein"
   },
   {
    "start": 13238,
    "end": 13993,
    "strand": 1,
    "locus_tag": "abyA4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75500.1</span><br>\n Gene: <span class=\"serif\">abyA4</span><br>\n \n Location: 13,238 - 13,993,\n (total: 756 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA4 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00198.26 (2-oxoacid dehydrogenases acyltransferase (catalytic domain)): [164:250](score: 64.0, e-value: 1.5e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyA4 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00198.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75500.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCAGCGTCTCCCCCGTCGCCCGCGAGCGCCGGCACACCCTCTTCTTCCTGGAGGCCGTGCGGTCCTTCGCGCCCGTGCACCTGGACGCCGAGGTGGACATGAGCCGCGTCCTGGCCGAGCGGAACCGGGCGCGGGCGGACGGACGGCGGCAGTCGATCGTCAGCCACGTCGTCGTGGCGGCGGGCCGGGTGCTCGCCAAGCATCCCGAGGCCAACGCCGCGATCCAGGGCCGGCTGCGCGCCCGGGTGGCCCGGTACCCGTTCGTGCACGCCAAGGTCACCGTGGACGGTGTCCTCAACGGGGCCCGCGTCGTCCTGGCGACCGTGGTGCCGAATGTCCACGAGGCCGATGTGGACCAGGTGCAGGCCCACCTGAGCCGGATCCGCGCCGTCGACCCGGAACGCGCTCCCGAGTTCGCGGGCATCCGTCGGGTGCACGCCTCGGCCCTGCCGCTGGCGTACGCCCGGTTCCGGCGGGCCGTGCGCGACCTGCGCGTCCGCCCGCTGCTCACCGGCACCGTCGCGGTGACCTCCCTCGGGCACCGCGACGTCGACGGCTTCCACTCCGTCGGGGGCACCACGGTGACGATCGGCGTGGGACGTGTCGCCGACCGGCCGGTGGTCCGTGACGGCCAGATCACCGTCGCACCCGTGCTGCGCCTCAGCCTGACCTTCGACCACCGCGTCATCGACGGGGCGGAAGCGGCCGACGTGCTGACCGACCTCAAGCAGGAACTGGAGAACCCGGCATGA",
    "translation": "MTSVSPVARERRHTLFFLEAVRSFAPVHLDAEVDMSRVLAERNRARADGRRQSIVSHVVVAAGRVLAKHPEANAAIQGRLRARVARYPFVHAKVTVDGVLNGARVVLATVVPNVHEADVDQVQAHLSRIRAVDPERAPEFAGIRRVHASALPLAYARFRRAVRDLRVRPLLTGTVAVTSLGHRDVDGFHSVGGTTVTIGVGRVADRPVVRDGQITVAPVLRLSLTFDHRVIDGAEAADVLTDLKQELENPA",
    "product": "pyruvate/2-oxoglutarate dehydrogenase"
   },
   {
    "start": 13990,
    "end": 15057,
    "strand": 1,
    "locus_tag": "abyA5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyA5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75501.1</span><br>\n Gene: <span class=\"serif\">abyA5</span><br>\n \n Location: 13,990 - 15,057,\n (total: 1068 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyA5 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06500.14 (Esterase FrsA-like): [45:283](score: 46.8, e-value: 1.9e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyA5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyA5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75501.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyA5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAACGACGTCGCAGAGCTGAAGCAGTACGTCCTCGCCCACGTCAGTGCCCAGAACGCCAGCGCGGACGGCGTGCTCGCCCGCATCGACGACGACGGCGACGGGCCCCGTTCCTGGACGACACAGTGGATCCGCGCCGGCGAGGAGCGGGAACAGGCGGGTGACCTGCTCGCCGCCACCACCTTCTACAACCTGGCCCGCTTCCCCTTCGTGGACTCACCGGGCCGGGCCGAGGCGCTGCGGCGCTGCGTGGCGGTGTTCGACCGGTGGCGTCGTACCGTGCCGGGGATCGAACGCCTGGAGCTGCGACTGCCCGGCGGTGTGGTCCGGGCCTGGGCCGCCGGGCTGTCCACGACCGAACGCCGTCCGGTGCTGCTGATGACCGGCGGCATCGTCAGCATCAAGGAGCAGTGGGCGCCGATCCTGCCGGAGCTGGCGCGCTACGGCTTCGCCGCCGTGGTCACCGAGCTACCGGGCGTCGGCGAGAACGAGCTGCGCTACGACCTGGACAGCGCCGCCCTGTTCGGCGTGCTGCTGGACGCCGTGGCCGAACGCGCGGACACCTCCCGGGCGTACGCGTTGGCGCTGAGCTTCAGCGGGCACCTGGCGCTGCGCGCGGCACCGTCCGAACCCCGACTGCGCGGAATCGTCACCGCCGGCGCACCGGTCGCGGCCTTCTTCACCGACAAGGAGTGGCAGGCGGCGGTGCCCCGCGTCACCGTGGACACCCTGGCCCGGCTGACGCAAACCACCCCGGCGACGGTCTTCGACCACGTCCGCAACTGGGCCCTGACCCCGCAGGACCTGGCCGGGGTACGGATCCCGGTGGCGTACGTGGCCAGCGGACGCGACGAGATCATCCCGCCCGCCGACCCGGCCCTGCTCCGCACGCACGTTCGCGACTTCCGGACGATCACCCACGACGACGTGCACGGCTCACCCGCGCACTTCCCGCACACCCGGCTCTGGACCCTCGCCCAGGTACTCGAGATGAGCGGCGCCGACCCACGGCACCGGGCGGCGGTCGACGGCGCGCTCGCCCAGGTCGAGGGAGGACGGGCGTGA",
    "translation": "MSNDVAELKQYVLAHVSAQNASADGVLARIDDDGDGPRSWTTQWIRAGEEREQAGDLLAATTFYNLARFPFVDSPGRAEALRRCVAVFDRWRRTVPGIERLELRLPGGVVRAWAAGLSTTERRPVLLMTGGIVSIKEQWAPILPELARYGFAAVVTELPGVGENELRYDLDSAALFGVLLDAVAERADTSRAYALALSFSGHLALRAAPSEPRLRGIVTAGAPVAAFFTDKEWQAAVPRVTVDTLARLTQTTPATVFDHVRNWALTPQDLAGVRIPVAYVASGRDEIIPPADPALLRTHVRDFRTITHDDVHGSPAHFPHTRLWTLAQVLEMSGADPRHRAAVDGALAQVEGGRA",
    "product": "AbyA5"
   },
   {
    "start": 15054,
    "end": 32399,
    "strand": 1,
    "locus_tag": "abyB1",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyB1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75502.1</span><br>\n Gene: <span class=\"serif\">abyB1</span><br>\n \n Location: 15,054 - 32,399,\n (total: 17346 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: mod_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: hyb_KS<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 300.4; E-value: 3.6e-91)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyB1 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (7..415)</dt>\n   <dd>\n   \n    found active site cysteine: False, scaffold matched GSSS: False<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (510..791)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (866..937)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (956..1378)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (1477..1760)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (1824..1976)</dt>\n   <dd>\n   \n    catalytic triad H,G,P found: False<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (2189..2365)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (2541..2963)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (3061..3344)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (3404..3560)</dt>\n   <dd>\n   \n    catalytic triad H,G,P inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (3802..3980)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (4055..4127)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (4146..4569)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (4661..4926)</dt>\n   <dd>\n   \n    Malonyl-CoA specific<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (4998..5149)</dt>\n   <dd>\n   \n    catalytic triad H,G,P inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (5407..5582)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyB1 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [5:243](score: 268.2, e-value: 7.9e-80)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [250:366](score: 125.1, e-value: 1.5e-36)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [368:475](score: 70.3, e-value: 1.9e-19)<br>\n \n  PF00698.24 (Acyl transferase domain): [509:811](score: 200.6, e-value: 4.8e-59)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [869:935](score: 47.6, e-value: 1.7e-12)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [954:1205](score: 306.6, e-value: 1.5e-91)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [1212:1328](score: 147.5, e-value: 1.7e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [1330:1446](score: 63.6, e-value: 2.3e-17)<br>\n \n  PF00698.24 (Acyl transferase domain): [1476:1775](score: 193.0, e-value: 9.6e-57)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [1824:2071](score: 147.1, e-value: 6.9e-43)<br>\n \n  PF08659.13 (KR domain): [2189:2365](score: 179.4, e-value: 6.6e-53)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [2452:2519](score: 49.3, e-value: 5.1e-13)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [2539:2790](score: 311.5, e-value: 4.8e-93)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [2797:2913](score: 146.6, e-value: 3.2e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [2915:3030](score: 61.1, e-value: 1.4e-16)<br>\n \n  PF00698.24 (Acyl transferase domain): [3060:3359](score: 193.0, e-value: 9.6e-57)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [3404:3663](score: 135.0, e-value: 3.3e-39)<br>\n \n  PF08659.13 (KR domain): [3802:3980](score: 210.2, e-value: 2.3e-62)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [4056:4123](score: 46.0, e-value: 5.3e-12)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [4144:4396](score: 299.5, e-value: 2.2e-89)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [4403:4519](score: 146.6, e-value: 3.2e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [4521:4611](score: 41.8, e-value: 1.4e-10)<br>\n \n  PF00698.24 (Acyl transferase domain): [4659:4926](score: 175.9, e-value: 1.6e-51)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [4998:5252](score: 119.8, e-value: 1.5e-34)<br>\n \n  PF08659.13 (KR domain): [5407:5582](score: 186.6, e-value: 3.9e-55)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [5677:5744](score: 46.9, e-value: 2.8e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyB1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyB1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75502.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCGCCCCCGACGAGCCGGTCGCCGTCGTCGGTCTGGCCTGCCGGCTGCCCGGCGCCGCCGATCCGGAGGCGTTCTGGGCGCTGCTGCGCGACGGGCGGGAGGCGATCACCGACCCGCCCGCGTCCCGACGCGACCCGGACGGGCGCGCCCGCAGGGGCGGCTTCCTGGACGCGGTGGACCTGTTCGACGCCGAGTTCTTCGGCGTCCCGCCCCGCGAGGCGGCGGCCATGGACCCGCAGCAGCGGCTGGTGCTGGAGCTGAGCTGGGAGGCCCTGGAGGACGCCCGGATCCGCCCGGACGCGCTGGCCGGCAGCCGGACCGGGGTGTTCGTTGGCGCCATCTCCGACGACTACGCGACGCTGCTGCGCCGCCGTGGTCCCGACGCCATCGGCCCGCACTCGTTGACCGGCACGAACCGGGGGATCATCGCCAACCGCGTCTCGTACCACCTCGGGCTGCACGGCCCGAGCATCACCGTCGACTCGGCGCAGTCCTCCGCCCTCGTCGCCGTGCACGTGGCCGCCGAGAGCCTGCGCCGCGGCGAGTCGGAACTGGCCCTCGCCGGTGGGGTGAACCTGAACCTCGCGCCGGAGAGCACGCTGGGCGCCGAACGCTTCGGCGCGCTGTCCCCGGACGGCCGCTGCCACACCTTCGACGCGCGGGCCAACGGGTACGTGCGCGGCGAGGGCGGCGGGCTGGTGGTGCTCAAGCCGCTGGACCGGGCGCTCGCCGACGGCGACCGGGTGCACGCGGTCCTGCTCGGCAGCGCGGTCAACAACGACGGTGTCACCGACGGCCTGACCGTGCCCGGCAGCGACGGGCAGCGGGAGGTGATCCGGCTGGCCCACGAGCGGGCCGGCACCACGCCCGGCGAGGTCGACTACGTCGAGCTGCACGGCACCGGCACGGTCGTCGGCGACCCGGTCGAGGCCGCCGCGCTGGGCGCAGAACTGGGCCAGCTGCGCGACACGCCACTGCTGGTGGGCTCCGCCAAGACCAACGTGGGGCACCTGGAAGGCGCGGCGGGCATCGTCGGGTTCGTCAAGGCCGTGCTCTGCGTACGGCACCGGACGCTGCCGCCGAGCCTGAACTTCGCCACCCCGAACCCACGCATCCCACTCAACGAGCTGAACCTGCGGGTGGTGACCGAGAGCCACACCGTGCCGCGGCCCCTGGTCGTCGGGGTCAGTTCCTTCGGCATGGGCGGCACGAACGCCCACGCCGTACTCACCGAGGCTCCGCTGCGGACGGCGCGGAAGCCGGCTCCCGCGGCGCGCCCGCTGACGTGGGTGGTCTCCGGGCACACCCCGCAGGCCCTGCGGGCGCAGGCCGGGCAGCTCACGAGCCTGGCCGCCGACCCGGCCGACGTGGCGTTCTCGCTGGCCACGACCCGCGCGACGCTGCCCTACCGGGCGGCGGTGGTCGGCGAGACGGCGGCCGACCTGCGCGCCGGGATGGCGGCGGTGGCGACCGGCACGCCCCACCCGGGCACGGTGACCGGCTCCCCGGCCGGCACGCTGGCGTTCGTCTTCACCGGGCAGGGCAGCCAGCGGGCCGGCATGGGGCGGGAGTTGGCCGCCCGGTTCCCGGTGTACGCCCAGGCGTTCGCCGAGGTCGCGGCGGCACTCGACCCGCACCTGGGTCGCCCCCTCGACGAGGTGCTCGACGACGCCGACGCCCTCGACCGCACCGAGTTCGCCCAGCCCGCACTGTTCGCCGTGGAGGTGGCGCTGTTCCGGCTGCTCACCCATTGGGGTCTGCGACCGGACGCGGTGGCGGGCCACTCGGTCGGTGAGATCGCCGCCGCGCACGTGGCCGGCGTGCTGGACCTCCCCGACGCGGCCCGCCTGGTGGCGGCTCGGGGCCGGCTCATGCAGGCGTTGCCGACCGGCGGCGCCATGGTCGCCCTGTCGGCCGGCGAGGAGGAGGTACGACCGCTCCTGCGTCCCGGGGCCGACCTGGCGGCGGTGAACGCGGCGGAGTCGGTCGTGGTGGCCGGCGACGACGACGCCGTCTCCGCCATCGAGGAGACCGTGCGCGGCTGGGGGCGGCGGACCAGCCGGCTACGGGTCAGCCACGCCTTCCACTCGGCCCGGATGGACCCGATGCGCGTCTCCTTCGCGCAGGCACTGGCCGACATCGAGTTCGCGCAGCCGACGATCCCCGTGGTGTCCGCGCTGACGGACCCCGACGTGACCGACGCGGAGCACTGGGTACGCCACGTCCGGGACACCGTCCGGTTCGCCGACGCGGTCCGGGACCTGCGCGACCGGGGCGTCCGCACAGTCCTGGAGGTCGGACCGGACGCGGTGCTCACCGCACTGGCGCACGACGTGGCGGAGCTCGCCGCCGTCGCGGTGCTGCGCCGCGACCGCCCCGAGCCGGACACCGCCGTGACGGCGCTGGCCACCGCGTTCACCCGGGGCGCGGCGGTGGACTGGACCGCCCTGCTCGGTGCCCGCCAGGCGGTCGACCTGCCCCGGTACGCCTTCCAGCGCAGCCGCCACTGGCTGGACCAGGACAACCCAGCGATCGCGGCACCGGAGGTCACCCGCGCCCCCGACGGCACGCCCCGCCGCTCGGACGAGGAACTGCTCGACCTGGTGCGTACCGCCGTCGCGGTCGCCCACGGCCGCGTCGGCCCGGCAGCGATCGACCCGGATACCACGTTCCGCGATCTCGGCCTGGACTCGGTCACCAGCGTGGAGTTCCGCGACCGGCTCGCCGCGGCGACCGGCGTCCCCCTCTCCCCCGGCCTGGTCTACGACCATCCCACCCCCCGCGCCGTGGTGGCGCACCTGCGGACGCTGACCGGCGGCGGACCGGCCGACCCGGAGCAGGAGAGCGGCTACCGCGACGAGCCGGTAGCCGTCATCGGCATGGCCTGCCGGTACCCCGGCGGGGTCGGCTCACCCGACGACCTGTGGCAGCTCGTGCGGGACGGGCGGGACGCCACCGGCCCGTTCCCCACCGACCGTGGCTGGGACCTCGACGCGCTCTACGACCCGGATCCCGGCACCCCGGGACGTACCTATGTGCGGCGGGGAGGATTCCTCGACGGCGCGGCCGAGTTCGACGCCGACTTCTTCGGCATCAGCCCGCGCGAGGCCAGCGCCATGGACCCGCAGCAGCGGCTGCTGCTGCACACCGCGTGGGAGGCGCTGGAACACGGCCGACTGAACCCGGAGTCGCTACGCGGCACCCGAACCGGGGTGTTCGTCGGCGTGGTGGACAACGACTACGGGCCGCGACTGCACGAGCCGGTCGAGGGCACGGAGGGTTACCTGCTCACCGGCACCACGGCGAGCGTCGCCTCCGGACGCGTCGCGTACGCCCTGGGGCTGACCGGCCCGGCGGTCACCGTCGACACCGCGTGCTCCTCGTCGCTGGTGGCGCTGCACCTGGCGGCGCAGGCGCTGCGGCAGGGAGAGTGCACCCTGGCGCTGGCCGGCGGGGCGACCGTACTCGCCACGCCGGGCATGTTCCTGGAGTTCAGCCGACAACGCGGCCTCGCACCGGACGGCCGCTGCAAGGCGTTCGCCGCCACGGCCGACGGCACCGCTTGGGCCGAGGGCGCCGGTCTCGTCGTGCTGGAACGCCTCTCCGACGCCCGTCGCAACGGCCACCCGGTCCTCGCCGTGCTGCGCGGCTCGGCGATCAACCAGGACGGCGCCTCCAACGGCCTGACCGCACCCAGCGGCCCCTCGCAGGAGCGGGTCATCCGCCGGGCGCTGGCCGTGGCCGGGTTGGCTCCCTCCGATGTGGACCTCATGGAGGCGCACGGCACGGGCACCGCCCTGGGCGACCCGATCGAGGCCCGGGCCATCCTGGCCACCTACGGGCAGCGGCGCGACACGCCGCTGCACCTCGGCTCGTTGAAGTCGAACATCGGCCACACCCAGGCCGCCGCCGGTATCGCCGGAGTCATCAAAGTCGTCCAGGCGATGCAACACGGCACCCTGCCGGCGACGCTGCACGTGGACGAACCCACCCCGCACGTCGACTGGGCCGAGGGTCAGGTCAGCCTGCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACACGGCGATCCGCAGCCGGCACCGCCGCGGCGTACGTCGACGGGGCACGTGGCCTGGCTGGTCTCGGCCCGGGAGCCGGAGCTGGTGGCCGAGCAGGCCGGCCGGCTACACCGGTTCGTGCGGGACAACCCGGAGCTGGACCCGGCGGACGTCGCGCTGTCGTTGGCCACCACCCGCCCCCTGCTGGAGCATCGCGCGGCCGTGGTGGGCGCCGACCGGGACGAACTGCTGGCCGGACTGGCGGAGCTGGAGTCGGGTCGCCGGCGCGCCGAGGCGATCCGGCCGGGGAAGGTGGCGTTTCTGTTCGCCGGACAAGGCACCCAACGCCTCAACATGGGCCGCCAACTCTACGACACCAACCCCACCTTCGCCCACGCCCTCGACACCGTCACCAACGCCCTCAACCCCCACCTCAACCAACCCCTCCTCGACATCATCTTCGGCACCGACCCCCACCTCCTCAACCGCACCGAAAACGCCCAACCCGCCCTCTTCGCCATCGAAACCGCCCTCTACCACCTCCTCACCCACCACGGCATCCACCCCGACTACCTCCTCGGCCACTCCCTCGGCGAAATCACCGCCGCCCACGCCGCCGGCATCCTCACCCTCACCGACGCCGCCACCCTCGTCACCACCCGCGCCAAACTCATGCAAACCGCCACCCCCGGCGGCGCCATGATCGCCATCGAAGCCACCGAAACCGAAATCCAACCCACCCTCCACCCCACCGTCACCATCGCCGCCATCAACACCCCCACCACCACCGTCATCAGCGGCGACCACCACCACACCCACGCCATCGCCCACCACTGGCGCCAACAAGGCCGACGCACCACCACCCTCACCGTCAGCCACGCCTTCCACTCCCCCCACATGGACCCCATCCTCGACACCTTCCACACCACCACCCAAACCCTCACCCACCACCCACCCCACACCCCCCTCATCACCAACCTCACCGGACAACCCCTCACCAACCCCACACCCGAACACTGGACCCACCACCTCCGCCAACCCGTCCGCTACCACGACGCCACCACCACCCTCACCCACCACGGCGTCACCCACACCATCGAAATCGGCCCCGACACCACCCTCACCACCCTCACCAAAACCAACCACCCCACCCTCACCACCACCCCCACCCTCCGCCCCCACCACAACGAAAACCACACCCTCACCCACACCCTCGCCACCACCCCCACCACCAACTGGGCCAGCCTGTACCCGCACGCCCGCCCGGTCCGGCTGCCCACCACGGCATTCCGGCGCGACCGGTACTGGCTCACCGGCGGCCGGGCCACCCCGGGCGCGGACTCGGGTGTGCGCGAGGTCGATCACCCGCTGCTGGGCGCCGCCGTGACGCTCGCCGACGACAGCACCGTCTACACCGGACGGCTGTCCCGGCGTACCGCCCCCTGGCTGGCCGACCACGTGGTGCTCGGCCGGGCGTTGCTGCCCGGCACCGCCCTGCTGGAGTACGCGCTGTGGGCGGGCCGGGACGTCGGGCTGCCCCGGGTGGCCGAGCTGACGCTGGAGGCCCCGCTGGTGCTGCCCGACGAGGGCGTGACGCAGGTGCGGGTCACCGTCGGCCCGCCGGGTGAGCAGCGGACCGTCGCCGTGCACGCGCGGGCCGACGACGCCGAGCAGTGGACCCGGCACGCCAGCGGCATGCTCACGGCGGCGCCCCCGGCGTCCCCGGTCCCCCCACGCGTGGACGGCCCGCCGGTCGACGTCGACGACCTGTACGAGCGGTTGGCCGGCAAGGGCTACGAGTACGGGCCCGCCTTCCGCCTCGCCACCGCCGCCCGGCACGGCCAGCACGTGGTGGCGCAACTCGCCGCGCCCGCCGGCCCCGACGGATTCGTGCTGCACCCGGCGCAGGTGGACGCCGCTCTGCACCCGATCGTGCTGGACGGCGACGAGACGCTCCTGCCGTTCAGCTGGAGCGGCGTCTCGGTCTTCCGCCGGCCCAGCGGGGCGCTGCACGCGTACTGGACGCCCGAGCGGGCGCTCGTCCTCACCGACGCCGACGGGGTGGTCGCCACCGCCGACAGCCTGCACCTGCGGCCCGCGCGCATGCCGGCCCCCACGGACCTGCACCGGATCCGGTGGGTGCCGGCCGAGGACGCCCGGCGGCAGATCCGCGTCGAACCGGTCGCCGACGCCACGGCCGCGCTCGCGATGCTCCACGAGCGCCTGGACGCCACCGAGCCGACCGCGCTGGTGGTGCCACACCTGGACCGCACCGGTGCGGCCGGGCTCGTCCGGTCGGCGCAGGCCGAACACCCCGGCCGGTTCGTGCTGATCCACGCCGACGACCCGGTCCGGACCGTACCGGACGGCGAACCCGAGGCGGCCTGGCGCGACGGTTCGTGGTGGGTCCCCCGGCTGGCCCGCGTCGCACCCGTCGATCCGGGGCTGCCGCTGTCCGGCACCGTGCTCGTCACCGGCGGGACCGGAGCCCTGGGCGCACTGGTCGCCCGGCACCTCGTCCGCGCCCACCGCGTGCGGGACCTCGTGCTGGTCAGCCGGCGCGGCGCGGACGCACCGGGTGCGGCCGCGCTGGCCGACGAGTTGGCGGGCCACGGCGCGCGGGTCGACCTGCGGGCATGTGACGTCGCCGACCGGGAGGCGTTGGCCTGCCTGCTCGCCGACCTGCCCACCCTCGACGCGGTCGTGCACGCGGCCGGGGTGGTCCGGGACGCGACGGTGTCCGCGCTGACCGTCGAGCAGGTACGCGCGGCCGCGACCAAAGCCGAGTCGGCCTGGCACCTGCACGAGCTGACCCGGGACCGTCCCCTGCGGGCGTTCGTGCTGTTCTCCTCGATCAGTGGGCTGCTGGGCACCGCCGGCCAGGGCGCGTATGCGGCCGCCAACGCCGCGCTGGACGCGCTGGCCGCGCACCGGCACGCCCTCGGCCTACCGGCGCTGTCCCTGGCCTGGGGTCTGTGGGAGGACACCGGGATGGGGGCGGGGCTGTCCGCTGCCGACGTGGCCCGGTGGCGGCGCGACGGGCTGCCGCCGCTGACCGTCGAGCAGGGCGTGGCGCTGTTCGACGCCGCGCTGTCGCACGAGGGTCCGGTCCTCGCACCGGTACGCCTGGACCTGGCGGCGCTGCGCGGCCGTGACGTGCTGCCCGCCGCGCTGCGGGGGCTGGTCACGCGTCGTGCCGTGCCGCCCGCCGGAAGCCGACCGCGTGACGAGGCCGAACTGCGGGAGGTGGTCCGTTCGGTGGTCGCCGAGGTGCTGGGGTACCCGTCGGCCGCCGGGGTGGACTCGGCCCGCCCGTTCCGCGACCTGGGGCTCGACTCGCTCGGCGGGGTGGAGCTGCGCAACCGCCTCGCCGCCGCGACCGGCCTGCCGGTGCCCGCCACGCTGGTGTTCGACCATCCGACGCCGGACGCCGTGGTGGCCCACCTGCTCGGCGCCACGACGAGCGCACAGCCGGCACCGACGCCCACAGTGGCCACCCGCACCGACGAGCCGATCGCGATCGTGGGGATGGCCTGCCGGTATCCCGGTGGTGTCTCCTCGCCGGAGGACCTGTGGCGGCTGGTGGCCGACGGTGTGGACGCGATCGGCGAGTTCCCCACCGACCGGGGCTGGGACCTGGGCCGGCTCTATGACCCCGACCCCGAACACGCCGGCACCTCGTACACCCGCCACGGCGGCTTCCTCTACGACGCGGCCGACTTCGACGCCGGGTTCTTCGCGCTGAGCCCGCGCGAGGCCACCGCCACGGACCCGCAGCAGCGGCTGCTGTTGGAGGTGGCGTGGGAGGCGTTCGAGCGGGCGGGAATCGACCCGACCGCGGTACGCGGCAGTCGGACGGGTGTGTTCGCGGGCGTCATGTACGGCGACTACGGGACGCGGTGGCGTACCGCCCCGGAGGGTTTCGAGGGGCACCTGCTCACCGGCAACACCTCCAGCGTGGTCTCGGGTCGGGTGGCGTACAGCTTCGGGTTGGAGGGTCCGGCGGTCACCGTGGACACCGCCTGCTCGTCCTCTCTGGTGGCCCTGCACCTGGCCGCCCAGTCACTGCGCAGCGGCGAGTGCGATCTGGCGCTGGCCGGCGGCGTCACGGTGATGGCGACGCCGCACACCTTCGTGGAGTTCAGCCGTCAGCGGGGGTTGTCCCCGGACGGGCGCTGCCGGTCGTTCTCGGCGGCGGCGAACGGTACGGGATGGAGTGAGGGTGCGGGCCTGCTGCTCGTCGAACGCCTCTCCGACGCCCGCGCCAACGGCCACCACGTCCTGGCCATCCTCCGCGGCTCCGCCGTCAACCAGGACGGCGCCTCCAACGGACTCACCGCACCCAACGGACCCGCCCAACAACGCGTCATCCGCACCGCCCTCACCAACGCCCACCTCCAACCCACCGACATCGACCTCGTCGAAGCCCACGGCACCGGCACCCGCCTCGGCGACCCCATCGAAGCCCAAGCCCTCATCGCCACCTACGGCCACCACCGCAACACCCCACTACACCTCGGCTCACTGAAATCCAACATCGGCCACACCCAAGCCGCCGCCGGCGTCGCCGGAGTCATCAAAGTCATCCAAGCCATGCAACACGGCACTCTCCCCGCCACACTGCACGTGAACGAACCCACCCCACACGTCAACTGGGCCGACAGCCAGGTCACCCTCCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACACGGCGATCCGCGGCCGGTGCCGCCGGAGGAGACGGATCCGCCCGCGCCGGTGCCGCTGGTGATCTCGGCCCGGTCCGCCGGCGCGCTACGCGACCAGGCCGCCCGGGTGCGCACGGCGTTGGGCTCGGGGCTGCCCGTGCGGGACGTGGCGTACACGCTGGGGGCGGCGCGCGCCCGGCACCCGCACCAGGCGGTGGTCGTGGGCGAGGGTCGGGCGGAGCTGCTGGCCGGACTCGACGCGGTGGCCGACGGCACCGTTCCCGGTGCGGTGGCCACCCCGGGGAAGGTGGCGTTCCTGTTCGCCGGACAAGGCACCCAACGCCTCAACATGGGCCGCCAACTCTACGACACCAACCCCACCTTCGCCCACGCCCTCGACACCGTCACCAACGCCCTCAACCCCCACCTCAACCAACCCCTCCTCGACATCATCTTCGGCACCGACCCCCACCTCCTCAACCGCACCGAAAACGCCCAACCCGCCCTCTTCGCCATCGAAACCGCCCTCTACCACCTCCTCACCCACCACGGCATCCACCCCGACTACCTCCTCGGCCACTCCCTCGGCGAAATCACCGCCGCCCACGCCGCCGGCATCCTCACCCTCACCGACGCCGCCACCCTCGTCACCACCCGCGCCAAACTCATGCAAACCGCCACCCCCGGCGGCGCCATGATCGCCATCGAAGCCACCGAAACCGAAATCCAACCCACCCTCCACCCCACCGTCACCATCGCCGCCATCAACACCCCCACCACCACCGTCATCAGCGGCGACCACCACCACACCCACGCCATCGCCCACCACTGGCGCCAACAAGGCCGACGCACCACCACCCTCACCGTCAGCCACGCCTTCCACTCCCCCCACATGGACCCCATCCTCGACACCTTCCACACCACCACCCAAACCCTCACCCACCACCCACCCCACACCCCCCTCATCACCAACCTCACCGGACAACCCCTCACCAACCCCACACCCGAACACTGGACCCACCACCTCCGCCAACCCGTCCGCTACCACGACGCCACCACCACCCTCACCCACCACGGCGTCACCCACACCATCGAAATCGGCCCCGACACCACCCTCACCACCCTCACCAAAACCAACCACCCCACCCTCACCACCACCCCCACCCTCCGCCCCCACCACAACGAAAACCACACCCTCACCCACACCCTCGCCACCACCCCCACCACCAACTGGAAGACCCTCCTCCCCCACGCCACCGTCATCGACCTGCCCACCTATCCGTTCCAGCGACAGCGGTACTGGCTGGACGGTCCCGCCGCCGACACCGGCCTCGACGGCAGCGGCCATCCCCTGCTGCCCGGCGTCGTCGACCTGGCCGACGGGGGGTTGGTCCTCACCGGCACGGTGAGCGCCGACAGCCACCCCTGGCTGGCGGGGCACCGGATCGGTGGCGCGACGCTGCTGCCCGCCACCGCCGTGGTGGAGGCGGTGGCGCACGCGGCCAGCCGCGTCGGCCTGGACGTCGACGAACTGGTCCTGACGGCCGCCGTGCCGGTCGATGCCCCGGTGCGCCTACGGCTCACCGTCGGGCCGGCGTCCGACGACGACAGCCGCGCTGTGCACCTGCACGGCAACACCGACGACGGCGAGTGGTTGCCGTACGCCACCGGGCGGCTCGCGGTCGTCACGCAGTCGCCCGCCGCCGACCTCGCCACCTGGCCGCCGACCGACGCCGAGCCGGTGGACGTGGTCGACCTCTACGACCGGCTGGCCGAGGGCGGCTACGGCTACCACGGCCTGTTCCAGGGGCTGCGGGCGCTGTGGCGCCGAGGCGACGAGACGTTCGCGGAGGTACGCCCCGACGAGTCGCCCACCGGCGGCTTCGCCCCGCACCCCGCCCTGTGGGACGCGGCGCTGCACCCGCTCGCCTGGGACGCCGCCGAGCGGGGGCAGGTGGAGATCCCGTTCGAGTGGCGGTCCGTTCGCCGGCACGGCCCCGGTGCTCCGGCACTGCGCGTGCGGCTCGCCCGCCGCGACGACGCGGTGAGCGTGGACGTGGCCGACGACGCGGGCCGCCCGATCGCCTCGGCCGGTGCGCTGCGGCTGCGGTCGACCGGCACCGCGCCCACCACCGTCCTCGAACCCGACTGGGAGCCGGTGCCCACCGACGGGGAGTGGACCGGCCGGTACGCGACGGTGGTGGCACCGCGCACCGGCGCGGACGCGAGCGCGGCGTACGCGGCCGTGACCTGGGCACTGGACGCGCTGCGGCAGCACGAGGGCGACGAGCCGCTGGTGGTCCGTACCGTCGACGACCCGGCCGGTGCGGCCGTCCGTGGCCTGGTGCGCACGGCGCAGACCGAGCAGCCGGGCCGCTTCGTGCTGTTCACCGGTTCCGGTGACCCGGAGCCGGCGCTGGTCCGCGCCGCGCTGGCCAGCGGCGAACCGGAGGTGGCGCTGCGCGACGGGACGCTGATGGCACCCCGGCTGTCGCGGATCCCCGTCGCGCCCGGTCCGCTGCCCTTCGCGTCCGGGTCGACGGTGCTGGTGACCGGCGGCACCGGCGCTCTCGGCGCGCTGGTCGCCCGGCATCTGGTCGTCCGGCACGGGGTACGGCGCCTGCTGCTGACCAGCCGGCGTGGCCCGGCCGCCGACGGCGCGGCCGAGCTGGTGGACGAGCTGACCGCGGCGGGCGCCGAGGTCGAGGTGGTGGCGTGCGACGTGGCGGATCGTCCGGCGGTGGCGGCGCTGTTGGCCAGCATCCCCGAGGAGCACCCGCTCACCGCCGTCATCCACACCGCCGGCGTGCTGGACGACGGCGCGCTCACCTCGCTCACCGAGGAGCGCCTGGCCCGGGTGCTGCGGCCCAAGGCGGAGGCGGCCTGGCACCTGCACGAGTTCACCCGGGACCGGCCCCTCACCGCCTTCGTGCTCTTCTCCTCGATCACCGGCATCACCGGCACGGCGGGACAGGCCAACTACGCCGCCGCGAACGCCTACCTGGACGCGCTGGCCCGGCACCGCCGCAACCTCGGCCTGCCCGGCGTCTCCCTGGCCTGGGGGCTGTGGGGGGCCACCGGCATGGCGTCGGGTCTCGGCGCGGCCGACCTCGACCGGCTGGCCCGCAGCGGGATCACCCCGCTGTCACCGCAGGAGGGCCTGGACCTCTTCGACGCCTGCCTGGTCGCGGACCGACCGGTCCTGGCACCGGCCCGGGTCGACCTGTCCACAACTCGCCGGCAGCGTCGCCGCGCGGCGTCCGCCGCCGCCACGGTCACCAGCCGGGAGGGCCTGCGGGAGCTGGTCCGCGCCCAGGTGGCCGCGGTGCTCGGGCACACCGACGCCACCGAGGTGTCCACCGACGTCGCGTTCACCGGGCTTGGCCTGGACTCCCTCACGGCGGTCGAGCTGCGCAACCGGATCGCCGAGCGTACCGGGCTGCGCCTGTCGAGCACGGTGGTCTTCGACCATCCCTCGGTGGACGCGCTCACCGACCACCTGGTCGCGGAACTGGCCGGCGCCCGTCCGGTGGAGACGCCGCAGCCCGTTACGCAGCCGGCCGACGAGCCGATCGCGATCGTGGGGATGGCCTGCCGGTATCCCGGTGGTGTCTCCTCGCCGGAGGACCTGTGGCGGCTGGTGGCCGACGGTGTGGACGCGATCGGCGAGTTCCCCACCGACCGGGGCTGGGGCGAGATCCACGACCCGGACCCGGACCGGCCGGGACACAGCTACACCCGGCACGGGGGCTTCCTCTATGCGGCGGGCGACTTCGACGCGGAGCTGTTCGGCATGAGCCCGCGCGAGGCGCTGACCACCGACCCGCAGCAACGGCTGCTGCTGGAGGTGGCGTGGGAGGCGTTCGAGCGGGCGGGGCTGCCACCGGGATCGCTGCGGGGCAGCCGGACCGGCGTGTTCACCGGCGTGATGTACAACGACTACGGCGCGCGGCTGCACCAGGCCGGCACGCCCGCCCCGGGCTACGAGGGCTACCTGGTCAGTGGCAGCGCGGGCAGCGTCGCCTCCGGTCGGGTGGCGTACAGCTTCGGGTTGGAGGGCCCGGCGGTCACCGTGGACACCGCCTGCTCGTCCTCCCTGGTGGCCCTGCACCTGGCCGCCCAGTCACTGCGCAGCGGCGAATGCGATCTGGCGCTGGCCGGCGGCGTCACAGTCATGGCCAGCCCGGCGACCTTCGTGGAGTTCAGCCGACAACGCGGCCTCGCACCCGACGGCCGGTGCAAACCATTCGCAGCCGCAGCCGACGGCACCGGATGGAGTGAGGGTGCGGGCCTGCTGCTCGTCGAACGCCTCTCCGACGCCCGCGCCAACGGCCACCACGTCCTGGCCATCCTCCGCGGCTCCGCCGTCAACCAGGACGGCGCCTCCAACGGACTCACCGCACCCAACGGACCCGCCCAACAACGCGTCATCCGCACCGCCCTCACCAACGCCCACCTCCAACCCACCGACATCGACCTCGTCGAAGCCCACGGCACCGGCACCCGCCTCGGCGACCCCATCGAAGCCCAAGCCCTCATCGCCACCTACGGCCACCACCGCAACACCCCACTACACCTCGGCTCACTGAAATCCAACATCGGCCACACCCAAGCCGCCGCCGGCGTCGCCGGAGTCATCAAAGTCATCCAAGCCATGCAACACGGCACTCTCCCCGCCACACTGCACGTGAACGAACCCACCCCACACGTCAACTGGGCCGACAGCCAGGTCACCCTCCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACACGGCGACGCCGTCGACACCGGGACCGGGACCGGGACCGTTGCACCGGGCACCGCCGTGGTGCCGTGGCTGCTGTCCGGGACCAGCCGGCAGGCGCTCACCGCGTACGCGCGGCTGCTCGGGGAGGTCGACGCCGCGCCCGTGGACATCGCCGCGACGCTGGCGCTGGGCCGCAGCCCGCTCGCCCTGCGGGCGTCCGTGGTCGGCCGGGACCGCCCGGAGTTTCCCACCGCGCGGCTGCAGCCGGTACAGCCGGTGGACGGGCCCACGGCGTTCGCGTTCACCGGCCAGGGCAGCCAGCGCGCCGGAATGGGGCTGGGACTGGCCGCCCGGTTCCCTCAGTTCGCCGACGCGCTCGCGTCCGTGGCAGAAGCCCTCGACCCGCACCTGCCGTCGCCGCTGCTCGACGTGCTCGCCGACGGCGACCTGCTGGAACGCACCGAGTACGCCCAACCGGCCATCTTCGCCGTGGAGGTGGCGCTGTTCCGGCTGCTGGCCCACTACGGAGTCACCCCGCACGTGCTGCTCGGGCACTCCGTCGGCGAGCTGGCCGCCGCGCACGTCGCCGGGGTGCTCGACCTACCCGACGCCGCCACGCTGGTCGCCGCGCGGGGACGCCTGATGGGAGGACTGGTTCCGGGTGGGGCCATGGCCGCCGTCCGGGCAGGCGAGGACGAGGTACTGGCGCTGCTGGTGCCCGGTGCGGAGATCGCCGCCGTCAACGCCGACGACGCGGTCGTCGTGTCCGGTGACGCGGAGGCCGTCGCAGCGGTCACCCAGGCCCTGCGCGACGCGGGCCGACGGGTCACCCCGTTACGGGTCAGCCACGCCTTCCACTCCGCCCGGATGGACCCGGTGCTGGAGGAGTTCCGGGCGGTGGCGGCCACGCTGCGGTTCTCCGAGCCCACCATCCCGCTGATCTCCCTGCTGCCCGGTTCCCCCACCGACCCCGGGTACTGGGTGCGGCACCTGCGCGAGGCGGTCCGCTTCGGCGACGGCGTACGGTCGCTGGCCGAGTGGGGCGTACGGCGCGTCCTGGAGGTGGGTCCGGACGCCGCGCTGACCCCGGTGACCGGGCCGACGGGAATCGCCACGCTGCGGCGCGACCACGACGAGGAGAGCGCCTTCGTCACGGCGCTGGCCGCGCTGCACGACACGGGCGCGACCGTGGACTGGGCGACCTTCTTCGGGGAGCTGGGCGCTCGGCGGGTGCCGCTACCCACCTACCCCTTCCAACGCCGCCGGTACTGGCTGACGCCCACCGCACCCCGCACCACCGGCGGGAGCGGTCATCCGCTGCTCGACGCGGCGGTGGAGCTGCCCGAGGGTGCCGTGCTGTTCACCGGCCGGGTGGCCGCCGAGGACGCCGACTGGCTGGCCGACCACGTGGTGCTGGGCCAGACCGTGGTCTCCGGCGCCACACTGCTGAGCCTGGTCCTGCATGCCGCGGCCGCGGCGGGACGACCCACGGTGCGGCGGCTGACGCTGCACGCGCCGCTGGTGCTGCCCGATGACGGCGGCGCGGCCGACCTGCGGGTCGGTGTCGACGAGCAGGGGCAGGTGACGGTGTACGCCCGGCCGGCCGGCGGCGGGTGGACCCGGCACGCCTCCGGCACGCTGGACACCGTCGAGCAGCCCGCCGAGGCGCTCGGGTCGTGGCCGCCGGCCGGTGCCGAGCCGCTCGACGTGGACTACACGCGACTGGCCGACGCGGGTTACGCGTACGGCCCCGGCTGCCGCCGGGTGCGCGCCGCGTGGCGCCTCGGCGACGACCTCTACGCCGAGGTGGGCCCGGTCGACGCCGACGGGCACGCCGCGCCGCATCCGGCGCTGCTCGACGCGGCGCTGCACCCGCTGGCCCTGGACCTGCTCGACGACGAGCAGACCCGGGTACCGCACGTCTGGTCGTCGGTGACGGTGCACGCGACCGGGGCGACGACGCTGCGGGCCCGGATCCGCCGGACCGGCACCGACCGTGTCGCCCTCACCCTCACCGACACCGACGACCGGCCGGTGGCCACGGCGGACCTCACCGTCCGGGCCGTTGCGCGCGGCCTGCCCGACCTGTACGCCGTCCGACTCACCCCGGTGCGGCCGGCCACCGGTGGGACGGTGTGGCCGAGCGTCGGCCGGGATGTCGGGCTGCCCCGCTACGCCGAGCTGTCCACCAGCACCGACGACATCGTCGAACGGGCGCACGACCGGGTCACCGAGGTGGCGGAGCTGCTTCGCCGCTGGCTGGCGCAGGGACCGCCGGAAGCCCGGCTGGTGGTCGCCACCGACCAGGTCACCGACCCGGCCGACGGGGTGCTGTGGGGCCTCGTACGGGCGGCCCAGACCGAGCATCCCGACCGGTTCGTGCTGCTCGACAGCGACGGCGACCCCCGGTCGCGGACCCTGGTCCCGGGGGCGCTGGCCACCGGCGAGCCGCAGCTCGTGGTGCGCGACGGGCGGATCACCGTGCCGAGACTCGCCCGCACCGCCGCCGCGCCGCAGCCACCCCGGCTCGATCCGGACGGGACGGTCCTGGTCACCGGTGCGGGTGGAGCCCTCGGCTCACTGACGGCCCGGCGCCTGGTCACCCACCACGGCGTACGGCGGCTCCTGCTGCTCGGCCGGCGCGGCGGGATGCAACCGCTGGCCGCCGAGCTGACCGCCCTGGGCGCCACGGTGCGGGTCGCGGCCTGCGACGCGGCCAACCGGGCGGCGCTGGCCCGGGTGCTCGACACCGTCCCCGCCGCGCACCCGCTCACCGCCGTGGTGCACGCGGCCGGGGTGGTGTCCGACGGGCCGCTGGCCACGTTGACGCCGCAGCGCTTCGCCGAGGTGCTGCGCCCGAAGGTGGACGCGGCGTGGCACCTGCATGAGCTGACCTGCGAGCAGGACCTGGCGGCGTTCGTGCTGTTCTCCTCCCTCGCCGGGCTGGTGGGCAACGCCGGCCAGGCCAATTACGCGGCCGCGAACACCGGCCTGGACGCCCTCGCCGCGTATCGCCGGGCCGCCGGGTTGCCGGCCGTGAGCCTGGCCTGGGGCCTGTGGGACGCGCCGGGCATGGGCGCCGCGCTGGACGAGACGCAGCGTGCCCGCATCGCGCGGACCGGTGTGGCGCCCCTGCCGGTCGAGCGGGGCCTGGCCCTCTTCGACGCCTGCCTCGGTGCCCGGGAGGCACTGTTGGTGCCCGCCGCGCTCCAGCCGGAGCGGGCGACGCGGGTCGCACCGGTGCTGGCCGGGCTGGCCCCGGCGACCACGGCGACCACGCCGCAGCAGGACTGGCCCCGACGGCTCGCCGGGCGGGGCGCCGCCGAGCAGCACCGGCTGCTGCTGGAGCTGGTCCGCAGCACGATCGTCGAGGTCCTCGGCCACTCCTCCGTCGCAGCCGTGGCACCCGACCGGGGGTTGATGGACCTCGGCTTCGACTCCCTCACCGCCGTCGAGCTGGCCGGGCGCCTCGGTGCCGACACCGGCGTCCGCACCCCGTCGACGGTGGTGTTCGACCATCCGACACCCACCGCGCTCGCCCACTACCTGCGACACGAGCTGGTGGGCGAGGAGGCGGCCGACGACGAGAAACCGCACGAGTTGGACGAGGTGTCCGACGAGGACCTGTTCGCCCTGATCGACACGGAGCTGGGAGAGCGATGA",
    "translation": "MSAPDEPVAVVGLACRLPGAADPEAFWALLRDGREAITDPPASRRDPDGRARRGGFLDAVDLFDAEFFGVPPREAAAMDPQQRLVLELSWEALEDARIRPDALAGSRTGVFVGAISDDYATLLRRRGPDAIGPHSLTGTNRGIIANRVSYHLGLHGPSITVDSAQSSALVAVHVAAESLRRGESELALAGGVNLNLAPESTLGAERFGALSPDGRCHTFDARANGYVRGEGGGLVVLKPLDRALADGDRVHAVLLGSAVNNDGVTDGLTVPGSDGQREVIRLAHERAGTTPGEVDYVELHGTGTVVGDPVEAAALGAELGQLRDTPLLVGSAKTNVGHLEGAAGIVGFVKAVLCVRHRTLPPSLNFATPNPRIPLNELNLRVVTESHTVPRPLVVGVSSFGMGGTNAHAVLTEAPLRTARKPAPAARPLTWVVSGHTPQALRAQAGQLTSLAADPADVAFSLATTRATLPYRAAVVGETAADLRAGMAAVATGTPHPGTVTGSPAGTLAFVFTGQGSQRAGMGRELAARFPVYAQAFAEVAAALDPHLGRPLDEVLDDADALDRTEFAQPALFAVEVALFRLLTHWGLRPDAVAGHSVGEIAAAHVAGVLDLPDAARLVAARGRLMQALPTGGAMVALSAGEEEVRPLLRPGADLAAVNAAESVVVAGDDDAVSAIEETVRGWGRRTSRLRVSHAFHSARMDPMRVSFAQALADIEFAQPTIPVVSALTDPDVTDAEHWVRHVRDTVRFADAVRDLRDRGVRTVLEVGPDAVLTALAHDVAELAAVAVLRRDRPEPDTAVTALATAFTRGAAVDWTALLGARQAVDLPRYAFQRSRHWLDQDNPAIAAPEVTRAPDGTPRRSDEELLDLVRTAVAVAHGRVGPAAIDPDTTFRDLGLDSVTSVEFRDRLAAATGVPLSPGLVYDHPTPRAVVAHLRTLTGGGPADPEQESGYRDEPVAVIGMACRYPGGVGSPDDLWQLVRDGRDATGPFPTDRGWDLDALYDPDPGTPGRTYVRRGGFLDGAAEFDADFFGISPREASAMDPQQRLLLHTAWEALEHGRLNPESLRGTRTGVFVGVVDNDYGPRLHEPVEGTEGYLLTGTTASVASGRVAYALGLTGPAVTVDTACSSSLVALHLAAQALRQGECTLALAGGATVLATPGMFLEFSRQRGLAPDGRCKAFAATADGTAWAEGAGLVVLERLSDARRNGHPVLAVLRGSAINQDGASNGLTAPSGPSQERVIRRALAVAGLAPSDVDLMEAHGTGTALGDPIEARAILATYGQRRDTPLHLGSLKSNIGHTQAAAGIAGVIKVVQAMQHGTLPATLHVDEPTPHVDWAEGQVSLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDPQPAPPRRTSTGHVAWLVSAREPELVAEQAGRLHRFVRDNPELDPADVALSLATTRPLLEHRAAVVGADRDELLAGLAELESGRRRAEAIRPGKVAFLFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPTLRPHHNENHTLTHTLATTPTTNWASLYPHARPVRLPTTAFRRDRYWLTGGRATPGADSGVREVDHPLLGAAVTLADDSTVYTGRLSRRTAPWLADHVVLGRALLPGTALLEYALWAGRDVGLPRVAELTLEAPLVLPDEGVTQVRVTVGPPGEQRTVAVHARADDAEQWTRHASGMLTAAPPASPVPPRVDGPPVDVDDLYERLAGKGYEYGPAFRLATAARHGQHVVAQLAAPAGPDGFVLHPAQVDAALHPIVLDGDETLLPFSWSGVSVFRRPSGALHAYWTPERALVLTDADGVVATADSLHLRPARMPAPTDLHRIRWVPAEDARRQIRVEPVADATAALAMLHERLDATEPTALVVPHLDRTGAAGLVRSAQAEHPGRFVLIHADDPVRTVPDGEPEAAWRDGSWWVPRLARVAPVDPGLPLSGTVLVTGGTGALGALVARHLVRAHRVRDLVLVSRRGADAPGAAALADELAGHGARVDLRACDVADREALACLLADLPTLDAVVHAAGVVRDATVSALTVEQVRAAATKAESAWHLHELTRDRPLRAFVLFSSISGLLGTAGQGAYAAANAALDALAAHRHALGLPALSLAWGLWEDTGMGAGLSAADVARWRRDGLPPLTVEQGVALFDAALSHEGPVLAPVRLDLAALRGRDVLPAALRGLVTRRAVPPAGSRPRDEAELREVVRSVVAEVLGYPSAAGVDSARPFRDLGLDSLGGVELRNRLAAATGLPVPATLVFDHPTPDAVVAHLLGATTSAQPAPTPTVATRTDEPIAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWDLGRLYDPDPEHAGTSYTRHGGFLYDAADFDAGFFALSPREATATDPQQRLLLEVAWEAFERAGIDPTAVRGSRTGVFAGVMYGDYGTRWRTAPEGFEGHLLTGNTSSVVSGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMATPHTFVEFSRQRGLSPDGRCRSFSAAANGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDPRPVPPEETDPPAPVPLVISARSAGALRDQAARVRTALGSGLPVRDVAYTLGAARARHPHQAVVVGEGRAELLAGLDAVADGTVPGAVATPGKVAFLFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPTLRPHHNENHTLTHTLATTPTTNWKTLLPHATVIDLPTYPFQRQRYWLDGPAADTGLDGSGHPLLPGVVDLADGGLVLTGTVSADSHPWLAGHRIGGATLLPATAVVEAVAHAASRVGLDVDELVLTAAVPVDAPVRLRLTVGPASDDDSRAVHLHGNTDDGEWLPYATGRLAVVTQSPAADLATWPPTDAEPVDVVDLYDRLAEGGYGYHGLFQGLRALWRRGDETFAEVRPDESPTGGFAPHPALWDAALHPLAWDAAERGQVEIPFEWRSVRRHGPGAPALRVRLARRDDAVSVDVADDAGRPIASAGALRLRSTGTAPTTVLEPDWEPVPTDGEWTGRYATVVAPRTGADASAAYAAVTWALDALRQHEGDEPLVVRTVDDPAGAAVRGLVRTAQTEQPGRFVLFTGSGDPEPALVRAALASGEPEVALRDGTLMAPRLSRIPVAPGPLPFASGSTVLVTGGTGALGALVARHLVVRHGVRRLLLTSRRGPAADGAAELVDELTAAGAEVEVVACDVADRPAVAALLASIPEEHPLTAVIHTAGVLDDGALTSLTEERLARVLRPKAEAAWHLHEFTRDRPLTAFVLFSSITGITGTAGQANYAAANAYLDALARHRRNLGLPGVSLAWGLWGATGMASGLGAADLDRLARSGITPLSPQEGLDLFDACLVADRPVLAPARVDLSTTRRQRRRAASAAATVTSREGLRELVRAQVAAVLGHTDATEVSTDVAFTGLGLDSLTAVELRNRIAERTGLRLSSTVVFDHPSVDALTDHLVAELAGARPVETPQPVTQPADEPIAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWGEIHDPDPDRPGHSYTRHGGFLYAAGDFDAELFGMSPREALTTDPQQRLLLEVAWEAFERAGLPPGSLRGSRTGVFTGVMYNDYGARLHQAGTPAPGYEGYLVSGSAGSVASGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMASPATFVEFSRQRGLAPDGRCKPFAAAADGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDAVDTGTGTGTVAPGTAVVPWLLSGTSRQALTAYARLLGEVDAAPVDIAATLALGRSPLALRASVVGRDRPEFPTARLQPVQPVDGPTAFAFTGQGSQRAGMGLGLAARFPQFADALASVAEALDPHLPSPLLDVLADGDLLERTEYAQPAIFAVEVALFRLLAHYGVTPHVLLGHSVGELAAAHVAGVLDLPDAATLVAARGRLMGGLVPGGAMAAVRAGEDEVLALLVPGAEIAAVNADDAVVVSGDAEAVAAVTQALRDAGRRVTPLRVSHAFHSARMDPVLEEFRAVAATLRFSEPTIPLISLLPGSPTDPGYWVRHLREAVRFGDGVRSLAEWGVRRVLEVGPDAALTPVTGPTGIATLRRDHDEESAFVTALAALHDTGATVDWATFFGELGARRVPLPTYPFQRRRYWLTPTAPRTTGGSGHPLLDAAVELPEGAVLFTGRVAAEDADWLADHVVLGQTVVSGATLLSLVLHAAAAAGRPTVRRLTLHAPLVLPDDGGAADLRVGVDEQGQVTVYARPAGGGWTRHASGTLDTVEQPAEALGSWPPAGAEPLDVDYTRLADAGYAYGPGCRRVRAAWRLGDDLYAEVGPVDADGHAAPHPALLDAALHPLALDLLDDEQTRVPHVWSSVTVHATGATTLRARIRRTGTDRVALTLTDTDDRPVATADLTVRAVARGLPDLYAVRLTPVRPATGGTVWPSVGRDVGLPRYAELSTSTDDIVERAHDRVTEVAELLRRWLAQGPPEARLVVATDQVTDPADGVLWGLVRAAQTEHPDRFVLLDSDGDPRSRTLVPGALATGEPQLVVRDGRITVPRLARTAAAPQPPRLDPDGTVLVTGAGGALGSLTARRLVTHHGVRRLLLLGRRGGMQPLAAELTALGATVRVAACDAANRAALARVLDTVPAAHPLTAVVHAAGVVSDGPLATLTPQRFAEVLRPKVDAAWHLHELTCEQDLAAFVLFSSLAGLVGNAGQANYAAANTGLDALAAYRRAAGLPAVSLAWGLWDAPGMGAALDETQRARIARTGVAPLPVERGLALFDACLGAREALLVPAALQPERATRVAPVLAGLAPATTATTPQQDWPRRLAGRGAAEQHRLLLELVRSTIVEVLGHSSVAAVAPDRGLMDLGFDSLTAVELAGRLGADTGVRTPSTVVFDHPTPTALAHYLRHELVGEEAADDEKPHELDEVSDEDLFALIDTELGER",
    "product": "type 1 polyketide synthase"
   },
   {
    "start": 32476,
    "end": 43413,
    "strand": 1,
    "locus_tag": "abyB2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyB2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75503.1</span><br>\n Gene: <span class=\"serif\">abyB2</span><br>\n \n Location: 32,476 - 43,413,\n (total: 10938 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: mod_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_N<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1021:malonyl CoA-acyl carrier protein transacylase (Score: 208.7; E-value: 2.9e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyB2 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (45..467)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (573..845)</dt>\n   <dd>\n   \n    Methylmalonyl-CoA specific<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (920..1073)</dt>\n   <dd>\n   \n    catalytic triad H,G,P inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (1304..1467)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KS</strong> (1642..2063)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (2160..2445)</dt>\n   <dd>\n   \n    Methylmalonyl-CoA specific<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_DH</strong> (2512..2666)</dt>\n   <dd>\n   \n    catalytic triad H,G,P found: False<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_ER</strong> (2938..3228)</dt>\n   <dd>\n   \n    ER domain putatively catalyzing 2R-configuration product formation<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_KR</strong> (3238..3417)</dt>\n   <dd>\n   \n    KR domain putatively catalyzing D-configuration product formation<br>\n   \n    catalytic triad S,Y,N inconclusive<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (3522..3594)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyB2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08990.14 (Erythronolide synthase docking domain): [11:39](score: 28.8, e-value: 7.8e-07)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [43:294](score: 306.1, e-value: 2.1e-91)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [301:417](score: 139.5, e-value: 5.2e-41)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [421:532](score: 58.1, e-value: 1.2e-15)<br>\n \n  PF00698.24 (Acyl transferase domain): [571:847](score: 295.4, e-value: 6.4e-88)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [920:1171](score: 51.8, e-value: 7.3e-14)<br>\n \n  PF08659.13 (KR domain): [1304:1468](score: 73.9, e-value: 1.6e-20)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [1552:1620](score: 51.6, e-value: 9.7e-14)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [1640:1890](score: 291.1, e-value: 8.3e-87)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [1897:2013](score: 144.8, e-value: 1.2e-42)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [2015:2114](score: 51.5, e-value: 1.3e-13)<br>\n \n  PF00698.24 (Acyl transferase domain): [2158:2466](score: 282.9, e-value: 4.3e-84)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [2512:2772](score: 179.7, e-value: 8.1e-53)<br>\n \n  PF13602.9 (Zinc-binding dehydrogenase): [3107:3229](score: 53.2, e-value: 6.5e-14)<br>\n \n  PF08659.13 (KR domain): [3238:3417](score: 202.4, e-value: 5.6e-60)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [3523:3590](score: 47.5, e-value: 1.8e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyB2 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08990.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016740' target='_blank'>GO:0016740</a>: transferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyB2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyB2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75503.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCACACCGAGCAAGGGGACGGACAGCATTGCCGACCAGCAGAAGCTGCGCGAGTACCTCCGGCGGGTCACCGACGACCTGCTGCGGACCCGCCGGCGCCTGACCGAGGTGGAGTCGGCCGACCGGGAGCCGGTGGCCATCGTCTCGATGGCCTGCCGCTTCCCCGGCGGGGTGGCTTCGCCGGAGGACCTGTGGCAGCTGGTGGCGTCCGGCACCGACGCGATCAGCGGGTTCCCCGATGACCGGGGCTGGCCACTGGACGAGCTGTACGACCCGGACCCGGAGCACCCGGGCACGTCCACCACCCGGCAGGGGGGTTTCCTGCACGACGCCGCCGACTTCGACCCGGAGTTCTTCGGGATCAGCCCCCGTGAGGCGTTGACCATCGACCCGCAGCAGCGGCTGCTGTTGGAGACCGCCTGGGAGGCGGTGGAGCGGGCCGGGATCGCACCGGACTCGCTGCGTGGCAGCCGGACCGGCGTGTTCGCCGGGGTCATGTACGGCGACTACGGTGCCCGCCTGCGCCCGATCCCGGCGGGCTTCGAGGGGTACATGGGCACCGGCAGCGCGGGCAGCGTGGCCACCGGCCGGATCGCGTACACCCTCGGCCTGGAGGGGCCGGCGGTGAGCGTCGACACGGCGTGCTCGTCGTCGCTGGTGGCGCTGCACCTCGCGGCGCAGGCGCTGCGGCGCGGCGAGTGCGACCTGGCGCTGGCCGGCGGCGTGACGGTCATCGCCACGCCGGAGCTGTTCGTGGAGTTCAGCCGCCAGCGGGGGTTGTCGCCGGACGGGCGGTGCAAGGCATTCGCGGCCTCGGCCGACGGCACGGGCTGGGCCGAGGGCGTCGGCCTGGTGCTTGTCGAACGGCTCGCCGACGCCCGCCGCAACGGTCACCCGGTGCTCGCGCTGCTGCGCGGCAGCGCCGTCAACCAGGACGGCCGCAGCAGCCAGCTCTCCGCGCCCAACGGCCCGGCGCAGCGGCGGGTCATCCGGGCGGCGCTGGCCAGTGCCGGCCTGGAGCCCGCCGAGGTCGACCTGGTGGAGGCACACGGCACCGGCACCCGGCTCGGTGACCCGATCGAGGCCCAGGCACTGCTGGCCGAGTACGGGCAGGGGCGCACGGAGCCGCTCTGGCTGGGCTCGCTCAAGTCGAACATCGGGCACACCCAGGCGGCGGCCGGCGTCGGCGGGGTGATCAAGGTGGTGCAGGCCATGCGGCACGGGCTCCTGCCCGCCACCCTGCACGCCGACGAGGCCACCCCGCACGTCGACTGGAGCGTCGGTGACGTCCGTCTGCTCACCGAGGCCCGCGACTGGCCGGCGCGGGAGCGGCCCCGGCGGGCGGCCGTGTCCTCCTTCGGCATCAGCGGCACCAACGCGCACGTGATCCTGGAGGAGGGCGACCCCGACGGGGTCGCCGACGCGCCACCGGACGACGTGCTCGCGCGCAAGCCGGTGCCGGTGGTGCTGTCGGCGCACACCGCGTCGGCTCTCGGGCCGCAGGCGGCCCGGCTCCGCGCGCACCTCGACGCCCACCCCGACCTCACGGTGGCCGACGTCGCGCACTCGCTGGCCACCACCCGTACCCCGCTCGCCGAGCGGGCCGTCCTCGTTGCCGCCGACCTCGACGAGCTGCGCACCGCCCTGGACGCCGTCGCGGACGGCGACGAGCCGCCGGTGCGCGGCACGGCCGGGCACCCCGGCGGGGTCGTGTTCGTCTTCCCCGGCCAGGGCGCCCAGTGGGCGGGCATGGCCCTGGACCTGTACCGCGAGGACGAGGTGTTCCGCGCGGCGCTGGACGACTGCGAGCGGGCCCTGGCCCCGCACGTCGACTGGTCGCTGCGGGCCGTGCTGGCCGACGCCGACGCCCTCGGACGCGTCGACGTCGTCCAGCCCGCCCTGTGGGCGGTGATGGTGTCACTGGCGGCGCTGTGGCAGCACCACGGCGTGACCCCCGACGCGGTCGTCGGCCACTCCCAGGGCGAGATCGCCGCCGCCTGTGTCGCGGGTGCCCTGTCGCTGGAGCAGGCCGCGGCCGTGGTGGCGCTGCGGGCGCGGGCCATCACCGCCGTCGCGGGTCGCGGTGCCATGGCGTCGGTTTCTGTGCCCGCACAGCAGATCACCGAGCGGTGGGGCGACCGGATCACCGTGGCCGTGACGAACTCCGCCGACGCGACGGTCGTCGCCGGTGAACCAGAGGCCGTCGCCGAGGTGGTCGCCGCGTACGACGCCGAGGGAGTCCGGGCCCGGGTCCTGCCGGTGGACTACGCCTCCCACTCGGCGCACGTGGAGCCCGTGCGGGAGCCGATCCTCGACGCGCTGCGCGACCTCACCCCGACCGAGGCCCGGGTCCCGTTCCACTCCACCGTCACCGGTGCGGAGTTCGACACCCGGGGCCTGACCGCCGACTACTGGTACACCAACCTGCGCAGCACCGTCCGGTTCGACCAGGCGGTGACCCGGCTACGCGAACAGGGCCACCGGATCTTCGTCGAGATCAGCCCGCATCCGGTACTGACGCCGGTGCTCGGCGAGGGCGCGTTCGGCACGCTGCGCCGCGACGAGGGCGACCGTCGACGTTTCATCACGTCACTGGGTGCGGTGCATGCCGTGGGCGTACCGGTGGACTGGTCCGCCGCGATCGGCCCGGCGCGCCGTGTGCCCCTGCCGACGTACGCCTTCCAGCGGTCCCGCTACTGGCTGGACGCGCCCGCGCGGACCGGCGACGCATCCGGGGTGGGGGTGGGCCCGACCGACCACCCGCTGCTCGGCGGTGCCGTCGACGTGGCCGGCGACGGCACGCTGGTGCTCACCGGGCGGCTGGTGCCCGGAGCGGACCGGGCCGCCGCCGAGCTGCGGGTCGGCGGCGTACCCGTGCTGTCCGGCACCGCGCTGCTCGACCTCGCCCTACGGGCGGGCGAGCTGGCCGGTCTGGGTGCGGTCGGCGAGTTCAGCGTGGAGACGCCTTTGGTGCTGTCCGCCACCGCCGGTTGGTTGCAGGTCGTGGTGGCGCCGGCCGGCGCCGACGGCGACCGGGAGATCGGCGTGTACGCCCGGCCCGACCACGAGGCGCCCTGGACCCGGCACGGTCACGGTGTGCTCGTCCCGGCCACGGCGCAGGACCTCCCGCCGCACCGGCCGGTGCCGGGCGCACCGCTCGCCCCGGACGAGGCGGTGGAGCGGCTCGCCGCGGCCGGTGTGGAACTGGCCTCGGCGCCCACGGCGGTGTCCGGCGACGCCGACGGGTACGTCGCCGACCTCGCGTCGCCGCCGGAGGGACGCTTCACGCTGCACCCGGCGCTGCTCGACGCCGCCCTGCTGCCCGCCTTCGGCCGGGGCGACGCCCGGCTGCCGAGCCGGTGGCGCGGGGTACGGCTGCCGCAGCCGGACGGCCAGCCGACCCGCGCGTCGGTACGCCGCCGCGACGGCGACTCGTGGGCCGTGTCGCTGACCGACTCCGCCGGTGCGCCGGTGGTCGAGATCGCCGAGGTGGTGCTGGGTCCGGTGCCGGTGGTGTCGGCCGCCGGGCACCACGACCCCCTGTTCACGCTGGAGTGGGCCCCCGTGGCCCGGCCCCGGGGTGCCGCCGCAACCGAGCCGGTGCCGCACGAGCTGCCCGGCGACGCCGGTCCCGCCGCGCTGGCCGTGCTTCGCGGCGGGCTGGCCGAGCCGGACGGGCCGCGCCAGGTGGTGGTGGCCCGCGGGGCGGGCACGGTGACGGGTCTGGTCCGGTGCGCGCAACTGGAGGAGCCCGGGCGGGTCGGCCTCGTCGAGTGGGACGGGCGCGACGCCGACGCGCTGCGCGACGCCGTGGCCGCCGGGCTGCCGCAGGTGGCGGTCCATGGTGCGGAGCTGCGTACGCCCCGGCTCGCGCCGCTCACCGCGCCGGGCCGCCCCGTCGAGTTGGACGGCACGGCCCTGATCGTCGGGGAGGCCGGAGCGCTGCGCGACGCCGTGCTGCGCACGCTGGCGCGCCACGGCGTGGACCGGCTGGTGGTGGTGGACGTGGACGGCACGGCACCAGCCGACGTGGGCGTACCCACCGAGGTGCTCACCGGTGATCCCACCGACCGTGCCGTGCTCGCCGAGGCGGTCCACCGCGCCGCGAACCTGCGCACGGTCGTGCACGCCGTGCAGCCCACGGCCGACGCGCCGCTGGCCGCGCTGAGCCCCGAGGACCTCACGGCCCTGGTCGAGCGGATCGTGGCGCCGGCCCGGCACCTGCACGAACTGACCGCGCACCTGCCGCTGACCCGGTTCGTGCTGTCCGGCTCGGCGGCGGGTGTGCTGGGCGGCATCGGGCAGGCCGCCGTGGCGGCGGCCACCACCGGGTTGGGCGCGCTCGCGGCCCGCCGTCGCGCCGACGGGCTGCCCGCCCAGGTCGTCGCCTGGGGTCCGTCGGCCGGCACCCGCCGGCTCGGGCTGGTGTCCCTCGACGACGCCCGCCTGGCCGCACTGTTCGCGCAGGTCTTGGCGCACGACGTCGACGTGGTGGCCGCGCCCCTGGTCCGGGCGGGGCTGCGGGGGCAGGCGCGGGCGGGCACGCTGCCCGTGGCGCTGCGGGCCCTCGTGCCGGCGCTGCCCGGCGGTGCCACCGGCCTGGCGGCCCGGCTGGCCGGCGCCTCCCCCGCCGAGGGGCGCCGTCTGCTGCTGGACACCATCCGTACCCATGTCGCCGGGGTGCTGGGCCACGACGACGCCAGCGGCATCGACGAGCGCCGCGCCTTCAAGGACCTCGGGTTCGACTCGCTCACCGCCATCGAGCTGCGCAACCGTCTCAACACCGCGCTGGGGCGGACCCTGCCCGCGACGCTGATCTTCGACCACCCCAGTCCCGGCGCTCTGGCCGAACACCTGCGCGACGACCTGCTCGGCCGTGCCGCCGTGGCCGCTGCCCCGGTGGCGGTCGCCAGCGACGAACCGATCGCCATCGTCGCGATGGGCTGCCGCTATCCGGGCGGCATCGCCGACCCCGAGGCGTTGTGGCAGGCGGTGGTGTCGGAACTCGACGCGGTGGGACCGTTCCCGACCGACCGGGGCTGGCCGGCGGACCTGTACGACCCCGACCCGGAGGCCACCGGCCGCACGTACGCGCGTGAGGGCGGCTTCCTCTACGACGCCGCCGGGTTCGACCCGGAATTCTTCGGCATCAGCCCCCGCGAGGCCACCGGCATGGACCCGCAGCAGCGGCTGCTGCTGCAGACCGGCTGGGAGGTGTTCGAGCGGGCCGGGATCGACCCCACGGCGCTGCGCGGCAGCCGTACCGGGGTCTTCGCGGGGGTCGTCTACACCGACTACGGCTCCCGGGCCGACCCGATCCCCGCCGACCTGGAGGGATACCTCGGCATCGGCAGCGCCGGCAGCATCGCCTCCGGCCGCATCGCCTACACCCTCGGCCTGGAGGGCCCGGCGGTCACCGTGGACACCGCGTGCTCCTCGTCGCTGGTGGCGCTGCACCTGGCCGTGCAGTCGCTGCGCCGCGGCGAGTGCGACCTGGCCCTGGCGGGCGGTGCGACGGTGCTGTCCAACCCGGACATCTTCGTCGGCTTCTCGCGCCAGCGGGGCCTGTCCCCGGACAGCCGTTGCAAGGCGTTCGCCGCCGCCGCCGACGGCACCGCCTTCGCCGAGGGTGTCGGCCTGCTGCTGGTGCAGCGGCTCGCCGACGCGCGGCGCGATGGTCGGCCGGTGCTGGCCGTCATCCGGGGCACCGCCATCAACCAGGACGGCGCGTCCAACGGGCTCACCGCACCCAACGGGCCGTCGCAGCAGCGGGTCATCCTGGGTGCGCTGGCCGACGCGGGGCTGCGCCCGTCCGACGTCGACGTGGTGGAGGCGCACGGCACCGGCACCACCCTGGGCGACCCGATCGAGGCGCAGGCGATCATCGCCACCTACGGGCAGGGCCGCGACGAGCCGCTGCTGCTCGGCTCGCTGAAGTCGAACATCGGCCACACCCAGGCCGCAGCCGGTGTCGGCGGCGTGATCAAGATGGTCGCCGCCATGCGACACGGGCTGGTGCCCCGGACCCTGCACGTCGACGAGCCGACCCCGCACGTGGACTGGTCGGCGGGTGCGGTCCGGCTGGTCACCGAGGCGCGGCCCTGGCCGGAGTCGAACCGGCCGCGCCGCGCCGGGGTGTCCTCGTTCGGCATGAGCGGCACGAACGCCCACGTCGTCGTCGAGCAGGGCGACCCGCTCGAGGTGCCGCCGGTGCGCGCCGGCCGCCTCGTACCGGTGCCGGTGTCCGCCGCCAACCCGGCGGCGCTGCGCCGACAGGCCGCCCGTCTGCTCCCCGCCGTGGCCGACCGGCATCCCGCCGACGTGGCCCGTACCCTCGCGGCCCGCACCTCCCTCGCCACCCGGGCCGTCGTGCTCGCGGACGACGCCGACGAGCTGGCCGAGGGCCTACGGGCGCTGGACGACGCGACGTTCACCGGTCCGGTGGGCGACGCCGACGAGCCGGGCAAGGTGGTCTTCGTCTTCCCCGGGCAGGGCGGGCAGTGGACCGGCATGGCTCTGGACCTGTACCGCGACGAGCCCACCTTCCGCGAGTCCCTGGACGCCTGCGCCGCCGCGCTGGCACCGCACGTGGACTGGGCGTTGCTCGACGTGCTCGCCGACGAGGAGGCCCTGCGGCGGGTGGACGTCGTGCAGCCCGCGCTCTGGGCGGTGATGGTGTCGGTGGCCCGGCTCTGGCAGCACCACGGCGTCACGCCCGACGCGGTGGTCGGCCACTCCCAGGGTGAGATCGCCGCCGCCCACGTGGCCGGCGCGCTCAGCCTGGCCGACGCCGCCGCCGTGGTGGCGCTGCGGGCCAGGGCGATCACGGCGATCGCCGGGACCGGCGGCATGGCCTCGGTCGCACTCGGTGTCGGAGAGGTCACCCGGCGCTGGGGCCACACGGTGGCCGTCGCCGCGACCAACGGTCCGGACACCGCGGTGATCGCCGGCGACCCGGGCGTGCTGGACCACATCGCCGCCACGTGTGCCGCCGAGGAGGTCCGGGTGAAGATCCTGCCGGTCGACTACGCCTCACACTCCGCGCACGTGGAGGCACTGCGTGAGGAACTGCTGGCTGCGTTGGAGACCGTGCAACCCCGGGCCGCCGAGATCGCGTTCTGTTCCACGGTCACCGCCGAGGCGCTGGACACCACCACGCTCACGGCCGACTACTGGTACACGAACCTGCGCAGCACCGTGCGCTACGACGAGACGGTCCGCCGGCTGCACGCCGAGGGGCACCGCACCTTTCTGGAGATGAGCCCTCACCCGGTGCTGACCACCGTCACCGAGCAGGTCACCGGGGCGGTCGCGCTGGGCACGCTGCGCCGGGACGAGGGCGACCGCCGCCGCTTCCTCACCGCGCTGGCCGAGGCGTACGTGACCGGCGTGGCGGTGGACTGGCGTCCGGCCGTGGGCGCCGACGCACGGCTGGTGGACCTGCCCACGTATGCGTTCGCCAGCGACCGCTACTGGCTCGACGCGACGACGCGGCCGGTCGACGCCACCGGGCTCGGGCTGGCTGCCACCGCGCACCCACTGCTCGGCGCGGCCGTCGACCTGGCCGACGACGAGGGCGTGCTGCTCACCGGCCGACTGTCGCTCGACAGCCACCCGTGGCTGGCCGACCACACGGTGGCGGGCGTGCCGTTGCTGCCGGGCGCGGCGTTCGTCGAGCTGTGCGCCCAGGCCGCGGAGGCCGCCGGCGCTGCCGGGGTGGCGGAGCTGACCCTGGAGACGCCCTGCGTGCTGCCCGAGCGCGGGGGCGTGGACGTGCAGGTCCAGGTCCGCGACGGCGGGCTGCGCGTGTACTCGCGCAGCGTCGGCGACGCCTGGGTACGCAACGCCTCCGGCGTCCTGCTTCCCACCGAGCCGCCCGCGCCGGCCGGTTGGGGCGCCTGGCCGCCACCCGGGGCGCAGGCCGTCGACGTCGAGGGCCTGTACCCGCAGCTGGCCGCGTCCGGCTACGGGTACGGCCCGGCCTTCCGGGGGCTGCGGGCCGCCTGGCGGCGCGGCGAGGAGGTCTTCGCCGAGGTCCGGCTGCCCGAGGGCCTCGAACCGGAGGGGTACGGTCTGCACCCGGCGCTGCTCGACGCGGCCCTGCACGCGCTGGCGTTCGGGGACTTCCTCGGCGCGGGTGTCCGCCTGCCGTTCGCCTTCACCGGCGTACGGGTGTTCGCCACCGGCGCCGACATCCTGCGCGTACGGCTCAGCCCGCGGGGCGAGGACACCGTGGCGGTGGCGCTGGCGGACTCCACCGGGGCACCGGTCGCCGAGATCGAGTCGCTGGTGCTGCGCGCGGCACCGTCCCTGGAGGCCACCGCGCCGCACGCCCCCGACGTGCTGGTCCTCGACTGGACCCCACTGGCCCTGCCGGACACCCCGGTGACCGAACCGGACCTGCTGGTGGTGGCACCGTCGGATGCGCACGACCCGGTGGCGGCCACCGGCCGGCTGGTGACGTCCACGATCGCCGAACTCGCCGGCCGGCTGGCCGACGACCGGGGCGCGGTCGTCGTGACCCGCGACGCGGTGGCCGTGCGCCCCGGCGATCCTGCCGCCGACCTGGCGCACGCCGCCCTGTGGGGCCTGCTGCGCAGCGCGCAGACGGAGAACCCGGACCGGTTCACGCTCGTCGACACCGACGGGCGGCCCGAGTCGGCAGCCGTGGTGGCGGCGGCCGTGGCGACCGGAGAGCCGCAGATCGCCGTCCGCGAGGGACGCGGGTACGTGCCGCGCCTGGCCCGCGCCGCCGCCAACCGGGGCCTCGTCCCGCCGCCGGGCGCCTGGCGGCTGGAGGCGGCCGGCACCACTGTGGACGAGCTGCGCCTGACGGAGGTGACCGAAGCGCCGCTGCCGGCCGGGCACGTCCGGGTCGCGGTACGCGCCTGCGGGCTGAACTTCCGCGACGTGCTGGCCACCCTGGGCGTCGTACCCCGCGACGCCCCGCTGGGCGCGGAGGGTGCGGGCGTGGTGGTCGAGGTCGGCGTCGGTGTCACCGGCTTCGCCCCCGGTGACCGGGTGTACGGCTTCCTCCAGGGCGCCATCGGCCCGCGCGCCGTCGTGGACGCGCGGCTGCTCGCCCACCTGCCCGCCGGATGGTCCTTCGCGCAGGCGGCCACAGCGCCGGCGGTCTGCACCACCGCCTACTACGCGCTGGTCACCCTGGCGGACCTGCGCCCCGGGGAGCGGGTGCTGATCCACTCCGCCGCCGGCGGGGTCGGTCTGGCCGCCGGGCACCTCGCCCGGCACCTGGGCGCCGAGGTGTTCGGCACGGCGAGCCCGGCCAAGTGGGCGGCGCTGGACCTGGACGAGGCGCACCTGGCGTCGTCGCGGAACACCGACTTCGCCGACCGGTTCGGCCCGGTCGACGTGGTGCTCAACTCGCTGACCGGGGAGTTCATCGACGCGTCCCTGCGCCTGCTGGGTCCGGGCGGTCGGTTCGTGGAGATGGGTGTGGCGGACCTGCGGTCGTCCGAGCAGATGCCCACCGGCGTCGACTACCACGCGTTCGAGCTGCTCGACCTGGCCCCCGCGCGGGTGGGCGAGCTGTTCGCCGAGGTGGTCCGGCTGATCGACCAGGGGGTCTTTCCGCCGCTGCCGGTCACCGCCTGGGACGTCCGGCGGGCGCCGGAGGCGCTGCGCTACTTCAGCCAGGCCCGGCAGATCGGCAAGATCGCCCTGACCGCCCCGGTCCCGCTCGACCCGAACGGCACGGTCCTGGTCACCGGCGGCACGGGCAGCCTCGGCGGCCTCGTCGCCCGGCACCTGGCGCGCGCCCACGGGGTACGTCACCTGCTGCTGGTCAGCCGGTCCGGTCCGGCCGCGCCCGGCGCGACGGAGCTGGTCGGTGAGTTGACCTCCCTGGACGTACGGGTGGACGTGGTGGCGGCCGACCTGGCCGACCGGGCGGCGGTCGCCGGGGTGTTGGCGGCGGTGCCGCCGGAGCACCCGCTCACCGCCGTCGTGCACACTGCCGGTGTCCTGGACGACGGCGTCCTGGAGTCGTTGACCCCGCAGAAGATCGCCCGGGTGCTCGCACCGAAGGTAGACGCCGCGTGGCACCTGCACGAGCTGACCCGGGACCTGGACCTGTCGGCGTTCCTGCTGTTCTCCTCGGCGTCGGGTCTGCTGGGCGGTGCGGGGCAGGCCAACTACGCGGCGGCCAATGCGTTCCTGGACGCGCTGGCCACGGCGCGGCGCCGCGCCGGCCTGCCCGCCGTGTCGCTGGCCTGGGGCATGTGGGCGCGGGCCACCGGCCTGACCGCCCACCTGGGCGGCACGGACCTGGGCCGCATCGAACGCGGCGGCCTGCTGCCGATGACCGACGAGCAGGGCCTGGCTTTGTTCGACGCCACCTGGACGGCCGACCGTCCGGTGCTGGTGCCGGCGCCGCTGCGCCTGGACCGGGGCCGCACCGGATCCGGTGTGGTGCCGGCCGTGCTGCGCGCGCTGGTGCGGCCGGTGCGCCGGGTGGCCCGCTCGGCGGGGACGGCGTCGCCGGACTCGCTGCGCGAGCGGCTGCTGCCGCTGTCCCCGACGGAGCGCACGGCCCTGCTGGTGGACCTGGTCCGTACACAGGTCGCGGCGGTCCTGGGCCACACCGACACCGACGCCGTGGTGGTGGACCGGGCGTTCAAGGACAGCGGTTTCGACTCGTTGACGGCGGTGGAGCTGCGCAACCGGGTGTCCCGCGCCACCGGGCTGCGGCTGCCACCCACCGTGGTGTTCGACCGCCCCACGCCGGCGGAGTTGGCCGCGCACCTTCTCGACCAGCTCGTGCCGCCTGCCGACGGGCCGGCCGGCGCGGCGACGCCCGCCCGCAAGACCCGAAAGCAACTCGACTCGGCCACGGTCGAGGAGATCTTCGACTTGATCGACTCCCAGCTCGGCCGGGGGTCTCGCAGCGACTATCAGGAGGTCGACGCCGGGTGA",
    "translation": "MTTPSKGTDSIADQQKLREYLRRVTDDLLRTRRRLTEVESADREPVAIVSMACRFPGGVASPEDLWQLVASGTDAISGFPDDRGWPLDELYDPDPEHPGTSTTRQGGFLHDAADFDPEFFGISPREALTIDPQQRLLLETAWEAVERAGIAPDSLRGSRTGVFAGVMYGDYGARLRPIPAGFEGYMGTGSAGSVATGRIAYTLGLEGPAVSVDTACSSSLVALHLAAQALRRGECDLALAGGVTVIATPELFVEFSRQRGLSPDGRCKAFAASADGTGWAEGVGLVLVERLADARRNGHPVLALLRGSAVNQDGRSSQLSAPNGPAQRRVIRAALASAGLEPAEVDLVEAHGTGTRLGDPIEAQALLAEYGQGRTEPLWLGSLKSNIGHTQAAAGVGGVIKVVQAMRHGLLPATLHADEATPHVDWSVGDVRLLTEARDWPARERPRRAAVSSFGISGTNAHVILEEGDPDGVADAPPDDVLARKPVPVVLSAHTASALGPQAARLRAHLDAHPDLTVADVAHSLATTRTPLAERAVLVAADLDELRTALDAVADGDEPPVRGTAGHPGGVVFVFPGQGAQWAGMALDLYREDEVFRAALDDCERALAPHVDWSLRAVLADADALGRVDVVQPALWAVMVSLAALWQHHGVTPDAVVGHSQGEIAAACVAGALSLEQAAAVVALRARAITAVAGRGAMASVSVPAQQITERWGDRITVAVTNSADATVVAGEPEAVAEVVAAYDAEGVRARVLPVDYASHSAHVEPVREPILDALRDLTPTEARVPFHSTVTGAEFDTRGLTADYWYTNLRSTVRFDQAVTRLREQGHRIFVEISPHPVLTPVLGEGAFGTLRRDEGDRRRFITSLGAVHAVGVPVDWSAAIGPARRVPLPTYAFQRSRYWLDAPARTGDASGVGVGPTDHPLLGGAVDVAGDGTLVLTGRLVPGADRAAAELRVGGVPVLSGTALLDLALRAGELAGLGAVGEFSVETPLVLSATAGWLQVVVAPAGADGDREIGVYARPDHEAPWTRHGHGVLVPATAQDLPPHRPVPGAPLAPDEAVERLAAAGVELASAPTAVSGDADGYVADLASPPEGRFTLHPALLDAALLPAFGRGDARLPSRWRGVRLPQPDGQPTRASVRRRDGDSWAVSLTDSAGAPVVEIAEVVLGPVPVVSAAGHHDPLFTLEWAPVARPRGAAATEPVPHELPGDAGPAALAVLRGGLAEPDGPRQVVVARGAGTVTGLVRCAQLEEPGRVGLVEWDGRDADALRDAVAAGLPQVAVHGAELRTPRLAPLTAPGRPVELDGTALIVGEAGALRDAVLRTLARHGVDRLVVVDVDGTAPADVGVPTEVLTGDPTDRAVLAEAVHRAANLRTVVHAVQPTADAPLAALSPEDLTALVERIVAPARHLHELTAHLPLTRFVLSGSAAGVLGGIGQAAVAAATTGLGALAARRRADGLPAQVVAWGPSAGTRRLGLVSLDDARLAALFAQVLAHDVDVVAAPLVRAGLRGQARAGTLPVALRALVPALPGGATGLAARLAGASPAEGRRLLLDTIRTHVAGVLGHDDASGIDERRAFKDLGFDSLTAIELRNRLNTALGRTLPATLIFDHPSPGALAEHLRDDLLGRAAVAAAPVAVASDEPIAIVAMGCRYPGGIADPEALWQAVVSELDAVGPFPTDRGWPADLYDPDPEATGRTYAREGGFLYDAAGFDPEFFGISPREATGMDPQQRLLLQTGWEVFERAGIDPTALRGSRTGVFAGVVYTDYGSRADPIPADLEGYLGIGSAGSIASGRIAYTLGLEGPAVTVDTACSSSLVALHLAVQSLRRGECDLALAGGATVLSNPDIFVGFSRQRGLSPDSRCKAFAAAADGTAFAEGVGLLLVQRLADARRDGRPVLAVIRGTAINQDGASNGLTAPNGPSQQRVILGALADAGLRPSDVDVVEAHGTGTTLGDPIEAQAIIATYGQGRDEPLLLGSLKSNIGHTQAAAGVGGVIKMVAAMRHGLVPRTLHVDEPTPHVDWSAGAVRLVTEARPWPESNRPRRAGVSSFGMSGTNAHVVVEQGDPLEVPPVRAGRLVPVPVSAANPAALRRQAARLLPAVADRHPADVARTLAARTSLATRAVVLADDADELAEGLRALDDATFTGPVGDADEPGKVVFVFPGQGGQWTGMALDLYRDEPTFRESLDACAAALAPHVDWALLDVLADEEALRRVDVVQPALWAVMVSVARLWQHHGVTPDAVVGHSQGEIAAAHVAGALSLADAAAVVALRARAITAIAGTGGMASVALGVGEVTRRWGHTVAVAATNGPDTAVIAGDPGVLDHIAATCAAEEVRVKILPVDYASHSAHVEALREELLAALETVQPRAAEIAFCSTVTAEALDTTTLTADYWYTNLRSTVRYDETVRRLHAEGHRTFLEMSPHPVLTTVTEQVTGAVALGTLRRDEGDRRRFLTALAEAYVTGVAVDWRPAVGADARLVDLPTYAFASDRYWLDATTRPVDATGLGLAATAHPLLGAAVDLADDEGVLLTGRLSLDSHPWLADHTVAGVPLLPGAAFVELCAQAAEAAGAAGVAELTLETPCVLPERGGVDVQVQVRDGGLRVYSRSVGDAWVRNASGVLLPTEPPAPAGWGAWPPPGAQAVDVEGLYPQLAASGYGYGPAFRGLRAAWRRGEEVFAEVRLPEGLEPEGYGLHPALLDAALHALAFGDFLGAGVRLPFAFTGVRVFATGADILRVRLSPRGEDTVAVALADSTGAPVAEIESLVLRAAPSLEATAPHAPDVLVLDWTPLALPDTPVTEPDLLVVAPSDAHDPVAATGRLVTSTIAELAGRLADDRGAVVVTRDAVAVRPGDPAADLAHAALWGLLRSAQTENPDRFTLVDTDGRPESAAVVAAAVATGEPQIAVREGRGYVPRLARAAANRGLVPPPGAWRLEAAGTTVDELRLTEVTEAPLPAGHVRVAVRACGLNFRDVLATLGVVPRDAPLGAEGAGVVVEVGVGVTGFAPGDRVYGFLQGAIGPRAVVDARLLAHLPAGWSFAQAATAPAVCTTAYYALVTLADLRPGERVLIHSAAGGVGLAAGHLARHLGAEVFGTASPAKWAALDLDEAHLASSRNTDFADRFGPVDVVLNSLTGEFIDASLRLLGPGGRFVEMGVADLRSSEQMPTGVDYHAFELLDLAPARVGELFAEVVRLIDQGVFPPLPVTAWDVRRAPEALRYFSQARQIGKIALTAPVPLDPNGTVLVTGGTGSLGGLVARHLARAHGVRHLLLVSRSGPAAPGATELVGELTSLDVRVDVVAADLADRAAVAGVLAAVPPEHPLTAVVHTAGVLDDGVLESLTPQKIARVLAPKVDAAWHLHELTRDLDLSAFLLFSSASGLLGGAGQANYAAANAFLDALATARRRAGLPAVSLAWGMWARATGLTAHLGGTDLGRIERGGLLPMTDEQGLALFDATWTADRPVLVPAPLRLDRGRTGSGVVPAVLRALVRPVRRVARSAGTASPDSLRERLLPLSPTERTALLVDLVRTQVAAVLGHTDTDAVVVDRAFKDSGFDSLTAVELRNRVSRATGLRLPPTVVFDRPTPAELAAHLLDQLVPPADGPAGAATPARKTRKQLDSATVEEIFDLIDSQLGRGSRSDYQEVDAG",
    "product": "type 1 polyketide synthase"
   },
   {
    "start": 43410,
    "end": 46388,
    "strand": 1,
    "locus_tag": "abyB3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyB3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75504.1</span><br>\n Gene: <span class=\"serif\">abyB3</span><br>\n \n Location: 43,410 - 46,388,\n (total: 2979 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: mod_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 270.7; E-value: 3.7e-82)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyB3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (36..451)</dt>\n   <dd>\n   \n    found active site cysteine: True, scaffold matched GSSS: True<br>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n   <dt><strong>PKS_AT</strong> (550..838)</dt>\n   <dd>\n   \n    (Methyl)Malonyl-CoA specificity inconclusive<br>\n   \n    found active site serine: True, scaffold matched GHGE: True<br>\n   \n   </dd>\n  \n   <dt><strong>ACP</strong> (915..986)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyB3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08990.14 (Erythronolide synthase docking domain): [5:32](score: 31.3, e-value: 1.2e-07)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [34:278](score: 272.3, e-value: 4.3e-81)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [285:401](score: 147.6, e-value: 1.6e-43)<br>\n \n  PF16197.8 (Ketoacyl-synthetase C-terminal extension): [403:513](score: 58.0, e-value: 1.2e-15)<br>\n \n  PF00698.24 (Acyl transferase domain): [549:858](score: 178.8, e-value: 2e-52)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [917:984](score: 48.2, e-value: 1.1e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyB3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08990.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016740' target='_blank'>GO:0016740</a>: transferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyB3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyB3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75504.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyB3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCGAGACACGCGAGGAGAAGCTCGTCGAGTACCTGAAGTGGGTCACCGGTGAGCTGCAGGAGACCAAGGCCCAACTCGCCAGGGCGAGGGCGGAACGCGAACCGATCGCGATCGTCTCGGCCGCCTGCCGGCTGCCCGGCGACGTCCACTCCCCCGAGGACCTGTGGCGCGTCGTGGTCGACGGTGTCGACGCCATCGGCGACGTCCCCACCGACCGGGGTTGGGCGGTGCATGAGGTGTACGCCGACGCGCCCGCGCACCGCCCGCTGGGCGGGTTCCTGTCCGACGCGGCCGGCTTCGACGCCGCGTTCTTCGGTATCGGCCCGCACGAGGCCACCGCCATGGACCCGCAGCACCGGCTGCTGCTGGAGTCGTCGTGGGAGGCGGTGGAGCGCGCCGGCATCGACCCGACCACCCTGCGCGGCAGCGCCACCGGGGTGTACGCGGGCCTGGTGTCGCAGAACTACGCCGCGTACGGCACCCCACCGGAGCTCAACGGCCACCTCATGACCGGCACGGCCACCAGCGTGGCGTCCGGCCGGATCGCCTATCTGCTGGGGCTGCGCGGCCCGGCGGTCACCCTGGACACCGCCTGCTCGTCGTCGCTGGTGGCCCTGCACCTGGCGGCGCAGGCGCTGCGCCGGGGCGAGTGCGATCTCGCGCTGGCCGGCGGGGCCACGGTCATGGCCACCCCGGCGTTGCTGGCGGAGTTCGTCACCCAGGGCGGGCTCTCGCCCGACGCCCGGTGCAAGGCGTTCGCGGCGGCGGCCGACGGAACGGGTTTCGCCGAGGGGGTCGGGGTGCTCGTGCTGGAACGCCTGGCCGACGCCCGGCGCCACCACCGGCGCGTGCTCGCGGTGCTGCGCGGCTCGGCGGTGAACCAGGACGGCGCGTCCAACGGGCTGACCGCGCCGAGCGGCCCCGCGCAGGAGGAGGTGATCCGCGCCGCGCTGGCCGACGCGGGCCTGCGACCGTCCGACGTGGACCATGTGGAGGCGCACGGCACCGGCACCCGGTTGGGCGACCCCATCGAGGCGGCGGCCCTGCTCGCCACCTACGGTCAGGACCGCGCCGAGCCGCTGTGGCTGGGTTCGGTGAAGTCCAACATCGGGCACACCCAGACCGCCGCCGGTGTGGCCGGGGTGATCAAGGTGATCGAAGCCCTGCGCCACGAGCGCCTGCCGCGCACCCTGCACGTCGACGAGCCCACTCCGCACGTCGACTGGGCGGCGGGGAAGGTACGGCTGCTCACCGAGGAGCAGCCGTGGCCGCGCGGGAAACGCCGCCGGGTGGCGGGGGTGTCGTCGTTCGGCATCAGCGGCACCAACGCCCACGTGCTCATCGAGGAGGGCGACCCGGAGCCGCCGCCCACGCCGCCCACGCCCTCCGCCCACCCGGTCGCCTGGCTGCTCGGCGCCAAGACCGACAGCGCGCTGCGCGCGCAGGCCGCGCGCCTACGCCAACGGTTCGCCGTCGCGTCGCACGACCCGCTGGACGTGGCGGTCGCGCTGGCCACCACCCGCACCGCGTTCGACCGGCGGGCGGCCGTGGTGGCGGCCGACCACGACGGCCTGCTGCGCGGTCTCGACGCGCTGGCCGCCGGGGAGACGACACCGGGACGGGCGGTACGGGGACCCACCGCCTTCCTCTTCTCCGGGCAGGGCAGCCAGCGCGTCGGCATGGGTACCGAGCTGCGGCGGGTCTTCCCTGCCTTCCGCGACGCCTGGCGGGAGGTCGCCGACGAGGTCGACCGGCACCTGGACCAGCCCCTGGACCGCGTGCTGGCCGACGAGGACCTGCTGCTGCGCACCGAGTACGCCCAGCCCGCGTTGTTCACCCTGGAGGTGGCCCTGGTCCGCTTGCTGGGCGGCTGGGGTCTGCGGCCGGACCTGCTGCTCGGTCACTCGCTCGGCGAACTGGTCGCGGCGCACGTCGCGGGGGTCCTCGACCTGCCCGACGCCGTCGCGCTGGTCGCGGCGCGGGGTGCGGCCATGCAGGCGGCCCCGGCCGAGGGCGCCATGGTTGCGATCCGGGCCGCCGCCGACGAGGTACGGGCCAGCCTCGCCGGCCGCGAGCACGAGGTGTCCGTCGCGGCGGTGAACGGCCCCCGCTCGACAGTCGTCTCCGGCGATGCCGGTGCGGTGCAGGAGGTCGCGGCCCACTGGGCGGCCACCGGGCACCGGACGTCGCGATTGCGGGTCAGCCACGCCTTCCACAGCCCGCACCTGGACGGGGTGCTGGACGGGTTCCGCGCGGTCGCCGCCGGCGTACGCCACCACCCGCCGAGCATCCCGGTCGTGTCGAACCTGACCGGCACGGTCGTCGAGGCGTTCACCGCCGAGCACTGGGTGCGGCACGTGCGCCAGGAGGTCCGCTTCGCCGCCGGCGTGTCCGCGCTCACCTCGGCGGGCGTACGCCGTTTCGTGGAGGTCGGCCCGGACGCGGTGCTGGCTGCCCTGGCCGGCGAGAACGCCCCTGGGACACCCGTCGTGGCGACCCTGCGCCGCGACGAGTCCGAGGCGTTGACCGTCGTCCGGGCGCTGGCGGCGAGCCACGTCACCGGCGCTCGGGTGGACTGGCGGGCGTTCCACGACGAGCGGACGGCGGCGGTGCCGCTGCCCACGTACCCCTTCGAGCACCGCCGCTACTGGGTGTCCCCGCCGACCGGCCCGGCGCCCACCGCCCCGCCGCCGGTGGCCGACGAGCCGCCGCGGGAGTCGACGCCACACGAGGAGCGGTTGCTCGACCTGGTCCGCACGCACGCGGCGGCGGTGCTGGGCCACGACACGCCGGAATCGGTGGGCCCGGACGACAACTTCGTGGAGATCGGGCTGTCGTCGTTCACCGCGCTGGAGGTGCGCAACCGGCTCTGCGAGGGCACCGGCCTGGAACTGTCGCCGCTGGCGCTGTTCGAACACCCCACCCCTGCCGCGCTGGCGGAGCACCTGCGGGCCGTACGGGCCGCGCGGACGTGA",
    "translation": "MSETREEKLVEYLKWVTGELQETKAQLARARAEREPIAIVSAACRLPGDVHSPEDLWRVVVDGVDAIGDVPTDRGWAVHEVYADAPAHRPLGGFLSDAAGFDAAFFGIGPHEATAMDPQHRLLLESSWEAVERAGIDPTTLRGSATGVYAGLVSQNYAAYGTPPELNGHLMTGTATSVASGRIAYLLGLRGPAVTLDTACSSSLVALHLAAQALRRGECDLALAGGATVMATPALLAEFVTQGGLSPDARCKAFAAAADGTGFAEGVGVLVLERLADARRHHRRVLAVLRGSAVNQDGASNGLTAPSGPAQEEVIRAALADAGLRPSDVDHVEAHGTGTRLGDPIEAAALLATYGQDRAEPLWLGSVKSNIGHTQTAAGVAGVIKVIEALRHERLPRTLHVDEPTPHVDWAAGKVRLLTEEQPWPRGKRRRVAGVSSFGISGTNAHVLIEEGDPEPPPTPPTPSAHPVAWLLGAKTDSALRAQAARLRQRFAVASHDPLDVAVALATTRTAFDRRAAVVAADHDGLLRGLDALAAGETTPGRAVRGPTAFLFSGQGSQRVGMGTELRRVFPAFRDAWREVADEVDRHLDQPLDRVLADEDLLLRTEYAQPALFTLEVALVRLLGGWGLRPDLLLGHSLGELVAAHVAGVLDLPDAVALVAARGAAMQAAPAEGAMVAIRAAADEVRASLAGREHEVSVAAVNGPRSTVVSGDAGAVQEVAAHWAATGHRTSRLRVSHAFHSPHLDGVLDGFRAVAAGVRHHPPSIPVVSNLTGTVVEAFTAEHWVRHVRQEVRFAAGVSALTSAGVRRFVEVGPDAVLAALAGENAPGTPVVATLRRDESEALTVVRALAASHVTGARVDWRAFHDERTAAVPLPTYPFEHRRYWVSPPTGPAPTAPPPVADEPPRESTPHEERLLDLVRTHAAAVLGHDTPESVGPDDNFVEIGLSSFTALEVRNRLCEGTGLELSPLALFEHPTPAALAEHLRAVRAART",
    "product": "type 1 polyketide synthase"
   },
   {
    "start": 46457,
    "end": 47149,
    "strand": -1,
    "locus_tag": "abyC",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyC</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75505.1</span><br>\n Gene: <span class=\"serif\">abyC</span><br>\n \n Location: 46,457 - 47,149,\n (total: 693 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1057:TetR family transcriptional regulator (Score: 94.7; E-value: 1.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyC collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00440.26 (Bacterial regulatory proteins, tetR family): [19:65](score: 54.3, e-value: 9.3e-15)<br>\n \n  PF14246.9 (AefR-like transcriptional repressor, C-terminal domain): [94:210](score: 88.6, e-value: 3e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyC collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00440.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyC\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyC\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75505.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyC.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyC\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyC\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGAGCGCGACACCCGAAACGCACCGCGCGGCAGGTTGGACAAGCGGCAGGCGATCATCGCCGCGGCCCTGCGCGTGTTCGCCCGCGAGGGCTACGGCCAGGCCAGCCTGGACACCATCGCGGCCGAGGCCGGGGTGGCGAAGCCGACCATCTACAACCACCTGGGCGGCAAGGAGAACCTGTTCCGGCACGTCCTCGCCGAGATTGCCGCGCGGTCGAACGCCAAGACCCTCGCAGCTCTCCAGACGTTCCCCACCGACCCTCAGGAGCTGCGCGACCACCTCAACACCGTCGGCCTGCGGCTGGCCGAATGCTTCGTCGACGAGCAGTCCTCGGCGCTGCGCCGGCTGCTGCACGCAGAGATCGCGCGCTTTCCCGACCTGTTCGACGTCGTGCTCGACAGCGGGCCGAACCAGGCCACCGAGGCGCTCGCGGGCCGGCTTGCACGGCTGGCCAACGCCGGCTACCTGACGATCGAGGACCCGATCCGCGCCGCCCGCCAATTCGTCGCCCTGCTGACCGACGAGCTGCCCGCGATGACCGCGCTCGGCACCCGCCCGATCAACCCGGACGACCTGGAACGCGCGGTGACCGCCGGGGTGGACACGTTCCTGCGGGCCTTCGCCACACCGACCGACGCCCCGGCCGACCCGCCCGCGCGCGAGGCGGTCGGGCCGCTGCCAGGCTGA",
    "translation": "MTERDTRNAPRGRLDKRQAIIAAALRVFAREGYGQASLDTIAAEAGVAKPTIYNHLGGKENLFRHVLAEIAARSNAKTLAALQTFPTDPQELRDHLNTVGLRLAECFVDEQSSALRRLLHAEIARFPDLFDVVLDSGPNQATEALAGRLARLANAGYLTIEDPIRAARQFVALLTDELPAMTALGTRPINPDDLERAVTAGVDTFLRAFATPTDAPADPPAREAVGPLPG",
    "product": "TetR regulatory protein"
   },
   {
    "start": 47233,
    "end": 48660,
    "strand": 1,
    "locus_tag": "abyD",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyD</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75506.1</span><br>\n Gene: <span class=\"serif\">abyD</span><br>\n \n Location: 47,233 - 48,660,\n (total: 1428 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 355.1; E-value: 7.5e-108)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyD collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07690.19 (Major Facilitator Superfamily): [20:413](score: 187.5, e-value: 3.5e-55)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyD collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00711 (efflux_EmrB: drug resistance MFS transporter, drug:H+ antiporter-2 (14 Spanner) (DHA2) family): [13:422](score: 342.6, e-value: 8.5e-103)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyD collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyD\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyD\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75506.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTQSPSDRIDGPLLRLLGVMVLGGVMSYFDATIINVSVETLTAHFDATLGTISWVATGYLLAVAVAIPLAGWAVARFGARRVWLAALTLFLVASALCALAWDVGSLIAFRVFQGFAGGLLEPIMLTVVATAAGPSRMGRAMGLISIPITLGPVLGPIIGGLILQNLTWQWIFLVNVPIALLAIALALLIMRDDRPEPGAAPPLDLIGVALLSPGFAALIYALSQAGTAGFGATRVIVGLAVGVVLVAAYVAHALRSAQPLIDLRLFRSSGFTSSVLTMFLLGGMLFSLLFLLPLFYQQVRGQGVLAAGLLLVPLGLGTMVGMPVAGKLADTFGPRRLVPTGALLIALSALVYTQAGPDTSQVLLTAAQLVTGFGLGLVGAPTMGSVYRTVAPEAVGGATGTLFILNQIGASLGVAVVALIVQSGLTDGRTPADSFDQAFWWTVAGGVIVALASRFLPGRPQPVTPTPADAETAAA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyD.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyD\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyD\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCCAATCCCCATCCGACCGCATCGACGGCCCACTGCTTCGCCTGCTCGGCGTCATGGTCCTCGGCGGGGTGATGTCCTACTTCGACGCCACGATCATCAACGTGAGCGTCGAGACGCTGACCGCTCACTTCGACGCCACACTGGGCACGATCTCGTGGGTCGCCACCGGTTACCTGCTCGCCGTGGCCGTCGCCATCCCGCTCGCCGGGTGGGCGGTGGCCCGCTTCGGCGCGCGCCGCGTGTGGCTGGCCGCGCTGACCCTCTTCCTGGTTGCCTCGGCGCTGTGCGCCCTGGCCTGGGACGTGGGCAGCCTGATCGCCTTCCGCGTGTTCCAGGGCTTCGCCGGCGGCCTGCTCGAACCCATCATGCTCACCGTGGTCGCCACGGCGGCCGGCCCGAGCCGGATGGGCCGCGCGATGGGCCTGATCTCCATCCCGATCACCCTGGGACCGGTGCTCGGCCCGATCATCGGCGGTCTGATCCTGCAGAACCTGACCTGGCAGTGGATCTTCCTGGTCAACGTGCCGATCGCGCTGCTGGCCATCGCCCTGGCGCTGCTGATCATGCGCGACGACCGGCCCGAGCCGGGCGCCGCGCCGCCGCTGGACCTGATCGGTGTCGCCCTGCTCTCCCCCGGCTTCGCCGCCCTGATCTACGCGCTGTCGCAGGCCGGCACGGCCGGGTTCGGCGCCACCCGGGTCATCGTCGGGCTCGCCGTGGGGGTGGTGCTGGTCGCCGCGTACGTGGCGCACGCGCTGCGTTCCGCACAGCCGCTCATCGACCTGCGCCTGTTCCGCAGCAGCGGCTTCACCTCCAGCGTGCTCACCATGTTCCTACTCGGCGGCATGCTGTTCTCGCTGTTGTTCCTGCTGCCGCTGTTCTACCAGCAGGTGCGCGGGCAGGGCGTGCTCGCCGCCGGACTGCTGCTCGTACCGCTCGGGCTGGGCACGATGGTCGGCATGCCGGTGGCCGGCAAGCTCGCCGACACCTTCGGCCCCCGCCGGCTGGTACCGACCGGCGCCCTGCTGATCGCGCTCAGCGCCCTCGTCTACACCCAGGCCGGACCGGACACCTCGCAGGTCCTGCTCACCGCCGCCCAACTCGTGACCGGCTTCGGCCTCGGCCTCGTCGGCGCACCGACGATGGGCTCCGTCTACCGCACCGTCGCGCCCGAGGCGGTGGGCGGCGCGACCGGCACCCTGTTCATCCTCAACCAGATCGGCGCGTCGTTGGGCGTGGCGGTGGTCGCGCTCATCGTGCAGAGCGGCCTCACCGACGGCCGGACGCCCGCCGACTCCTTCGACCAAGCCTTCTGGTGGACCGTCGCCGGTGGCGTGATCGTCGCACTGGCCAGCAGGTTCCTGCCCGGACGCCCGCAGCCCGTCACCCCCACACCGGCCGATGCGGAGACCGCCGCGGCCTGA",
    "translation": "MTQSPSDRIDGPLLRLLGVMVLGGVMSYFDATIINVSVETLTAHFDATLGTISWVATGYLLAVAVAIPLAGWAVARFGARRVWLAALTLFLVASALCALAWDVGSLIAFRVFQGFAGGLLEPIMLTVVATAAGPSRMGRAMGLISIPITLGPVLGPIIGGLILQNLTWQWIFLVNVPIALLAIALALLIMRDDRPEPGAAPPLDLIGVALLSPGFAALIYALSQAGTAGFGATRVIVGLAVGVVLVAAYVAHALRSAQPLIDLRLFRSSGFTSSVLTMFLLGGMLFSLLFLLPLFYQQVRGQGVLAAGLLLVPLGLGTMVGMPVAGKLADTFGPRRLVPTGALLIALSALVYTQAGPDTSQVLLTAAQLVTGFGLGLVGAPTMGSVYRTVAPEAVGGATGTLFILNQIGASLGVAVVALIVQSGLTDGRTPADSFDQAFWWTVAGGVIVALASRFLPGRPQPVTPTPADAETAAA",
    "product": "EmrB/QacA drug resistance transporter"
   },
   {
    "start": 48731,
    "end": 49738,
    "strand": 1,
    "locus_tag": "abyE",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyE</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75507.1</span><br>\n Gene: <span class=\"serif\">abyE</span><br>\n \n Location: 48,731 - 49,738,\n (total: 1008 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1251:luciferase family protein (Score: 100.5; E-value: 1.8e-30)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyE collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00296.23 (Luciferase-like monooxygenase): [16:299](score: 132.6, e-value: 2.1e-38)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyE collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03558 (oxido_grp_1: luciferase family oxidoreductase, group 1): [6:328](score: 388.8, e-value: 4.6e-117)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyE collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00296.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyE\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyE\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75507.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyE.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyE\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyE\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGACACACCGCCCGTATCCGTCCTCGACGTCGTTCCGGTCTGGAGCGGCTCCACGGCGACGCGCGCCCTGCGCGACTCCGTGCAGCTCGCCGTCGAGGTCGAGCGGCTCGGTTACACCCGCTACTGGGTGGCCGAGCACCACAACACCCCGTGCCTGGCCACCGCCACGCCTCCCGTCCTGGTCGGCGCCCTGCTGGCGGCCACCTCGACGCTGCGGGTGGGCTCCGGCGGGGTCCTGCTGCCCAACCACCCCCCGCTGGTGGTCGCCGAGCAGTTCGGCACCCTCGCCGCGCTGTACCCGGGCCGCGTCGACCTCGGGGTCGGTCGCGCCCCCGGCACCGACGCCGCCACGGCCCGTGCCCTGCGCCGGGCACCCGACGGCGCCGACCAGTTCCCGACGGAGCTCGCCGAGCTGATCGACCACTTCGGCCCGGCACCGCGTCCCCGGCAGATCACCGCCGTGGCCGCTGCCGAGTCCGAGGTACCGGTCTGGATCCTGGGCTCCAGCCCCGGCAGCGCCCGCCTGGCCGGCTCGCTCGGGCTGCCGTACGCGTTCGCCCACCAGATCAACCCGACCCTCACCGCCACCGCGCTGCAGCTCTACCGGAAGTCGTTCCGCCCCTCGGCACACCTCGCCGATCCGCACGCGATCCTGTCGGCCGTGGTCGTGGTCGGCGAGAACGACGAGCACGCCGAGCGGCTGATCGCGCCGTACCTGCTCGGTCAGATCGGGCACCGCACCGTCGGTCGACTGGACCCCTTTCCGAACGCGGCGCAGGCTCAGCAGCACTCGTACACCGACGCCGAACGGGCCTTCGTCGCCGAGCGGATCACCAGCCAGATAGTGGGCGGCCCCGAAACGGTGCGCGAGCGGGTCCAGCGGTTGCACGCGGAGACCGGCGCGAACGAGCTGATGGCGCTGACCATCCTGCCCGAGCTGGAGGACCGCGTGCGCTCTTACGCCCTGCTGGCCGACGCCGTCCGGGCCAGCATCGCCGTGTAG",
    "translation": "MTDTPPVSVLDVVPVWSGSTATRALRDSVQLAVEVERLGYTRYWVAEHHNTPCLATATPPVLVGALLAATSTLRVGSGGVLLPNHPPLVVAEQFGTLAALYPGRVDLGVGRAPGTDAATARALRRAPDGADQFPTELAELIDHFGPAPRPRQITAVAAAESEVPVWILGSSPGSARLAGSLGLPYAFAHQINPTLTATALQLYRKSFRPSAHLADPHAILSAVVVVGENDEHAERLIAPYLLGQIGHRTVGRLDPFPNAAQAQQHSYTDAERAFVAERITSQIVGGPETVRERVQRLHAETGANELMALTILPELEDRVRSYALLADAVRASIAV",
    "product": "luciferase/monooxygenase"
   },
   {
    "start": 49826,
    "end": 51442,
    "strand": 1,
    "locus_tag": "abyF1",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75508.1</span><br>\n Gene: <span class=\"serif\">abyF1</span><br>\n \n Location: 49,826 - 51,442,\n (total: 1617 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1068:extracellular solute-binding protein family 5 (Score: 373; E-value: 4.4e-113)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF1 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00496.25 (Bacterial extracellular solute-binding proteins, family 5 Middle): [79:446](score: 239.3, e-value: 7.4e-71)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75508.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMRTTTRSTAILLLLVAATAACGTSAAQTGDAQPTTGGALTFATAVEPDCLDPAVSARDVTGVINRNIFDSLVRQAPDGSFHPWLAERWETAPDGRAYTFHLRSGVRFHDGTTLDAAAVKATLDHAVDPATESRFAAGLLAAYRSAEVTDASTVTVRLSRPDAALLQTLSTPYLGIQSPRSLRENKDGLCEQPIGSGPFRFVRWEKKVGIDLSRYPDYAWSPSGATHQGPARLDTLRITFVAEDSVRLGSLTSGQVQVSDVPASKARTVQGSAHLLKTEVPGAPYTIFLNSSRDAILADIRVRQALRRAVDLDQLVKSIYFGQNQRAWSPLTPATPLYDDSTRDAFTFDQAEANRLLDEAGWTQRDSAGYRLKDGRRLTLRWPHTAAMERDQRNLIGQGLQSQAKQVGIEIQYTLVDQGTIGDLIGKRALDLFDVSFTRSDPDILRYFFGTKSTLAEGGGNIFGLDIPELDKLLTDGVSTLDPAQRQRIYSDAQRYVVENAVSLPVYVPTSLLGVARHVHGVEFGANATPLFAGAWIAG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF1.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCGCACGACAACCCGCTCGACAGCCATTCTGCTGCTCCTGGTCGCCGCCACCGCGGCCTGCGGCACCTCCGCGGCCCAGACCGGCGACGCCCAGCCCACCACGGGCGGCGCCCTGACCTTCGCCACCGCCGTGGAACCGGACTGCCTCGACCCCGCGGTCAGCGCACGGGACGTCACCGGCGTCATCAACCGCAACATCTTCGACTCGCTCGTGCGGCAGGCCCCGGACGGGAGCTTCCACCCCTGGCTGGCCGAGCGGTGGGAGACGGCGCCGGACGGGCGGGCCTACACCTTCCACCTGCGATCGGGAGTACGGTTCCACGACGGCACCACCCTCGACGCCGCGGCGGTGAAGGCCACCCTGGACCACGCCGTCGATCCCGCCACCGAGTCCCGCTTCGCGGCGGGCCTGCTGGCCGCCTACCGCAGCGCCGAGGTCACCGACGCGTCCACCGTCACCGTCCGGCTGAGCCGTCCGGACGCCGCACTGCTCCAGACGCTGAGCACCCCCTACCTGGGCATCCAGTCCCCCCGGTCACTGCGGGAGAACAAGGACGGGCTCTGCGAACAGCCGATCGGTTCCGGGCCGTTCCGCTTCGTCCGGTGGGAGAAGAAGGTCGGCATCGACCTGAGCCGCTACCCCGACTACGCCTGGTCGCCCAGCGGGGCAACCCACCAGGGACCGGCCCGCCTGGACACGCTACGGATCACGTTCGTGGCAGAGGACAGCGTCCGGCTCGGGTCGCTGACCAGCGGTCAGGTGCAGGTCTCCGACGTGCCGGCGAGCAAGGCGCGCACGGTGCAGGGCAGCGCCCACCTGCTCAAGACCGAGGTCCCCGGGGCCCCGTACACCATCTTCCTCAACTCCTCCCGCGACGCGATCCTGGCCGACATCCGGGTCCGCCAGGCCCTGCGTCGGGCGGTGGACCTCGACCAGCTCGTCAAGAGCATCTACTTCGGGCAGAACCAGCGCGCGTGGAGCCCACTGACCCCGGCCACCCCGCTGTACGACGACTCGACCCGGGACGCGTTCACCTTCGACCAGGCCGAGGCGAACCGCCTGCTGGACGAGGCGGGGTGGACCCAGCGCGACAGCGCCGGTTACCGACTCAAGGACGGCCGCCGGCTCACCCTGCGCTGGCCGCACACCGCCGCGATGGAACGCGACCAACGGAACCTGATCGGGCAGGGCCTGCAGTCGCAGGCCAAGCAGGTGGGTATCGAGATCCAGTACACGCTGGTCGACCAGGGCACGATCGGCGACCTGATCGGCAAGCGGGCGCTGGACCTGTTCGACGTCAGCTTCACCCGCTCCGACCCGGACATCTTGCGCTACTTCTTCGGCACGAAGTCGACGCTCGCCGAGGGCGGCGGCAACATCTTCGGCCTCGACATCCCCGAGCTGGACAAGCTGCTCACCGACGGCGTGAGCACCCTCGACCCGGCACAGCGCCAGCGCATCTACAGCGACGCGCAGCGGTACGTGGTCGAGAACGCCGTCTCCCTGCCGGTCTACGTGCCCACCAGCCTGCTCGGGGTGGCCCGCCACGTACACGGCGTCGAATTCGGCGCGAACGCCACCCCGCTGTTCGCCGGTGCCTGGATCGCCGGATGA",
    "translation": "MRTTTRSTAILLLLVAATAACGTSAAQTGDAQPTTGGALTFATAVEPDCLDPAVSARDVTGVINRNIFDSLVRQAPDGSFHPWLAERWETAPDGRAYTFHLRSGVRFHDGTTLDAAAVKATLDHAVDPATESRFAAGLLAAYRSAEVTDASTVTVRLSRPDAALLQTLSTPYLGIQSPRSLRENKDGLCEQPIGSGPFRFVRWEKKVGIDLSRYPDYAWSPSGATHQGPARLDTLRITFVAEDSVRLGSLTSGQVQVSDVPASKARTVQGSAHLLKTEVPGAPYTIFLNSSRDAILADIRVRQALRRAVDLDQLVKSIYFGQNQRAWSPLTPATPLYDDSTRDAFTFDQAEANRLLDEAGWTQRDSAGYRLKDGRRLTLRWPHTAAMERDQRNLIGQGLQSQAKQVGIEIQYTLVDQGTIGDLIGKRALDLFDVSFTRSDPDILRYFFGTKSTLAEGGGNIFGLDIPELDKLLTDGVSTLDPAQRQRIYSDAQRYVVENAVSLPVYVPTSLLGVARHVHGVEFGANATPLFAGAWIAG",
    "product": "BC transporter oligopeptide binding protein"
   },
   {
    "start": 51439,
    "end": 52374,
    "strand": 1,
    "locus_tag": "abyF2",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75509.1</span><br>\n Gene: <span class=\"serif\">abyF2</span><br>\n \n Location: 51,439 - 52,374,\n (total: 936 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1118:binding-protein-dependent transport systems (Score: 303; E-value: 3.5e-92)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF19300.2 (Binding-prot-dependent transport system membrane comp, N-term): [4:105](score: 35.8, e-value: 8.1e-09)<br>\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [119:307](score: 105.9, e-value: 2.3e-30)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyF2 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75509.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSPALRWLARKLALAVLVVLGAATVAFAALHLAPGDPVRAVIGTLAPSDDLVAQVRADLDLDKPLATQYAHMLGGLARGDLGESYQLRRPVVEVIVADLGWTVQLAVASLLLALVVSTALAVATAGRRPTLRRVSILLELVTASSPTFWVGTILLAVLSFQLHLFPAAGAGGLEGLVLPAVTQAIGLVGIFTQVLRQSMEQALDEPFALSARARGTTETALRLRHAARHALIPVLTLSGWILGALLSGAVVVETLFSRPGLGRTLVTAILGRDLPVVIGVVVVAAALFTVINLVVDLLYRVVDPRLREWAA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF2.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCCTGCCCTCCGGTGGCTGGCGCGCAAGCTGGCCCTGGCCGTCCTGGTCGTCCTCGGGGCCGCGACCGTGGCGTTCGCGGCGCTGCACCTCGCACCGGGCGACCCGGTCCGCGCGGTGATCGGCACGCTGGCCCCGAGCGACGACCTGGTGGCCCAGGTCCGCGCCGACCTCGACCTCGACAAGCCGCTGGCCACCCAGTACGCGCACATGCTGGGTGGCCTCGCGCGCGGCGACCTGGGTGAGTCCTACCAGCTGCGCCGCCCGGTCGTCGAGGTGATCGTGGCGGACCTCGGCTGGACCGTCCAGCTCGCGGTCGCCTCCCTGCTGCTCGCGCTGGTGGTGTCGACGGCACTCGCGGTCGCCACCGCCGGCCGGCGGCCCACCCTGCGCCGGGTCAGCATCCTGCTGGAACTCGTGACCGCCTCCAGCCCGACATTCTGGGTGGGCACCATCCTGCTCGCGGTGCTGTCGTTCCAGCTGCACCTCTTCCCCGCCGCCGGCGCCGGCGGTCTGGAAGGGCTCGTGCTGCCGGCCGTCACGCAGGCGATCGGGTTGGTCGGCATCTTCACCCAGGTGCTGCGGCAGAGCATGGAGCAGGCCCTCGACGAGCCCTTCGCGCTCAGCGCGCGGGCCCGAGGCACCACCGAGACGGCCCTGCGGCTGCGGCACGCCGCGCGGCACGCCCTCATCCCGGTGCTCACCCTGTCCGGTTGGATCCTGGGGGCGCTGCTCAGCGGCGCGGTCGTGGTGGAGACGCTGTTCAGCCGGCCGGGCCTCGGGCGCACGCTGGTCACCGCCATCCTCGGCCGCGACCTGCCGGTGGTGATCGGCGTGGTGGTGGTCGCCGCCGCGCTGTTCACCGTGATCAACCTGGTCGTCGACCTGCTGTACCGCGTCGTCGACCCCCGGCTGCGGGAGTGGGCGGCATGA",
    "translation": "MSPALRWLARKLALAVLVVLGAATVAFAALHLAPGDPVRAVIGTLAPSDDLVAQVRADLDLDKPLATQYAHMLGGLARGDLGESYQLRRPVVEVIVADLGWTVQLAVASLLLALVVSTALAVATAGRRPTLRRVSILLELVTASSPTFWVGTILLAVLSFQLHLFPAAGAGGLEGLVLPAVTQAIGLVGIFTQVLRQSMEQALDEPFALSARARGTTETALRLRHAARHALIPVLTLSGWILGALLSGAVVVETLFSRPGLGRTLVTAILGRDLPVVIGVVVVAAALFTVINLVVDLLYRVVDPRLREWAA",
    "product": "ABC transporter oligopeptide permease"
   },
   {
    "start": 52371,
    "end": 53222,
    "strand": 1,
    "locus_tag": "abyF3",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75510.1</span><br>\n Gene: <span class=\"serif\">abyF3</span><br>\n \n Location: 52,371 - 53,222,\n (total: 852 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1085:binding-protein-dependent transport systems (Score: 256.5; E-value: 4e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [96:267](score: 91.8, e-value: 4.5e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyF3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75510.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTTVLTPVTAPVARARPALVLAWVGLGLLALAAAWPALLATAAPDTVDPASALAPISPHHPFGTDQLGRDVYSRVVYGTRMSLLIGLGATTLAVTAGALLGVLAAAAGRAVDELFMRITDILLAFPGLLLALLVIAVLGPGAVNTTIALACAAVPGYVRLARGQALVVRRSGYVSAAVVMGRSRVGIFFGHVLPNALPPVLAFAAVDVGTALMASASLSFLGLGAQPPAPEWGSMLAEGRDYLDSTWGLTVFPGLVVTAAVIACYVVGADLRARFEGRGTGGR\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF3.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGACCGTCCTCACCCCGGTCACCGCGCCGGTGGCCCGTGCCCGTCCCGCCCTGGTGCTGGCCTGGGTCGGGCTCGGGTTGCTCGCCCTGGCCGCCGCCTGGCCCGCGCTGCTCGCCACCGCCGCGCCGGACACGGTCGACCCCGCCTCGGCGCTCGCGCCGATCAGCCCGCACCACCCGTTCGGCACCGACCAGCTCGGGCGTGACGTCTACAGCCGGGTGGTGTACGGCACCCGCATGTCGCTGCTCATCGGGCTCGGCGCGACCACGCTGGCCGTGACCGCAGGCGCGCTGCTCGGGGTGCTGGCCGCCGCCGCCGGGCGAGCCGTCGACGAACTGTTCATGCGGATCACCGACATCCTGTTGGCGTTCCCGGGACTGCTGCTGGCGCTGCTGGTGATCGCCGTGCTCGGTCCGGGCGCGGTGAACACCACCATCGCCCTGGCCTGCGCCGCCGTACCCGGCTACGTGCGCCTGGCCCGGGGGCAGGCGCTGGTGGTCCGCCGGTCGGGCTACGTGTCGGCGGCGGTGGTGATGGGCCGGTCCCGGGTCGGGATCTTCTTCGGTCACGTGCTGCCGAACGCGCTGCCGCCGGTGCTCGCCTTCGCGGCGGTGGACGTCGGTACGGCGCTGATGGCCAGCGCCTCGCTGAGCTTCCTCGGCCTGGGCGCGCAGCCACCCGCGCCGGAGTGGGGCTCGATGCTCGCCGAGGGACGGGACTACCTGGACAGCACCTGGGGGCTGACGGTGTTTCCCGGCCTGGTGGTCACCGCCGCGGTGATCGCCTGCTACGTCGTCGGCGCCGACCTGCGCGCCCGGTTCGAGGGACGGGGCACCGGTGGACGATGA",
    "translation": "MTTVLTPVTAPVARARPALVLAWVGLGLLALAAAWPALLATAAPDTVDPASALAPISPHHPFGTDQLGRDVYSRVVYGTRMSLLIGLGATTLAVTAGALLGVLAAAAGRAVDELFMRITDILLAFPGLLLALLVIAVLGPGAVNTTIALACAAVPGYVRLARGQALVVRRSGYVSAAVVMGRSRVGIFFGHVLPNALPPVLAFAAVDVGTALMASASLSFLGLGAQPPAPEWGSMLAEGRDYLDSTWGLTVFPGLVVTAAVIACYVVGADLRARFEGRGTGGR",
    "product": "binding-protein dependent ABC transporter"
   },
   {
    "start": 53212,
    "end": 54831,
    "strand": 1,
    "locus_tag": "abyF4",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyF4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75511.1</span><br>\n Gene: <span class=\"serif\">abyF4</span><br>\n \n Location: 53,212 - 54,831,\n (total: 1620 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 202.4; E-value: 1.4e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyF4 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [25:183](score: 83.4, e-value: 2.2e-23)<br>\n \n  PF08352.15 (Oligopeptide/dipeptide transporter, C-terminal region): [233:274](score: 26.0, e-value: 1e-05)<br>\n \n  PF00005.30 (ABC transporter): [308:448](score: 109.2, e-value: 2.4e-31)<br>\n \n  PF08352.15 (Oligopeptide/dipeptide transporter, C-terminal region): [499:529](score: 27.6, e-value: 3.4e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyF4 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF08352.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF08352.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF08352.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015833' target='_blank'>GO:0015833</a>: peptide transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyF4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyF4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75511.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMDDEVVSVAGLHVTYRVGRAEVFAVRGVDFHLRAGECLAIVGESGSGKSTVARALVGLTGPGARLRSDRLVVSGQELSRLGDREWRRIRGAQVGLVLQDALTALDPLRTVGAEVAEAARNHGLVRRGEVARRVHRLLTDVQVPQPELRARQYPQQLSGGLRQRALIAAAMAADPPVLVADEPTTALDVTLQAKLLDLLAARKAAGTAVLLISHDLSVVARLADRVAVMRDGEFVETGCTTDVLRAPEHPYTRQLLAATPSAHARGARLAGPRSTPARTRTPRPSGVLARVREVSKTFRGPGGARLAAVSEVSFSLSAGEILGVVGESGSGKSTLAHLLLGLLEPDTGTIELFGQPWSGVPEARRQRGRVQWVQQDPLGSFDPRYRVGRLIAEAGVDRARVRELLDQVGLDPAMADRHPRTLSGGQRQRVAIARALARDPEVIVCDEPVSALDVSVQAQILDLFADIRADLGTALVLISHDLAVVHHVADRVLVMRAGTVVESGPVTEVFARPTHPYTAQLIAALPRPGDAYAAYPEGVA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n  <a href=\" smcogs/abyF4.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyF4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGACGATGAGGTCGTGTCCGTCGCCGGGCTGCACGTGACGTACCGCGTCGGCCGCGCCGAGGTGTTCGCCGTGCGCGGGGTGGACTTCCACCTGCGCGCCGGGGAGTGCCTGGCCATCGTGGGCGAATCCGGGTCGGGCAAGAGCACGGTGGCTCGCGCGTTGGTCGGCCTCACCGGACCCGGCGCACGGCTGCGCAGCGACCGGCTCGTGGTGTCCGGCCAGGAACTCAGCAGGCTGGGCGACCGCGAGTGGCGGCGGATACGTGGCGCCCAGGTGGGGCTGGTGTTGCAGGACGCGCTCACCGCGCTGGATCCACTGCGTACCGTCGGCGCCGAGGTCGCCGAGGCGGCGCGCAACCACGGTCTGGTCCGTCGGGGTGAGGTGGCGCGACGGGTCCACCGACTGCTCACCGACGTCCAGGTGCCGCAGCCCGAGCTGCGTGCCCGGCAGTACCCGCAGCAGCTCTCCGGTGGTCTGCGCCAACGCGCGCTGATCGCCGCCGCGATGGCCGCGGATCCGCCGGTGCTGGTGGCCGACGAGCCCACCACCGCGCTGGACGTCACCCTGCAGGCCAAGCTGCTCGACCTGCTGGCGGCACGCAAGGCAGCCGGCACCGCCGTGCTGCTGATCAGTCACGACCTGTCCGTGGTGGCCCGGCTCGCCGACCGGGTCGCGGTGATGCGCGACGGAGAGTTCGTGGAGACCGGCTGCACGACCGACGTGCTGCGCGCGCCGGAGCACCCGTACACCCGGCAGTTGCTCGCGGCCACACCCTCCGCGCACGCCCGCGGCGCCCGACTGGCCGGGCCGCGCAGCACACCGGCGCGAACCCGTACGCCGCGTCCGTCCGGTGTCCTGGCGCGGGTCCGGGAGGTCTCCAAGACGTTCCGCGGGCCGGGCGGGGCACGGCTCGCGGCCGTGTCGGAGGTGTCGTTCTCACTTTCGGCCGGTGAGATCCTCGGCGTGGTCGGCGAGTCGGGCTCGGGCAAGAGCACCCTCGCGCATCTGCTGCTCGGGCTCCTCGAACCGGACACCGGCACCATCGAGCTGTTCGGGCAGCCCTGGTCGGGGGTGCCGGAGGCGCGGCGGCAGCGGGGCCGCGTGCAGTGGGTGCAGCAGGACCCGCTCGGCTCGTTCGACCCGCGCTACCGGGTGGGACGGCTGATCGCCGAGGCGGGGGTCGACCGGGCCCGGGTCCGCGAGCTGCTCGACCAGGTCGGTCTCGACCCGGCCATGGCCGACCGGCACCCGCGCACATTGTCCGGCGGGCAGCGGCAGCGGGTCGCCATCGCCCGCGCGCTCGCCCGCGACCCGGAGGTCATCGTGTGCGACGAACCGGTCTCCGCGCTGGACGTCTCGGTGCAGGCACAGATCCTGGACCTCTTCGCCGACATCCGCGCCGACCTGGGTACCGCGCTGGTGCTGATCAGCCACGACCTCGCGGTGGTGCACCACGTGGCGGACCGGGTCCTGGTGATGCGGGCCGGGACGGTCGTGGAGAGCGGGCCGGTGACCGAGGTCTTCGCCCGGCCGACGCACCCCTACACCGCGCAGCTCATCGCCGCCCTCCCCCGGCCGGGGGACGCCTACGCCGCCTACCCCGAAGGAGTCGCATGA",
    "translation": "MDDEVVSVAGLHVTYRVGRAEVFAVRGVDFHLRAGECLAIVGESGSGKSTVARALVGLTGPGARLRSDRLVVSGQELSRLGDREWRRIRGAQVGLVLQDALTALDPLRTVGAEVAEAARNHGLVRRGEVARRVHRLLTDVQVPQPELRARQYPQQLSGGLRQRALIAAAMAADPPVLVADEPTTALDVTLQAKLLDLLAARKAAGTAVLLISHDLSVVARLADRVAVMRDGEFVETGCTTDVLRAPEHPYTRQLLAATPSAHARGARLAGPRSTPARTRTPRPSGVLARVREVSKTFRGPGGARLAAVSEVSFSLSAGEILGVVGESGSGKSTLAHLLLGLLEPDTGTIELFGQPWSGVPEARRQRGRVQWVQQDPLGSFDPRYRVGRLIAEAGVDRARVRELLDQVGLDPAMADRHPRTLSGGQRQRVAIARALARDPEVIVCDEPVSALDVSVQAQILDLFADIRADLGTALVLISHDLAVVHHVADRVLVMRAGTVVESGPVTEVFARPTHPYTAQLIAALPRPGDAYAAYPEGVA",
    "product": "ATP-binding ABC peptide transporter"
   },
   {
    "start": 54828,
    "end": 56015,
    "strand": 1,
    "locus_tag": "abyV",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyV</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75512.1</span><br>\n Gene: <span class=\"serif\">abyV</span><br>\n \n Location: 54,828 - 56,015,\n (total: 1188 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1007:cytochrome P450 (Score: 399.5; E-value: 2.6e-121)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyV collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [268:364](score: 74.9, e-value: 5.9e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyV collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyV\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyV\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75512.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyV\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyV\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGAGATCCCGTCTGCGGCGACCGCGTCGCCGCAGTATCCGCAGCGGCGCGCCTGCCCCTATCGTCCGGCAGGGGGTTACGAGCGGCCGGTGACCCGCGTACGGCTGTACGACGGCCGGCCGGCGTGGCTGGTCACCGGCCACGAGACGGCACGGCAGGTGCTGCTGGACGCCGCGACCTTCTCCTCCGACCGGCAGCACCCCGCGTTCCCGGCGCTCGCCGCGCGGTTCGAGGCCGCCCGCGCGGTCCGCAACTTCATCGGGATGGACCCGCCCGAGCACACGGCGCAGCGGCGCATGCTCATCTCCGGTTTCACCGCCAAGCGGGTGGCCACACTCCGGCCGGCCATCACCGAGATCGTGGACTCCCTCCTCGACGAGGTGGTTCGGCGCGGGCCCGGAGTGGACCTCGTTGCGACCTTCACGCTCCCGGTGCCGTCGGTCGTGATCTGCCGCCTACTCGGCGTCCCGTACGCCGACCACGAGTTCTTCGAGCACCAGTCCCGGCGCATCGCGGCGGGCACCTCGACGGCCGCCGAGAGCGCGGACGCCTTCGGCCAACTGAAGCGCTATCTGCTCGGTCTGATCGAAACGAAGGGCAGAGGCGGCGAGGACATGCTCGACGTGCTCGTCGACGAGCAGGTGGCCACCGGCACAGTCACGACCCCTGACCTGGTCGACCTGGCACTGTTGCTGCTCGTGGCGGGGCACGAGACCACGGCCAGCACGTTGGCGCTCGGAGTGGCTCTCCTGCTGGAGCAGGACGGCGGCGCCGTCGCCGCCGACCCGACGCGAGTCGGCGCGGTGGTGGAGGAGATCCTGCGGCACACCGCCGTGGCCGACGGCGTGGCCCGCTTCGCCACCCGCGACACCGAGGTGGCCGGCGTCCGGATCGCCGCCGGCGACGCGGTGGTGGTCGCTCTCTCGGCGGCCAACCGGGACCCGGGCCCGTTCCCCGACCCGGACCGCTTCGACCCTCGTCGTGGCGGTCGCCAGCACGTGACCTTCGGGCACGGCCCCCACCAGTGCATCGGTGCGAACCTGGCCCGCGCCGAGTTGGAGATCGCCCTGTCCCGTCTGTTCACGCGGCTGCCGACGCTGGCGCTCGCGGTGCCCGTCGAGGAGCTGGGCGGCAAGGAGGCGGGGGGTGTGCAGGGTGTCCAACGCCTTCCGGTCACCTGGTGA",
    "translation": "MIEIPSAATASPQYPQRRACPYRPAGGYERPVTRVRLYDGRPAWLVTGHETARQVLLDAATFSSDRQHPAFPALAARFEAARAVRNFIGMDPPEHTAQRRMLISGFTAKRVATLRPAITEIVDSLLDEVVRRGPGVDLVATFTLPVPSVVICRLLGVPYADHEFFEHQSRRIAAGTSTAAESADAFGQLKRYLLGLIETKGRGGEDMLDVLVDEQVATGTVTTPDLVDLALLLLVAGHETTASTLALGVALLLEQDGGAVAADPTRVGAVVEEILRHTAVADGVARFATRDTEVAGVRIAAGDAVVVALSAANRDPGPFPDPDRFDPRRGGRQHVTFGHGPHQCIGANLARAELEIALSRLFTRLPTLALAVPVEELGGKEAGGVQGVQRLPVTW",
    "product": "cytochrome P450"
   },
   {
    "start": 55978,
    "end": 56229,
    "strand": 1,
    "locus_tag": "abyW",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyW</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75513.1</span><br>\n Gene: <span class=\"serif\">abyW</span><br>\n \n Location: 55,978 - 56,229,\n (total: 252 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1265:ferredoxin (Score: 76.5; E-value: 2.2e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyW collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13459.9 (4Fe-4S single cluster domain): [16:75](score: 44.2, e-value: 2.5e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyW\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyW\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75513.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/abyW.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyW\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyW\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTGCAGGGTGTCCAACGCCTTCCGGTCACCTGGTGACCCGGTCCACGTCAACATCGACGCGGCACGGTGCGTCGGCGCCGGGCAGTGCGTGCGGACCGACCCGACGGTCTTCGGCCAGTCCGACGAGGGCACCGTCCGGCTGTTGCGCGGCAGCCTCCCCGGCTCCCTGCGGTCCGTGGTGACCGAGGCGGCGGCGCTGTGCCCGGCCCAGGCGATCACCGTGACCGGCACGGCCGATCCGCCCCACTGA",
    "translation": "MCRVSNAFRSPGDPVHVNIDAARCVGAGQCVRTDPTVFGQSDEGTVRLLRGSLPGSLRSVVTEAAALCPAQAITVTGTADPPH",
    "product": "alcohol dehydrogenase"
   },
   {
    "start": 56230,
    "end": 56808,
    "strand": -1,
    "locus_tag": "abyZ",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyZ</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75514.1</span><br>\n Gene: <span class=\"serif\">abyZ</span><br>\n \n Location: 56,230 - 56,808,\n (total: 579 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyZ collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03358.18 (NADPH-dependent FMN reductase): [2:143](score: 103.1, e-value: 1.3e-29)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-abyZ collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03567 (FMN_reduc_SsuE: FMN reductase): [2:172](score: 206.0, e-value: 8.8e-62)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyZ collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03358.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyZ\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyZ\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75514.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyZ\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyZ\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCACCGTGCTCTCCGTCTCCGGCAGCCCGTCGGCGACCTCGCGTACCGCTGGCCTGCTTCGTCACCTCGACCGGCAGTTGGTCGCCGACGGGCACGAGGTGATCCCGCTGGACGTGCGGACCCTGCCCGCGCACGTGCTGGTCGGCGCCGACCCACGCCACCCGGCGATCACCGGCGTGGCGGCGCTGGTCGCGGAGGCCGACGGGCTGGTGATCGGCACACCGATCTACAAGGCCGCCTACTCCGGCCTGTTGAAGTGCCTGTTCGACCTGCTGCCGCAGTACGCCCTGGCGGGCAAGACGGTGCTGCCGCTGGCCACCGGTGGCAGCAGGGCCCATGTGCTGGCCATCGACTACGCGCTGCGTCCCGTCCTGACCGCGATGGGCGCGGGGCACGTCCTGCCCGGCTGGTTCACCCTCGACACCGACCTGGTCGTCGGCGACGACGGCACACTTGTCGTCGCGCCGGCTGCCGCCGACGCGCTCTGCGAGGTCGTCGACCGGTTCGCGGCGGCGCTGCACCGCGCGGTGACCAGCGCGCCCCCGGACGGCACGGGGCGGCCGGGAATGCGCTGA",
    "translation": "MPTVLSVSGSPSATSRTAGLLRHLDRQLVADGHEVIPLDVRTLPAHVLVGADPRHPAITGVAALVAEADGLVIGTPIYKAAYSGLLKCLFDLLPQYALAGKTVLPLATGGSRAHVLAIDYALRPVLTAMGAGHVLPGWFTLDTDLVVGDDGTLVVAPAAADALCEVVDRFAAALHRAVTSAPPDGTGRPGMR",
    "product": "NAD(P)H-depedent FMN-reductase"
   },
   {
    "start": 56933,
    "end": 57829,
    "strand": 1,
    "locus_tag": "abyT",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">abyT</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75515.1</span><br>\n Gene: <span class=\"serif\">abyT</span><br>\n \n Location: 56,933 - 57,829,\n (total: 897 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Abhydrolase_6<br>\n \n  biosynthetic-additional (smcogs) SMCOG1004:thioesterase (Score: 197.7; E-value: 2.7e-60)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-abyT collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>Thioesterase</strong> (26..240)</dt>\n   <dd>\n   \n    active site serine inconclusive<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-abyT collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00975.23 (Thioesterase domain): [26:237](score: 118.4, e-value: 5.4e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-abyT collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00975.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"abyT\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"abyT\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75515.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyT\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"abyT\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGCGGACAGCGCGGGCGGGCACGCAACGATCGACCGGTTACCTGGACCGGACGCCGGATCCGGCGGACCGGGTGCGGCTGTTCTGTTTCCACCACGCCGGCGCCGCAGCGTCCACCTTCGCCGGCTGGGCGGAGGCGTTGCAGCCACGGGTCGCGGTCTACCCGGTGCAGCTGCCCGGCCGGGAGAACCGCGTGCGGGAGGCGCCCATCACCGATTTCGGCCGTCTGCTCGACGCCGTCGTGGACGCTGTCGAGCCGTCACTGGAACGTCCGTACGCTCTCTATGGACACAGCATGGGTGCGGCCCTGGCCGCCGCGGTGGCCCGACGGCAGGTCGAGCGGGGACGACCGCCGGTGGCGTTGTTCGTCGGCGGCTACCCGGACCCGCGCTGCGGGCCACCGCTCGCGGTGTCGGCGCTGTCCGACGACGAGGTCGCCGACCTGCTGGTGCGCATCGGGGGCATGTCCGAGGTGGTACGCCGGTATCCCGCGTGGGTGCGGACGGCGGTCCGGCTGCTGCGCGGCGACCTCGCGGCCCTGCACTCCCAGCCTCCGACCGGGCCCGATCCGGTGCCGGTGCCGGTGCGCGCCTACGTCGGCGACTCCGATCCGCTGGTGGGGCGCGCCGACGCGGTCGGGTGGGCGGCGTACACCTCGTCGTCGTTCCGGCTGCGGGTGCTGCCCGGCGGTCACCTGTTCCACCTCCGGTCGGGCGATCGGCTCCGGGCGGACATCGCGGCCTGCCTGGGCGAGCTGACCTCGCTGCCGGGCGGCAGGCCCGACGGTGGGGCGTCAGTCGATGTCGAGGACCGCCTTGCCGGCCACGCGGCGGCCGAGCAGCGCCTCGATCGCGTCGTCGACGCGCTTCCAGGAGTCCCGCCAGCCGACCGGTAG",
    "translation": "MGRTARAGTQRSTGYLDRTPDPADRVRLFCFHHAGAAASTFAGWAEALQPRVAVYPVQLPGRENRVREAPITDFGRLLDAVVDAVEPSLERPYALYGHSMGAALAAAVARRQVERGRPPVALFVGGYPDPRCGPPLAVSALSDDEVADLLVRIGGMSEVVRRYPAWVRTAVRLLRGDLAALHSQPPTGPDPVPVPVRAYVGDSDPLVGRADAVGWAAYTSSSFRLRVLPGGHLFHLRSGDRLRADIAACLGELTSLPGGRPDGGASVDVEDRLAGHAAAEQRLDRVVDALPGVPPADR",
    "product": "type II thioesterase"
   },
   {
    "start": 57728,
    "end": 58636,
    "strand": -1,
    "locus_tag": "orfU",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">orfU</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75516.1</span><br>\n Gene: <span class=\"serif\">orfU</span><br>\n \n Location: 57,728 - 58,636,\n (total: 909 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase (Score: 205.3; E-value: 2.1e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-orfU collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13602.9 (Zinc-binding dehydrogenase): [175:299](score: 47.7, e-value: 3.3e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"orfU\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"orfU\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75516.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfU\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfU\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCAAGCCCTGATCGCCGCCCCCGACACCGCCGAGGGACACCGCTTGGCCGAGGTGCCCGAGCCGGTCCCGACGCCCGGCCAGTTGCTCGTCGAGGTGAGACAGTCCTCGGTGAACTTCGGCGAGGCCCGCTTCCGTGCCGGGATGCCCGCCGGCACGGTGCTCGGTTACGACGCCGCGGGTTACGTCGTGCGGGCCGCCGAGGACGGCAGCGGTCCGGCCGTCGGCGACCGGGTGGTCGCCTTCGGTCCGGGAACGTGGGCCGAACGTGCCGTCTTCGACGTCGACAGCGTGGCGCGGATCCCCGACGGGCTCGATCTCGCCGCCACGGCGGCCCTGCCGATGGTGGGCCTCACCGCCCTGCGGACCCTGCGAGGCGCCGGCCCACTGCTGGGCCGTCGGGTGCTGGTCACCGGCGCGTCCGGAGGCGTCGGACGGCTGGCGGTTCAACTCGCCCGCCTCGGCGGAGCCACGGTGGTGGCGTCGGTCGGCTCGCCGGCGCGGGGGGAGGGGCTGCGCGACCTGGGCGCAGCCGAGGTGGTGGTCGGGCTGGACGACGTCCGCGAGCCGGTCGACGTGGTGGTGGAGACAGTCGGTGGTGACCACCTCACCCGCGCGTGGTCGCTGCTCAAGCCGGGCGGGATCTGCCAGAGCATCGGCTGGGCGTCGGGTGCGGCGGCCGTCTTCGCGCCCAACTCGACCTTCGCATTGGGCGAACCCCGGCGTCTGCAGTCCTTCGGTGACACCTCCCGCCCCGGAGCCGACCTGGCTACCCTCCTGGCCTTCGTGGCCGCCGGGGACATCTCCCTACCGGTCGGCTGGCGGGACTCCTGGAAGCGCGTCGACGACGCGATCGAGGCGCTGCTCGGCCGCCGCGTGGCCGGCAAGGCGGTCCTCGACATCGACTGA",
    "translation": "MQALIAAPDTAEGHRLAEVPEPVPTPGQLLVEVRQSSVNFGEARFRAGMPAGTVLGYDAAGYVVRAAEDGSGPAVGDRVVAFGPGTWAERAVFDVDSVARIPDGLDLAATAALPMVGLTALRTLRGAGPLLGRRVLVTGASGGVGRLAVQLARLGGATVVASVGSPARGEGLRDLGAAEVVVGLDDVREPVDVVVETVGGDHLTRAWSLLKPGGICQSIGWASGAAAVFAPNSTFALGEPRRLQSFGDTSRPGADLATLLAFVAAGDISLPVGWRDSWKRVDDAIEALLGRRVAGKAVLDID",
    "product": "Zn-dependent alcohol dehydrogenase"
   },
   {
    "start": 58727,
    "end": 59320,
    "strand": 1,
    "locus_tag": "orfS",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">orfS</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">None</span><br>\n Protein ID: <span class=\"serif\">AEK75517.1</span><br>\n Gene: <span class=\"serif\">orfS</span><br>\n \n Location: 58,727 - 59,320,\n (total: 594 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1057:TetR family transcriptional regulator (Score: 72.3; E-value: 1.1e-21)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-orfS collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00440.26 (Bacterial regulatory proteins, tetR family): [14:61](score: 34.0, e-value: 2e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-orfS collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00440.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"orfS\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"orfS\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/AEK75517.1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\" smcogs/orfS.png\" target=\"_new\">View smCOG seed phylogenetic tree with this gene</a><br>\n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfS\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"orfS\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGACTGAACGCGCCGACGCGGCCCGCAACCGGGCGATGATCCTGCGCGCCACCGAGGATCTATTGACGTACCGCGAAGCTATGCCGATCTCCGTCGACTCGATCGCCGCCCGGGCGGGCGTCGGCAAAGGCACCGTCTTCCGCCGCTTCGGCAGCCGGTCCGGCCTGTTCCGGGAACTCCTCGCCGAACGCGCGACGCGAATCGGAGAGCAGATCAGCCACGGTCCACCACCGCTGGGGCCCGGAGCACCGCCCGGGGACCGGCTCCTGGCCTTCCTCGATGCACTGGCCGACCTCGCCGCGACCAACGCGACCCTCCTCGCCGCCCACGCAATGGCCTGCGCCGCCGGACGGCACGACGACCCCACCTACCGACGCTGGCACGAACACCTGCGCCAGCTCGTCGGGCAACTCCGCCCGGACCTCGACGCCGGATACGTCGCCCACGTCCTGCTCGGGGCATTCGACGCCGAACTGGTCCGCCGAACCATCGCCGACGGCGGCGGCGACCGGCTCCGCGCAGCCGTAAGGGCACTCGCACGGTGCCTGCTGCCACCCGGGCCCGAGCGATCATGCCGCCCGGGCCCGTAA",
    "translation": "MTTERADAARNRAMILRATEDLLTYREAMPISVDSIAARAGVGKGTVFRRFGSRSGLFRELLAERATRIGEQISHGPPPLGPGAPPGDRLLAFLDALADLAATNATLLAAHAMACAAGRHDDPTYRRWHEHLRQLVGQLRPDLDAGYVAHVLLGAFDAELVRRTIADGGGDRLRAAVRALARCLLPPGPERSCRPGP",
    "product": "TetR transcriptional regulator"
   }
  ],
  "clusters": [
   {
    "start": 15053,
    "end": 46388,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 59320,
    "product": "T1PKS",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 6964,
     "end": 6966,
     "strand": 1,
     "containedBy": [
      "abyI"
     ]
    },
    {
     "start": 29571,
     "end": 29573,
     "strand": 1,
     "containedBy": [
      "abyB1"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "T1PKS",
  "products": [
   "T1PKS"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS T1PKS",
  "anchor": "r1c1"
 }
};
var details_data = {
 "nrpspks": {
  "r1c1": {
   "id": "r1c1",
   "orfs": [
    {
     "id": "abyA2",
     "sequence": "MTAGAAAPSATGSDAAAELSELYRSGRLPTEFPRLRALLAELPDTELHRAGRLLERVGPDAVRAAHPDVPVVPITVSGYGTVAPLVPLLTVELARHGLLLDPRLGDFGGYLDALAAPDDSSLLLTLLDAQVVFDQVPTPWRPEDVAHTFTAKIDLIEGLLARSTTPVVLNTIPLPRIFPAQLIDHRSRALLGAVWREANARLLRLSQDHPTVVVVDLDPWAATGLAVRDARLSVYAKAHLTPPLLHAYAREVAHLARARAGAARKVLALDLDETVWGGVVGEVGPLAVEVADSHRGEAFREFQRVVRQLGSQGVLVAAVSKNDPEPVREALRAHPGMTLREDDFVRVVANWRPKHENLRTLAEDLNLGLDSVVFVDDSPFEQGLVRRELPEVAVVAVDDEPADHVGRLLADGWFDTVTLTAEDRQRPGLYRAEVERRDFLHSFDSLRDYLAELKVRVDLAVADETDVPRVSQLTLRTNQFNLTTRRLAPADVLALLRHPAATVLTVRCADRFGDIGLVGAVVLRHDDDVLHVDNFVLSCRAFSRGVETATLAEILRHARGSSASAVTAEYLPSRRNAKVADFYPRNGFTRLDATHFRHDLTDMPRPPEHVQLTGSWPPGGTP",
     "domains": [
      {
       "type": "FkbH",
       "start": 264,
       "end": 400,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "KVLALDLDETVWGGVVGEVGPLAVEVADSHRGEAFREFQRVVRQLGSQGVLVAAVSKNDPEPVREALRAHPGMTLREDDFVRVVANWRPKHENLRTLAEDLNLGLDSVVFVDDSPFEQGLVRRELPEVAVVAVDDE",
       "dna_sequence": "AAGGTGCTCGCCCTGGACCTGGACGAGACCGTCTGGGGAGGGGTCGTCGGCGAGGTCGGCCCGCTCGCCGTCGAGGTGGCCGACAGCCACCGGGGCGAGGCGTTCCGCGAGTTCCAGCGGGTCGTCCGCCAGCTCGGGTCGCAGGGTGTGCTGGTCGCCGCGGTGAGCAAGAACGACCCCGAGCCGGTACGCGAGGCGCTGCGCGCGCACCCAGGCATGACACTGCGGGAGGACGACTTCGTCCGGGTCGTGGCGAACTGGCGGCCCAAGCACGAGAATCTGCGCACCCTCGCCGAGGACCTCAACCTCGGGCTCGACAGCGTCGTCTTCGTCGACGACAGCCCGTTCGAGCAGGGCCTGGTCCGCCGCGAACTGCCCGAGGTGGCGGTGGTCGCCGTCGACGACGAG",
       "abbreviation": "FkbH",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": []
    },
    {
     "id": "abyA3",
     "sequence": "MSTLRSVHDFVTLVRDELGLPIEESDLDRHLDDVAGWDSVHLLALCSALERATGRSISLPAVLTADSLGGIYATAVDR",
     "domains": [
      {
       "type": "PP-binding",
       "start": 9,
       "end": 73,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FVTLVRDELGLPIEESDLDRHLDDVAGWDSVHLLALCSALERATGRSISLPAVLTADSLGGIYA",
       "dna_sequence": "TTCGTCACCCTGGTCCGCGACGAGCTTGGGCTGCCCATCGAGGAGAGCGACCTCGACCGCCACCTCGACGACGTCGCCGGATGGGACTCCGTCCACCTGCTCGCGCTCTGCTCGGCGCTGGAGCGCGCCACCGGGCGGTCCATCTCGCTCCCGGCCGTCCTGACCGCCGACAGCCTGGGCGGGATCTACGCG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    },
    {
     "id": "abyB1",
     "sequence": "MSAPDEPVAVVGLACRLPGAADPEAFWALLRDGREAITDPPASRRDPDGRARRGGFLDAVDLFDAEFFGVPPREAAAMDPQQRLVLELSWEALEDARIRPDALAGSRTGVFVGAISDDYATLLRRRGPDAIGPHSLTGTNRGIIANRVSYHLGLHGPSITVDSAQSSALVAVHVAAESLRRGESELALAGGVNLNLAPESTLGAERFGALSPDGRCHTFDARANGYVRGEGGGLVVLKPLDRALADGDRVHAVLLGSAVNNDGVTDGLTVPGSDGQREVIRLAHERAGTTPGEVDYVELHGTGTVVGDPVEAAALGAELGQLRDTPLLVGSAKTNVGHLEGAAGIVGFVKAVLCVRHRTLPPSLNFATPNPRIPLNELNLRVVTESHTVPRPLVVGVSSFGMGGTNAHAVLTEAPLRTARKPAPAARPLTWVVSGHTPQALRAQAGQLTSLAADPADVAFSLATTRATLPYRAAVVGETAADLRAGMAAVATGTPHPGTVTGSPAGTLAFVFTGQGSQRAGMGRELAARFPVYAQAFAEVAAALDPHLGRPLDEVLDDADALDRTEFAQPALFAVEVALFRLLTHWGLRPDAVAGHSVGEIAAAHVAGVLDLPDAARLVAARGRLMQALPTGGAMVALSAGEEEVRPLLRPGADLAAVNAAESVVVAGDDDAVSAIEETVRGWGRRTSRLRVSHAFHSARMDPMRVSFAQALADIEFAQPTIPVVSALTDPDVTDAEHWVRHVRDTVRFADAVRDLRDRGVRTVLEVGPDAVLTALAHDVAELAAVAVLRRDRPEPDTAVTALATAFTRGAAVDWTALLGARQAVDLPRYAFQRSRHWLDQDNPAIAAPEVTRAPDGTPRRSDEELLDLVRTAVAVAHGRVGPAAIDPDTTFRDLGLDSVTSVEFRDRLAAATGVPLSPGLVYDHPTPRAVVAHLRTLTGGGPADPEQESGYRDEPVAVIGMACRYPGGVGSPDDLWQLVRDGRDATGPFPTDRGWDLDALYDPDPGTPGRTYVRRGGFLDGAAEFDADFFGISPREASAMDPQQRLLLHTAWEALEHGRLNPESLRGTRTGVFVGVVDNDYGPRLHEPVEGTEGYLLTGTTASVASGRVAYALGLTGPAVTVDTACSSSLVALHLAAQALRQGECTLALAGGATVLATPGMFLEFSRQRGLAPDGRCKAFAATADGTAWAEGAGLVVLERLSDARRNGHPVLAVLRGSAINQDGASNGLTAPSGPSQERVIRRALAVAGLAPSDVDLMEAHGTGTALGDPIEARAILATYGQRRDTPLHLGSLKSNIGHTQAAAGIAGVIKVVQAMQHGTLPATLHVDEPTPHVDWAEGQVSLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDPQPAPPRRTSTGHVAWLVSAREPELVAEQAGRLHRFVRDNPELDPADVALSLATTRPLLEHRAAVVGADRDELLAGLAELESGRRRAEAIRPGKVAFLFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPTLRPHHNENHTLTHTLATTPTTNWASLYPHARPVRLPTTAFRRDRYWLTGGRATPGADSGVREVDHPLLGAAVTLADDSTVYTGRLSRRTAPWLADHVVLGRALLPGTALLEYALWAGRDVGLPRVAELTLEAPLVLPDEGVTQVRVTVGPPGEQRTVAVHARADDAEQWTRHASGMLTAAPPASPVPPRVDGPPVDVDDLYERLAGKGYEYGPAFRLATAARHGQHVVAQLAAPAGPDGFVLHPAQVDAALHPIVLDGDETLLPFSWSGVSVFRRPSGALHAYWTPERALVLTDADGVVATADSLHLRPARMPAPTDLHRIRWVPAEDARRQIRVEPVADATAALAMLHERLDATEPTALVVPHLDRTGAAGLVRSAQAEHPGRFVLIHADDPVRTVPDGEPEAAWRDGSWWVPRLARVAPVDPGLPLSGTVLVTGGTGALGALVARHLVRAHRVRDLVLVSRRGADAPGAAALADELAGHGARVDLRACDVADREALACLLADLPTLDAVVHAAGVVRDATVSALTVEQVRAAATKAESAWHLHELTRDRPLRAFVLFSSISGLLGTAGQGAYAAANAALDALAAHRHALGLPALSLAWGLWEDTGMGAGLSAADVARWRRDGLPPLTVEQGVALFDAALSHEGPVLAPVRLDLAALRGRDVLPAALRGLVTRRAVPPAGSRPRDEAELREVVRSVVAEVLGYPSAAGVDSARPFRDLGLDSLGGVELRNRLAAATGLPVPATLVFDHPTPDAVVAHLLGATTSAQPAPTPTVATRTDEPIAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWDLGRLYDPDPEHAGTSYTRHGGFLYDAADFDAGFFALSPREATATDPQQRLLLEVAWEAFERAGIDPTAVRGSRTGVFAGVMYGDYGTRWRTAPEGFEGHLLTGNTSSVVSGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMATPHTFVEFSRQRGLSPDGRCRSFSAAANGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDPRPVPPEETDPPAPVPLVISARSAGALRDQAARVRTALGSGLPVRDVAYTLGAARARHPHQAVVVGEGRAELLAGLDAVADGTVPGAVATPGKVAFLFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPTLRPHHNENHTLTHTLATTPTTNWKTLLPHATVIDLPTYPFQRQRYWLDGPAADTGLDGSGHPLLPGVVDLADGGLVLTGTVSADSHPWLAGHRIGGATLLPATAVVEAVAHAASRVGLDVDELVLTAAVPVDAPVRLRLTVGPASDDDSRAVHLHGNTDDGEWLPYATGRLAVVTQSPAADLATWPPTDAEPVDVVDLYDRLAEGGYGYHGLFQGLRALWRRGDETFAEVRPDESPTGGFAPHPALWDAALHPLAWDAAERGQVEIPFEWRSVRRHGPGAPALRVRLARRDDAVSVDVADDAGRPIASAGALRLRSTGTAPTTVLEPDWEPVPTDGEWTGRYATVVAPRTGADASAAYAAVTWALDALRQHEGDEPLVVRTVDDPAGAAVRGLVRTAQTEQPGRFVLFTGSGDPEPALVRAALASGEPEVALRDGTLMAPRLSRIPVAPGPLPFASGSTVLVTGGTGALGALVARHLVVRHGVRRLLLTSRRGPAADGAAELVDELTAAGAEVEVVACDVADRPAVAALLASIPEEHPLTAVIHTAGVLDDGALTSLTEERLARVLRPKAEAAWHLHEFTRDRPLTAFVLFSSITGITGTAGQANYAAANAYLDALARHRRNLGLPGVSLAWGLWGATGMASGLGAADLDRLARSGITPLSPQEGLDLFDACLVADRPVLAPARVDLSTTRRQRRRAASAAATVTSREGLRELVRAQVAAVLGHTDATEVSTDVAFTGLGLDSLTAVELRNRIAERTGLRLSSTVVFDHPSVDALTDHLVAELAGARPVETPQPVTQPADEPIAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWGEIHDPDPDRPGHSYTRHGGFLYAAGDFDAELFGMSPREALTTDPQQRLLLEVAWEAFERAGLPPGSLRGSRTGVFTGVMYNDYGARLHQAGTPAPGYEGYLVSGSAGSVASGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMASPATFVEFSRQRGLAPDGRCKPFAAAADGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEHGDAVDTGTGTGTVAPGTAVVPWLLSGTSRQALTAYARLLGEVDAAPVDIAATLALGRSPLALRASVVGRDRPEFPTARLQPVQPVDGPTAFAFTGQGSQRAGMGLGLAARFPQFADALASVAEALDPHLPSPLLDVLADGDLLERTEYAQPAIFAVEVALFRLLAHYGVTPHVLLGHSVGELAAAHVAGVLDLPDAATLVAARGRLMGGLVPGGAMAAVRAGEDEVLALLVPGAEIAAVNADDAVVVSGDAEAVAAVTQALRDAGRRVTPLRVSHAFHSARMDPVLEEFRAVAATLRFSEPTIPLISLLPGSPTDPGYWVRHLREAVRFGDGVRSLAEWGVRRVLEVGPDAALTPVTGPTGIATLRRDHDEESAFVTALAALHDTGATVDWATFFGELGARRVPLPTYPFQRRRYWLTPTAPRTTGGSGHPLLDAAVELPEGAVLFTGRVAAEDADWLADHVVLGQTVVSGATLLSLVLHAAAAAGRPTVRRLTLHAPLVLPDDGGAADLRVGVDEQGQVTVYARPAGGGWTRHASGTLDTVEQPAEALGSWPPAGAEPLDVDYTRLADAGYAYGPGCRRVRAAWRLGDDLYAEVGPVDADGHAAPHPALLDAALHPLALDLLDDEQTRVPHVWSSVTVHATGATTLRARIRRTGTDRVALTLTDTDDRPVATADLTVRAVARGLPDLYAVRLTPVRPATGGTVWPSVGRDVGLPRYAELSTSTDDIVERAHDRVTEVAELLRRWLAQGPPEARLVVATDQVTDPADGVLWGLVRAAQTEHPDRFVLLDSDGDPRSRTLVPGALATGEPQLVVRDGRITVPRLARTAAAPQPPRLDPDGTVLVTGAGGALGSLTARRLVTHHGVRRLLLLGRRGGMQPLAAELTALGATVRVAACDAANRAALARVLDTVPAAHPLTAVVHAAGVVSDGPLATLTPQRFAEVLRPKVDAAWHLHELTCEQDLAAFVLFSSLAGLVGNAGQANYAAANTGLDALAAYRRAAGLPAVSLAWGLWDAPGMGAALDETQRARIARTGVAPLPVERGLALFDACLGAREALLVPAALQPERATRVAPVLAGLAPATTATTPQQDWPRRLAGRGAAEQHRLLLELVRSTIVEVLGHSSVAAVAPDRGLMDLGFDSLTAVELAGRLGADTGVRTPSTVVFDHPTPTALAHYLRHELVGEEAADDEKPHELDEVSDEDLFALIDTELGER",
     "domains": [
      {
       "type": "PKS_KS(Hybrid-KS)",
       "start": 7,
       "end": 415,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VAVVGLACRLPGAADPEAFWALLRDGREAITDPPASRRDPDGRARRGGFLDAVDLFDAEFFGVPPREAAAMDPQQRLVLELSWEALEDARIRPDALAGSRTGVFVGAISDDYATLLRRRGPDAIGPHSLTGTNRGIIANRVSYHLGLHGPSITVDSAQSSALVAVHVAAESLRRGESELALAGGVNLNLAPESTLGAERFGALSPDGRCHTFDARANGYVRGEGGGLVVLKPLDRALADGDRVHAVLLGSAVNNDGVTDGLTVPGSDGQREVIRLAHERAGTTPGEVDYVELHGTGTVVGDPVEAAALGAELGQLRDTPLLVGSAKTNVGHLEGAAGIVGFVKAVLCVRHRTLPPSLNFATPNPRIPLNELNLRVVTESHTVPRPLVVGVSSFGMGGTNAHAVLTEAP",
       "dna_sequence": "GTCGCCGTCGTCGGTCTGGCCTGCCGGCTGCCCGGCGCCGCCGATCCGGAGGCGTTCTGGGCGCTGCTGCGCGACGGGCGGGAGGCGATCACCGACCCGCCCGCGTCCCGACGCGACCCGGACGGGCGCGCCCGCAGGGGCGGCTTCCTGGACGCGGTGGACCTGTTCGACGCCGAGTTCTTCGGCGTCCCGCCCCGCGAGGCGGCGGCCATGGACCCGCAGCAGCGGCTGGTGCTGGAGCTGAGCTGGGAGGCCCTGGAGGACGCCCGGATCCGCCCGGACGCGCTGGCCGGCAGCCGGACCGGGGTGTTCGTTGGCGCCATCTCCGACGACTACGCGACGCTGCTGCGCCGCCGTGGTCCCGACGCCATCGGCCCGCACTCGTTGACCGGCACGAACCGGGGGATCATCGCCAACCGCGTCTCGTACCACCTCGGGCTGCACGGCCCGAGCATCACCGTCGACTCGGCGCAGTCCTCCGCCCTCGTCGCCGTGCACGTGGCCGCCGAGAGCCTGCGCCGCGGCGAGTCGGAACTGGCCCTCGCCGGTGGGGTGAACCTGAACCTCGCGCCGGAGAGCACGCTGGGCGCCGAACGCTTCGGCGCGCTGTCCCCGGACGGCCGCTGCCACACCTTCGACGCGCGGGCCAACGGGTACGTGCGCGGCGAGGGCGGCGGGCTGGTGGTGCTCAAGCCGCTGGACCGGGCGCTCGCCGACGGCGACCGGGTGCACGCGGTCCTGCTCGGCAGCGCGGTCAACAACGACGGTGTCACCGACGGCCTGACCGTGCCCGGCAGCGACGGGCAGCGGGAGGTGATCCGGCTGGCCCACGAGCGGGCCGGCACCACGCCCGGCGAGGTCGACTACGTCGAGCTGCACGGCACCGGCACGGTCGTCGGCGACCCGGTCGAGGCCGCCGCGCTGGGCGCAGAACTGGGCCAGCTGCGCGACACGCCACTGCTGGTGGGCTCCGCCAAGACCAACGTGGGGCACCTGGAAGGCGCGGCGGGCATCGTCGGGTTCGTCAAGGCCGTGCTCTGCGTACGGCACCGGACGCTGCCGCCGAGCCTGAACTTCGCCACCCCGAACCCACGCATCCCACTCAACGAGCTGAACCTGCGGGTGGTGACCGAGAGCCACACCGTGCCGCGGCCCCTGGTCGTCGGGGTCAGTTCCTTCGGCATGGGCGGCACGAACGCCCACGCCGTACTCACCGAGGCTCCG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 510,
       "end": 791,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "Malonyl-CoA"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VFTGQGSQRAGMGRELAARFPVYAQAFAEVAAALDPHLGRPLDEVLDDADALDRTEFAQPALFAVEVALFRLLTHWGLRPDAVAGHSVGEIAAAHVAGVLDLPDAARLVAARGRLMQALPTGGAMVALSAGEEEVRPLLRPGADLAAVNAAESVVVAGDDDAVSAIEETVRGWGRRTSRLRVSHAFHSARMDPMRVSFAQALADIEFAQPTIPVVSALTDPDVTDAEHWVRHVRDTVRFADAVRDLRDRGVRTVLEVGPDAVLTALAHDVAELAAVAVLRR",
       "dna_sequence": "GTCTTCACCGGGCAGGGCAGCCAGCGGGCCGGCATGGGGCGGGAGTTGGCCGCCCGGTTCCCGGTGTACGCCCAGGCGTTCGCCGAGGTCGCGGCGGCACTCGACCCGCACCTGGGTCGCCCCCTCGACGAGGTGCTCGACGACGCCGACGCCCTCGACCGCACCGAGTTCGCCCAGCCCGCACTGTTCGCCGTGGAGGTGGCGCTGTTCCGGCTGCTCACCCATTGGGGTCTGCGACCGGACGCGGTGGCGGGCCACTCGGTCGGTGAGATCGCCGCCGCGCACGTGGCCGGCGTGCTGGACCTCCCCGACGCGGCCCGCCTGGTGGCGGCTCGGGGCCGGCTCATGCAGGCGTTGCCGACCGGCGGCGCCATGGTCGCCCTGTCGGCCGGCGAGGAGGAGGTACGACCGCTCCTGCGTCCCGGGGCCGACCTGGCGGCGGTGAACGCGGCGGAGTCGGTCGTGGTGGCCGGCGACGACGACGCCGTCTCCGCCATCGAGGAGACCGTGCGCGGCTGGGGGCGGCGGACCAGCCGGCTACGGGTCAGCCACGCCTTCCACTCGGCCCGGATGGACCCGATGCGCGTCTCCTTCGCGCAGGCACTGGCCGACATCGAGTTCGCGCAGCCGACGATCCCCGTGGTGTCCGCGCTGACGGACCCCGACGTGACCGACGCGGAGCACTGGGTACGCCACGTCCGGGACACCGTCCGGTTCGCCGACGCGGTCCGGGACCTGCGCGACCGGGGCGTCCGCACAGTCCTGGAGGTCGGACCGGACGCGGTGCTCACCGCACTGGCGCACGACGTGGCGGAGCTCGCCGCCGTCGCGGTGCTGCGCCGC",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "ACP",
       "start": 866,
       "end": 937,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LDLVRTAVAVAHGRVGPAAIDPDTTFRDLGLDSVTSVEFRDRLAAATGVPLSPGLVYDHPTPRAVVAHLRT",
       "dna_sequence": "CTCGACCTGGTGCGTACCGCCGTCGCGGTCGCCCACGGCCGCGTCGGCCCGGCAGCGATCGACCCGGATACCACGTTCCGCGATCTCGGCCTGGACTCGGTCACCAGCGTGGAGTTCCGCGACCGGCTCGCCGCGGCGACCGGCGTCCCCCTCTCCCCCGGCCTGGTCTACGACCATCCCACCCCCCGCGCCGTGGTGGCGCACCTGCGGACG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "PKS_KS(Modular-KS)",
       "start": 956,
       "end": 1378,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VAVIGMACRYPGGVGSPDDLWQLVRDGRDATGPFPTDRGWDLDALYDPDPGTPGRTYVRRGGFLDGAAEFDADFFGISPREASAMDPQQRLLLHTAWEALEHGRLNPESLRGTRTGVFVGVVDNDYGPRLHEPVEGTEGYLLTGTTASVASGRVAYALGLTGPAVTVDTACSSSLVALHLAAQALRQGECTLALAGGATVLATPGMFLEFSRQRGLAPDGRCKAFAATADGTAWAEGAGLVVLERLSDARRNGHPVLAVLRGSAINQDGASNGLTAPSGPSQERVIRRALAVAGLAPSDVDLMEAHGTGTALGDPIEARAILATYGQRRDTPLHLGSLKSNIGHTQAAAGIAGVIKVVQAMQHGTLPATLHVDEPTPHVDWAEGQVSLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEH",
       "dna_sequence": "GTAGCCGTCATCGGCATGGCCTGCCGGTACCCCGGCGGGGTCGGCTCACCCGACGACCTGTGGCAGCTCGTGCGGGACGGGCGGGACGCCACCGGCCCGTTCCCCACCGACCGTGGCTGGGACCTCGACGCGCTCTACGACCCGGATCCCGGCACCCCGGGACGTACCTATGTGCGGCGGGGAGGATTCCTCGACGGCGCGGCCGAGTTCGACGCCGACTTCTTCGGCATCAGCCCGCGCGAGGCCAGCGCCATGGACCCGCAGCAGCGGCTGCTGCTGCACACCGCGTGGGAGGCGCTGGAACACGGCCGACTGAACCCGGAGTCGCTACGCGGCACCCGAACCGGGGTGTTCGTCGGCGTGGTGGACAACGACTACGGGCCGCGACTGCACGAGCCGGTCGAGGGCACGGAGGGTTACCTGCTCACCGGCACCACGGCGAGCGTCGCCTCCGGACGCGTCGCGTACGCCCTGGGGCTGACCGGCCCGGCGGTCACCGTCGACACCGCGTGCTCCTCGTCGCTGGTGGCGCTGCACCTGGCGGCGCAGGCGCTGCGGCAGGGAGAGTGCACCCTGGCGCTGGCCGGCGGGGCGACCGTACTCGCCACGCCGGGCATGTTCCTGGAGTTCAGCCGACAACGCGGCCTCGCACCGGACGGCCGCTGCAAGGCGTTCGCCGCCACGGCCGACGGCACCGCTTGGGCCGAGGGCGCCGGTCTCGTCGTGCTGGAACGCCTCTCCGACGCCCGTCGCAACGGCCACCCGGTCCTCGCCGTGCTGCGCGGCTCGGCGATCAACCAGGACGGCGCCTCCAACGGCCTGACCGCACCCAGCGGCCCCTCGCAGGAGCGGGTCATCCGCCGGGCGCTGGCCGTGGCCGGGTTGGCTCCCTCCGATGTGGACCTCATGGAGGCGCACGGCACGGGCACCGCCCTGGGCGACCCGATCGAGGCCCGGGCCATCCTGGCCACCTACGGGCAGCGGCGCGACACGCCGCTGCACCTCGGCTCGTTGAAGTCGAACATCGGCCACACCCAGGCCGCCGCCGGTATCGCCGGAGTCATCAAAGTCGTCCAGGCGATGCAACACGGCACCCTGCCGGCGACGCTGCACGTGGACGAACCCACCCCGCACGTCGACTGGGCCGAGGGTCAGGTCAGCCTGCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACAC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 1477,
       "end": 1760,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "Malonyl-CoA"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPT",
       "dna_sequence": "CTGTTCGCCGGACAAGGCACCCAACGCCTCAACATGGGCCGCCAACTCTACGACACCAACCCCACCTTCGCCCACGCCCTCGACACCGTCACCAACGCCCTCAACCCCCACCTCAACCAACCCCTCCTCGACATCATCTTCGGCACCGACCCCCACCTCCTCAACCGCACCGAAAACGCCCAACCCGCCCTCTTCGCCATCGAAACCGCCCTCTACCACCTCCTCACCCACCACGGCATCCACCCCGACTACCTCCTCGGCCACTCCCTCGGCGAAATCACCGCCGCCCACGCCGCCGGCATCCTCACCCTCACCGACGCCGCCACCCTCGTCACCACCCGCGCCAAACTCATGCAAACCGCCACCCCCGGCGGCGCCATGATCGCCATCGAAGCCACCGAAACCGAAATCCAACCCACCCTCCACCCCACCGTCACCATCGCCGCCATCAACACCCCCACCACCACCGTCATCAGCGGCGACCACCACCACACCCACGCCATCGCCCACCACTGGCGCCAACAAGGCCGACGCACCACCACCCTCACCGTCAGCCACGCCTTCCACTCCCCCCACATGGACCCCATCCTCGACACCTTCCACACCACCACCCAAACCCTCACCCACCACCCACCCCACACCCCCCTCATCACCAACCTCACCGGACAACCCCTCACCAACCCCACACCCGAACACTGGACCCACCACCTCCGCCAACCCGTCCGCTACCACGACGCCACCACCACCCTCACCCACCACGGCGTCACCCACACCATCGAAATCGGCCCCGACACCACCCTCACCACCCTCACCAAAACCAACCACCCCACCCTCACCACCACCCCCACC",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PKS_DH",
       "start": 1824,
       "end": 1976,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "HPLLGAAVTLADDSTVYTGRLSRRTAPWLADHVVLGRALLPGTALLEYALWAGRDVGLPRVAELTLEAPLVLPDEGVTQVRVTVGPPGEQRTVAVHARADDAEQWTRHASGMLTAAPPASPVPPRVDGPPVDVDDLYERLAGKGYEYGPAFR",
       "dna_sequence": "CACCCGCTGCTGGGCGCCGCCGTGACGCTCGCCGACGACAGCACCGTCTACACCGGACGGCTGTCCCGGCGTACCGCCCCCTGGCTGGCCGACCACGTGGTGCTCGGCCGGGCGTTGCTGCCCGGCACCGCCCTGCTGGAGTACGCGCTGTGGGCGGGCCGGGACGTCGGGCTGCCCCGGGTGGCCGAGCTGACGCTGGAGGCCCCGCTGGTGCTGCCCGACGAGGGCGTGACGCAGGTGCGGGTCACCGTCGGCCCGCCGGGTGAGCAGCGGACCGTCGCCGTGCACGCGCGGGCCGACGACGCCGAGCAGTGGACCCGGCACGCCAGCGGCATGCTCACGGCGGCGCCCCCGGCGTCCCCGGTCCCCCCACGCGTGGACGGCCCGCCGGTCGACGTCGACGACCTGTACGAGCGGTTGGCCGGCAAGGGCTACGAGTACGGGCCCGCCTTCCGC",
       "abbreviation": "DH",
       "html_class": "jsdomain-mod-dh"
      },
      {
       "type": "PKS_KR",
       "start": 2189,
       "end": 2365,
       "predictions": [
        [
         "KR activity",
         "active"
        ],
        [
         "KR stereochemistry",
         "(unknown)"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "GTVLVTGGTGALGALVARHLVRAHRVRDLVLVSRRGADAPGAAALADELAGHGARVDLRACDVADREALACLLADLPTLDAVVHAAGVVRDATVSALTVEQVRAAATKAESAWHLHELTRDRPLRAFVLFSSISGLLGTAGQGAYAAANAALDALAAHRHALGLPALSLAWGLWED",
       "dna_sequence": "GGCACCGTGCTCGTCACCGGCGGGACCGGAGCCCTGGGCGCACTGGTCGCCCGGCACCTCGTCCGCGCCCACCGCGTGCGGGACCTCGTGCTGGTCAGCCGGCGCGGCGCGGACGCACCGGGTGCGGCCGCGCTGGCCGACGAGTTGGCGGGCCACGGCGCGCGGGTCGACCTGCGGGCATGTGACGTCGCCGACCGGGAGGCGTTGGCCTGCCTGCTCGCCGACCTGCCCACCCTCGACGCGGTCGTGCACGCGGCCGGGGTGGTCCGGGACGCGACGGTGTCCGCGCTGACCGTCGAGCAGGTACGCGCGGCCGCGACCAAAGCCGAGTCGGCCTGGCACCTGCACGAGCTGACCCGGGACCGTCCCCTGCGGGCGTTCGTGCTGTTCTCCTCGATCAGTGGGCTGCTGGGCACCGCCGGCCAGGGCGCGTATGCGGCCGCCAACGCCGCGCTGGACGCGCTGGCCGCGCACCGGCACGCCCTCGGCCTACCGGCGCTGTCCCTGGCCTGGGGTCTGTGGGAGGAC",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      },
      {
       "type": "PKS_PP",
       "start": 2443,
       "end": 2521,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "PRDEAELREVVRSVVAEVLGYPSAAGVDSARPFRDLGLDSLGGVELRNRLAAATGLPVPATLVFDHPTPDAVVAHLLG",
       "dna_sequence": "CCGCGTGACGAGGCCGAACTGCGGGAGGTGGTCCGTTCGGTGGTCGCCGAGGTGCTGGGGTACCCGTCGGCCGCCGGGGTGGACTCGGCCCGCCCGTTCCGCGACCTGGGGCTCGACTCGCTCGGCGGGGTGGAGCTGCGCAACCGCCTCGCCGCCGCGACCGGCCTGCCGGTGCCCGCCACGCTGGTGTTCGACCATCCGACGCCGGACGCCGTGGTGGCCCACCTGCTCGGC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "PKS_KS(Modular-KS)",
       "start": 2541,
       "end": 2963,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWDLGRLYDPDPEHAGTSYTRHGGFLYDAADFDAGFFALSPREATATDPQQRLLLEVAWEAFERAGIDPTAVRGSRTGVFAGVMYGDYGTRWRTAPEGFEGHLLTGNTSSVVSGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMATPHTFVEFSRQRGLSPDGRCRSFSAAANGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEH",
       "dna_sequence": "ATCGCGATCGTGGGGATGGCCTGCCGGTATCCCGGTGGTGTCTCCTCGCCGGAGGACCTGTGGCGGCTGGTGGCCGACGGTGTGGACGCGATCGGCGAGTTCCCCACCGACCGGGGCTGGGACCTGGGCCGGCTCTATGACCCCGACCCCGAACACGCCGGCACCTCGTACACCCGCCACGGCGGCTTCCTCTACGACGCGGCCGACTTCGACGCCGGGTTCTTCGCGCTGAGCCCGCGCGAGGCCACCGCCACGGACCCGCAGCAGCGGCTGCTGTTGGAGGTGGCGTGGGAGGCGTTCGAGCGGGCGGGAATCGACCCGACCGCGGTACGCGGCAGTCGGACGGGTGTGTTCGCGGGCGTCATGTACGGCGACTACGGGACGCGGTGGCGTACCGCCCCGGAGGGTTTCGAGGGGCACCTGCTCACCGGCAACACCTCCAGCGTGGTCTCGGGTCGGGTGGCGTACAGCTTCGGGTTGGAGGGTCCGGCGGTCACCGTGGACACCGCCTGCTCGTCCTCTCTGGTGGCCCTGCACCTGGCCGCCCAGTCACTGCGCAGCGGCGAGTGCGATCTGGCGCTGGCCGGCGGCGTCACGGTGATGGCGACGCCGCACACCTTCGTGGAGTTCAGCCGTCAGCGGGGGTTGTCCCCGGACGGGCGCTGCCGGTCGTTCTCGGCGGCGGCGAACGGTACGGGATGGAGTGAGGGTGCGGGCCTGCTGCTCGTCGAACGCCTCTCCGACGCCCGCGCCAACGGCCACCACGTCCTGGCCATCCTCCGCGGCTCCGCCGTCAACCAGGACGGCGCCTCCAACGGACTCACCGCACCCAACGGACCCGCCCAACAACGCGTCATCCGCACCGCCCTCACCAACGCCCACCTCCAACCCACCGACATCGACCTCGTCGAAGCCCACGGCACCGGCACCCGCCTCGGCGACCCCATCGAAGCCCAAGCCCTCATCGCCACCTACGGCCACCACCGCAACACCCCACTACACCTCGGCTCACTGAAATCCAACATCGGCCACACCCAAGCCGCCGCCGGCGTCGCCGGAGTCATCAAAGTCATCCAAGCCATGCAACACGGCACTCTCCCCGCCACACTGCACGTGAACGAACCCACCCCACACGTCAACTGGGCCGACAGCCAGGTCACCCTCCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACAC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 3061,
       "end": 3344,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "Malonyl-CoA"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LFAGQGTQRLNMGRQLYDTNPTFAHALDTVTNALNPHLNQPLLDIIFGTDPHLLNRTENAQPALFAIETALYHLLTHHGIHPDYLLGHSLGEITAAHAAGILTLTDAATLVTTRAKLMQTATPGGAMIAIEATETEIQPTLHPTVTIAAINTPTTTVISGDHHHTHAIAHHWRQQGRRTTTLTVSHAFHSPHMDPILDTFHTTTQTLTHHPPHTPLITNLTGQPLTNPTPEHWTHHLRQPVRYHDATTTLTHHGVTHTIEIGPDTTLTTLTKTNHPTLTTTPT",
       "dna_sequence": "CTGTTCGCCGGACAAGGCACCCAACGCCTCAACATGGGCCGCCAACTCTACGACACCAACCCCACCTTCGCCCACGCCCTCGACACCGTCACCAACGCCCTCAACCCCCACCTCAACCAACCCCTCCTCGACATCATCTTCGGCACCGACCCCCACCTCCTCAACCGCACCGAAAACGCCCAACCCGCCCTCTTCGCCATCGAAACCGCCCTCTACCACCTCCTCACCCACCACGGCATCCACCCCGACTACCTCCTCGGCCACTCCCTCGGCGAAATCACCGCCGCCCACGCCGCCGGCATCCTCACCCTCACCGACGCCGCCACCCTCGTCACCACCCGCGCCAAACTCATGCAAACCGCCACCCCCGGCGGCGCCATGATCGCCATCGAAGCCACCGAAACCGAAATCCAACCCACCCTCCACCCCACCGTCACCATCGCCGCCATCAACACCCCCACCACCACCGTCATCAGCGGCGACCACCACCACACCCACGCCATCGCCCACCACTGGCGCCAACAAGGCCGACGCACCACCACCCTCACCGTCAGCCACGCCTTCCACTCCCCCCACATGGACCCCATCCTCGACACCTTCCACACCACCACCCAAACCCTCACCCACCACCCACCCCACACCCCCCTCATCACCAACCTCACCGGACAACCCCTCACCAACCCCACACCCGAACACTGGACCCACCACCTCCGCCAACCCGTCCGCTACCACGACGCCACCACCACCCTCACCCACCACGGCGTCACCCACACCATCGAAATCGGCCCCGACACCACCCTCACCACCCTCACCAAAACCAACCACCCCACCCTCACCACCACCCCCACC",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PKS_DH",
       "start": 3404,
       "end": 3560,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "HPLLPGVVDLADGGLVLTGTVSADSHPWLAGHRIGGATLLPATAVVEAVAHAASRVGLDVDELVLTAAVPVDAPVRLRLTVGPASDDDSRAVHLHGNTDDGEWLPYATGRLAVVTQSPAADLATWPPTDAEPVDVVDLYDRLAEGGYGYHGLFQGL",
       "dna_sequence": "CATCCCCTGCTGCCCGGCGTCGTCGACCTGGCCGACGGGGGGTTGGTCCTCACCGGCACGGTGAGCGCCGACAGCCACCCCTGGCTGGCGGGGCACCGGATCGGTGGCGCGACGCTGCTGCCCGCCACCGCCGTGGTGGAGGCGGTGGCGCACGCGGCCAGCCGCGTCGGCCTGGACGTCGACGAACTGGTCCTGACGGCCGCCGTGCCGGTCGATGCCCCGGTGCGCCTACGGCTCACCGTCGGGCCGGCGTCCGACGACGACAGCCGCGCTGTGCACCTGCACGGCAACACCGACGACGGCGAGTGGTTGCCGTACGCCACCGGGCGGCTCGCGGTCGTCACGCAGTCGCCCGCCGCCGACCTCGCCACCTGGCCGCCGACCGACGCCGAGCCGGTGGACGTGGTCGACCTCTACGACCGGCTGGCCGAGGGCGGCTACGGCTACCACGGCCTGTTCCAGGGGCTG",
       "abbreviation": "DH",
       "html_class": "jsdomain-mod-dh"
      },
      {
       "type": "PKS_KR",
       "start": 3802,
       "end": 3980,
       "predictions": [
        [
         "KR activity",
         "active"
        ],
        [
         "KR stereochemistry",
         "B1"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "TVLVTGGTGALGALVARHLVVRHGVRRLLLTSRRGPAADGAAELVDELTAAGAEVEVVACDVADRPAVAALLASIPEEHPLTAVIHTAGVLDDGALTSLTEERLARVLRPKAEAAWHLHEFTRDRPLTAFVLFSSITGITGTAGQANYAAANAYLDALARHRRNLGLPGVSLAWGLWG",
       "dna_sequence": "ACGGTGCTGGTGACCGGCGGCACCGGCGCTCTCGGCGCGCTGGTCGCCCGGCATCTGGTCGTCCGGCACGGGGTACGGCGCCTGCTGCTGACCAGCCGGCGTGGCCCGGCCGCCGACGGCGCGGCCGAGCTGGTGGACGAGCTGACCGCGGCGGGCGCCGAGGTCGAGGTGGTGGCGTGCGACGTGGCGGATCGTCCGGCGGTGGCGGCGCTGTTGGCCAGCATCCCCGAGGAGCACCCGCTCACCGCCGTCATCCACACCGCCGGCGTGCTGGACGACGGCGCGCTCACCTCGCTCACCGAGGAGCGCCTGGCCCGGGTGCTGCGGCCCAAGGCGGAGGCGGCCTGGCACCTGCACGAGTTCACCCGGGACCGGCCCCTCACCGCCTTCGTGCTCTTCTCCTCGATCACCGGCATCACCGGCACGGCGGGACAGGCCAACTACGCCGCCGCGAACGCCTACCTGGACGCGCTGGCCCGGCACCGCCGCAACCTCGGCCTGCCCGGCGTCTCCCTGGCCTGGGGGCTGTGGGGG",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      },
      {
       "type": "ACP",
       "start": 4055,
       "end": 4127,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ELVRAQVAAVLGHTDATEVSTDVAFTGLGLDSLTAVELRNRIAERTGLRLSSTVVFDHPSVDALTDHLVAEL",
       "dna_sequence": "GAGCTGGTCCGCGCCCAGGTGGCCGCGGTGCTCGGGCACACCGACGCCACCGAGGTGTCCACCGACGTCGCGTTCACCGGGCTTGGCCTGGACTCCCTCACGGCGGTCGAGCTGCGCAACCGGATCGCCGAGCGTACCGGGCTGCGCCTGTCGAGCACGGTGGTCTTCGACCATCCCTCGGTGGACGCGCTCACCGACCACCTGGTCGCGGAACTG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "PKS_KS(Modular-KS)",
       "start": 4146,
       "end": 4569,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IAIVGMACRYPGGVSSPEDLWRLVADGVDAIGEFPTDRGWGEIHDPDPDRPGHSYTRHGGFLYAAGDFDAELFGMSPREALTTDPQQRLLLEVAWEAFERAGLPPGSLRGSRTGVFTGVMYNDYGARLHQAGTPAPGYEGYLVSGSAGSVASGRVAYSFGLEGPAVTVDTACSSSLVALHLAAQSLRSGECDLALAGGVTVMASPATFVEFSRQRGLAPDGRCKPFAAAADGTGWSEGAGLLLVERLSDARANGHHVLAILRGSAVNQDGASNGLTAPNGPAQQRVIRTALTNAHLQPTDIDLVEAHGTGTRLGDPIEAQALIATYGHHRNTPLHLGSLKSNIGHTQAAAGVAGVIKVIQAMQHGTLPATLHVNEPTPHVNWADSQVTLLTEATPWPDTGRPRRAAVSSFGISGTNAHVILEH",
       "dna_sequence": "ATCGCGATCGTGGGGATGGCCTGCCGGTATCCCGGTGGTGTCTCCTCGCCGGAGGACCTGTGGCGGCTGGTGGCCGACGGTGTGGACGCGATCGGCGAGTTCCCCACCGACCGGGGCTGGGGCGAGATCCACGACCCGGACCCGGACCGGCCGGGACACAGCTACACCCGGCACGGGGGCTTCCTCTATGCGGCGGGCGACTTCGACGCGGAGCTGTTCGGCATGAGCCCGCGCGAGGCGCTGACCACCGACCCGCAGCAACGGCTGCTGCTGGAGGTGGCGTGGGAGGCGTTCGAGCGGGCGGGGCTGCCACCGGGATCGCTGCGGGGCAGCCGGACCGGCGTGTTCACCGGCGTGATGTACAACGACTACGGCGCGCGGCTGCACCAGGCCGGCACGCCCGCCCCGGGCTACGAGGGCTACCTGGTCAGTGGCAGCGCGGGCAGCGTCGCCTCCGGTCGGGTGGCGTACAGCTTCGGGTTGGAGGGCCCGGCGGTCACCGTGGACACCGCCTGCTCGTCCTCCCTGGTGGCCCTGCACCTGGCCGCCCAGTCACTGCGCAGCGGCGAATGCGATCTGGCGCTGGCCGGCGGCGTCACAGTCATGGCCAGCCCGGCGACCTTCGTGGAGTTCAGCCGACAACGCGGCCTCGCACCCGACGGCCGGTGCAAACCATTCGCAGCCGCAGCCGACGGCACCGGATGGAGTGAGGGTGCGGGCCTGCTGCTCGTCGAACGCCTCTCCGACGCCCGCGCCAACGGCCACCACGTCCTGGCCATCCTCCGCGGCTCCGCCGTCAACCAGGACGGCGCCTCCAACGGACTCACCGCACCCAACGGACCCGCCCAACAACGCGTCATCCGCACCGCCCTCACCAACGCCCACCTCCAACCCACCGACATCGACCTCGTCGAAGCCCACGGCACCGGCACCCGCCTCGGCGACCCCATCGAAGCCCAAGCCCTCATCGCCACCTACGGCCACCACCGCAACACCCCACTACACCTCGGCTCACTGAAATCCAACATCGGCCACACCCAAGCCGCCGCCGGCGTCGCCGGAGTCATCAAAGTCATCCAAGCCATGCAACACGGCACTCTCCCCGCCACACTGCACGTGAACGAACCCACCCCACACGTCAACTGGGCCGACAGCCAGGTCACCCTCCTCACCGAAGCCACACCCTGGCCCGACACCGGCCGACCCCGCCGCGCCGCCGTCTCCTCCTTCGGCATCAGCGGCACCAACGCCCACGTCATCCTCGAACAC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 4661,
       "end": 4926,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "Malonyl-CoA"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FTGQGSQRAGMGLGLAARFPQFADALASVAEALDPHLPSPLLDVLADGDLLERTEYAQPAIFAVEVALFRLLAHYGVTPHVLLGHSVGELAAAHVAGVLDLPDAATLVAARGRLMGGLVPGGAMAAVRAGEDEVLALLVPGAEIAAVNADDAVVVSGDAEAVAAVTQALRDAGRRVTPLRVSHAFHSARMDPVLEEFRAVAATLRFSEPTIPLISLLPGSPTDPGYWVRHLREAVRFGDGVRSLAEWGVRRVLEVGPDAALTPVT",
       "dna_sequence": "TTCACCGGCCAGGGCAGCCAGCGCGCCGGAATGGGGCTGGGACTGGCCGCCCGGTTCCCTCAGTTCGCCGACGCGCTCGCGTCCGTGGCAGAAGCCCTCGACCCGCACCTGCCGTCGCCGCTGCTCGACGTGCTCGCCGACGGCGACCTGCTGGAACGCACCGAGTACGCCCAACCGGCCATCTTCGCCGTGGAGGTGGCGCTGTTCCGGCTGCTGGCCCACTACGGAGTCACCCCGCACGTGCTGCTCGGGCACTCCGTCGGCGAGCTGGCCGCCGCGCACGTCGCCGGGGTGCTCGACCTACCCGACGCCGCCACGCTGGTCGCCGCGCGGGGACGCCTGATGGGAGGACTGGTTCCGGGTGGGGCCATGGCCGCCGTCCGGGCAGGCGAGGACGAGGTACTGGCGCTGCTGGTGCCCGGTGCGGAGATCGCCGCCGTCAACGCCGACGACGCGGTCGTCGTGTCCGGTGACGCGGAGGCCGTCGCAGCGGTCACCCAGGCCCTGCGCGACGCGGGCCGACGGGTCACCCCGTTACGGGTCAGCCACGCCTTCCACTCCGCCCGGATGGACCCGGTGCTGGAGGAGTTCCGGGCGGTGGCGGCCACGCTGCGGTTCTCCGAGCCCACCATCCCGCTGATCTCCCTGCTGCCCGGTTCCCCCACCGACCCCGGGTACTGGGTGCGGCACCTGCGCGAGGCGGTCCGCTTCGGCGACGGCGTACGGTCGCTGGCCGAGTGGGGCGTACGGCGCGTCCTGGAGGTGGGTCCGGACGCCGCGCTGACCCCGGTGACC",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PKS_DH",
       "start": 4998,
       "end": 5149,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "HPLLDAAVELPEGAVLFTGRVAAEDADWLADHVVLGQTVVSGATLLSLVLHAAAAAGRPTVRRLTLHAPLVLPDDGGAADLRVGVDEQGQVTVYARPAGGGWTRHASGTLDTVEQPAEALGSWPPAGAEPLDVDYTRLADAGYAYGPGCRR",
       "dna_sequence": "CATCCGCTGCTCGACGCGGCGGTGGAGCTGCCCGAGGGTGCCGTGCTGTTCACCGGCCGGGTGGCCGCCGAGGACGCCGACTGGCTGGCCGACCACGTGGTGCTGGGCCAGACCGTGGTCTCCGGCGCCACACTGCTGAGCCTGGTCCTGCATGCCGCGGCCGCGGCGGGACGACCCACGGTGCGGCGGCTGACGCTGCACGCGCCGCTGGTGCTGCCCGATGACGGCGGCGCGGCCGACCTGCGGGTCGGTGTCGACGAGCAGGGGCAGGTGACGGTGTACGCCCGGCCGGCCGGCGGCGGGTGGACCCGGCACGCCTCCGGCACGCTGGACACCGTCGAGCAGCCCGCCGAGGCGCTCGGGTCGTGGCCGCCGGCCGGTGCCGAGCCGCTCGACGTGGACTACACGCGACTGGCCGACGCGGGTTACGCGTACGGCCCCGGCTGCCGCCGG",
       "abbreviation": "DH",
       "html_class": "jsdomain-mod-dh"
      },
      {
       "type": "PKS_KR",
       "start": 5407,
       "end": 5582,
       "predictions": [
        [
         "KR activity",
         "active"
        ],
        [
         "KR stereochemistry",
         "(unknown)"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "GTVLVTGAGGALGSLTARRLVTHHGVRRLLLLGRRGGMQPLAAELTALGATVRVAACDAANRAALARVLDTVPAAHPLTAVVHAAGVVSDGPLATLTPQRFAEVLRPKVDAAWHLHELTCEQDLAAFVLFSSLAGLVGNAGQANYAAANTGLDALAAYRRAAGLPAVSLAWGLWD",
       "dna_sequence": "GGGACGGTCCTGGTCACCGGTGCGGGTGGAGCCCTCGGCTCACTGACGGCCCGGCGCCTGGTCACCCACCACGGCGTACGGCGGCTCCTGCTGCTCGGCCGGCGCGGCGGGATGCAACCGCTGGCCGCCGAGCTGACCGCCCTGGGCGCCACGGTGCGGGTCGCGGCCTGCGACGCGGCCAACCGGGCGGCGCTGGCCCGGGTGCTCGACACCGTCCCCGCCGCGCACCCGCTCACCGCCGTGGTGCACGCGGCCGGGGTGGTGTCCGACGGGCCGCTGGCCACGTTGACGCCGCAGCGCTTCGCCGAGGTGCTGCGCCCGAAGGTGGACGCGGCGTGGCACCTGCATGAGCTGACCTGCGAGCAGGACCTGGCGGCGTTCGTGCTGTTCTCCTCCCTCGCCGGGCTGGTGGGCAACGCCGGCCAGGCCAATTACGCGGCCGCGAACACCGGCCTGGACGCCCTCGCCGCGTATCGCCGGGCCGCCGGGTTGCCGGCCGTGAGCCTGGCCTGGGGCCTGTGGGAC",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      },
      {
       "type": "PKS_PP",
       "start": 5662,
       "end": 5747,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LAGRGAAEQHRLLLELVRSTIVEVLGHSSVAAVAPDRGLMDLGFDSLTAVELAGRLGADTGVRTPSTVVFDHPTPTALAHYLRHE",
       "dna_sequence": "CTCGCCGGGCGGGGCGCCGCCGAGCAGCACCGGCTGCTGCTGGAGCTGGTCCGCAGCACGATCGTCGAGGTCCTCGGCCACTCCTCCGTCGCAGCCGTGGCACCCGACCGGGGGTTGATGGACCTCGGCTTCGACTCCCTCACCGCCGTCGAGCTGGCCGGGCGCCTCGGTGCCGACACCGGCGTCCGCACCCCGTCGACGGTGGTGTTCGACCATCCGACACCCACCGCGCTCGCCCACTACCTGCGACACGAG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 7,
       "end": 937,
       "complete": true,
       "iterative": false,
       "monomer": "mal",
       "multi_cds": null,
       "match_id": null
      },
      {
       "start": 956,
       "end": 2521,
       "complete": true,
       "iterative": false,
       "monomer": "ccmal",
       "multi_cds": null,
       "match_id": null
      },
      {
       "start": 2541,
       "end": 4127,
       "complete": true,
       "iterative": false,
       "monomer": "ccmal",
       "multi_cds": null,
       "match_id": null
      },
      {
       "start": 4146,
       "end": 5747,
       "complete": true,
       "iterative": false,
       "monomer": "ccmal",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "abyB2",
     "sequence": "MTTPSKGTDSIADQQKLREYLRRVTDDLLRTRRRLTEVESADREPVAIVSMACRFPGGVASPEDLWQLVASGTDAISGFPDDRGWPLDELYDPDPEHPGTSTTRQGGFLHDAADFDPEFFGISPREALTIDPQQRLLLETAWEAVERAGIAPDSLRGSRTGVFAGVMYGDYGARLRPIPAGFEGYMGTGSAGSVATGRIAYTLGLEGPAVSVDTACSSSLVALHLAAQALRRGECDLALAGGVTVIATPELFVEFSRQRGLSPDGRCKAFAASADGTGWAEGVGLVLVERLADARRNGHPVLALLRGSAVNQDGRSSQLSAPNGPAQRRVIRAALASAGLEPAEVDLVEAHGTGTRLGDPIEAQALLAEYGQGRTEPLWLGSLKSNIGHTQAAAGVGGVIKVVQAMRHGLLPATLHADEATPHVDWSVGDVRLLTEARDWPARERPRRAAVSSFGISGTNAHVILEEGDPDGVADAPPDDVLARKPVPVVLSAHTASALGPQAARLRAHLDAHPDLTVADVAHSLATTRTPLAERAVLVAADLDELRTALDAVADGDEPPVRGTAGHPGGVVFVFPGQGAQWAGMALDLYREDEVFRAALDDCERALAPHVDWSLRAVLADADALGRVDVVQPALWAVMVSLAALWQHHGVTPDAVVGHSQGEIAAACVAGALSLEQAAAVVALRARAITAVAGRGAMASVSVPAQQITERWGDRITVAVTNSADATVVAGEPEAVAEVVAAYDAEGVRARVLPVDYASHSAHVEPVREPILDALRDLTPTEARVPFHSTVTGAEFDTRGLTADYWYTNLRSTVRFDQAVTRLREQGHRIFVEISPHPVLTPVLGEGAFGTLRRDEGDRRRFITSLGAVHAVGVPVDWSAAIGPARRVPLPTYAFQRSRYWLDAPARTGDASGVGVGPTDHPLLGGAVDVAGDGTLVLTGRLVPGADRAAAELRVGGVPVLSGTALLDLALRAGELAGLGAVGEFSVETPLVLSATAGWLQVVVAPAGADGDREIGVYARPDHEAPWTRHGHGVLVPATAQDLPPHRPVPGAPLAPDEAVERLAAAGVELASAPTAVSGDADGYVADLASPPEGRFTLHPALLDAALLPAFGRGDARLPSRWRGVRLPQPDGQPTRASVRRRDGDSWAVSLTDSAGAPVVEIAEVVLGPVPVVSAAGHHDPLFTLEWAPVARPRGAAATEPVPHELPGDAGPAALAVLRGGLAEPDGPRQVVVARGAGTVTGLVRCAQLEEPGRVGLVEWDGRDADALRDAVAAGLPQVAVHGAELRTPRLAPLTAPGRPVELDGTALIVGEAGALRDAVLRTLARHGVDRLVVVDVDGTAPADVGVPTEVLTGDPTDRAVLAEAVHRAANLRTVVHAVQPTADAPLAALSPEDLTALVERIVAPARHLHELTAHLPLTRFVLSGSAAGVLGGIGQAAVAAATTGLGALAARRRADGLPAQVVAWGPSAGTRRLGLVSLDDARLAALFAQVLAHDVDVVAAPLVRAGLRGQARAGTLPVALRALVPALPGGATGLAARLAGASPAEGRRLLLDTIRTHVAGVLGHDDASGIDERRAFKDLGFDSLTAIELRNRLNTALGRTLPATLIFDHPSPGALAEHLRDDLLGRAAVAAAPVAVASDEPIAIVAMGCRYPGGIADPEALWQAVVSELDAVGPFPTDRGWPADLYDPDPEATGRTYAREGGFLYDAAGFDPEFFGISPREATGMDPQQRLLLQTGWEVFERAGIDPTALRGSRTGVFAGVVYTDYGSRADPIPADLEGYLGIGSAGSIASGRIAYTLGLEGPAVTVDTACSSSLVALHLAVQSLRRGECDLALAGGATVLSNPDIFVGFSRQRGLSPDSRCKAFAAAADGTAFAEGVGLLLVQRLADARRDGRPVLAVIRGTAINQDGASNGLTAPNGPSQQRVILGALADAGLRPSDVDVVEAHGTGTTLGDPIEAQAIIATYGQGRDEPLLLGSLKSNIGHTQAAAGVGGVIKMVAAMRHGLVPRTLHVDEPTPHVDWSAGAVRLVTEARPWPESNRPRRAGVSSFGMSGTNAHVVVEQGDPLEVPPVRAGRLVPVPVSAANPAALRRQAARLLPAVADRHPADVARTLAARTSLATRAVVLADDADELAEGLRALDDATFTGPVGDADEPGKVVFVFPGQGGQWTGMALDLYRDEPTFRESLDACAAALAPHVDWALLDVLADEEALRRVDVVQPALWAVMVSVARLWQHHGVTPDAVVGHSQGEIAAAHVAGALSLADAAAVVALRARAITAIAGTGGMASVALGVGEVTRRWGHTVAVAATNGPDTAVIAGDPGVLDHIAATCAAEEVRVKILPVDYASHSAHVEALREELLAALETVQPRAAEIAFCSTVTAEALDTTTLTADYWYTNLRSTVRYDETVRRLHAEGHRTFLEMSPHPVLTTVTEQVTGAVALGTLRRDEGDRRRFLTALAEAYVTGVAVDWRPAVGADARLVDLPTYAFASDRYWLDATTRPVDATGLGLAATAHPLLGAAVDLADDEGVLLTGRLSLDSHPWLADHTVAGVPLLPGAAFVELCAQAAEAAGAAGVAELTLETPCVLPERGGVDVQVQVRDGGLRVYSRSVGDAWVRNASGVLLPTEPPAPAGWGAWPPPGAQAVDVEGLYPQLAASGYGYGPAFRGLRAAWRRGEEVFAEVRLPEGLEPEGYGLHPALLDAALHALAFGDFLGAGVRLPFAFTGVRVFATGADILRVRLSPRGEDTVAVALADSTGAPVAEIESLVLRAAPSLEATAPHAPDVLVLDWTPLALPDTPVTEPDLLVVAPSDAHDPVAATGRLVTSTIAELAGRLADDRGAVVVTRDAVAVRPGDPAADLAHAALWGLLRSAQTENPDRFTLVDTDGRPESAAVVAAAVATGEPQIAVREGRGYVPRLARAAANRGLVPPPGAWRLEAAGTTVDELRLTEVTEAPLPAGHVRVAVRACGLNFRDVLATLGVVPRDAPLGAEGAGVVVEVGVGVTGFAPGDRVYGFLQGAIGPRAVVDARLLAHLPAGWSFAQAATAPAVCTTAYYALVTLADLRPGERVLIHSAAGGVGLAAGHLARHLGAEVFGTASPAKWAALDLDEAHLASSRNTDFADRFGPVDVVLNSLTGEFIDASLRLLGPGGRFVEMGVADLRSSEQMPTGVDYHAFELLDLAPARVGELFAEVVRLIDQGVFPPLPVTAWDVRRAPEALRYFSQARQIGKIALTAPVPLDPNGTVLVTGGTGSLGGLVARHLARAHGVRHLLLVSRSGPAAPGATELVGELTSLDVRVDVVAADLADRAAVAGVLAAVPPEHPLTAVVHTAGVLDDGVLESLTPQKIARVLAPKVDAAWHLHELTRDLDLSAFLLFSSASGLLGGAGQANYAAANAFLDALATARRRAGLPAVSLAWGMWARATGLTAHLGGTDLGRIERGGLLPMTDEQGLALFDATWTADRPVLVPAPLRLDRGRTGSGVVPAVLRALVRPVRRVARSAGTASPDSLRERLLPLSPTERTALLVDLVRTQVAAVLGHTDTDAVVVDRAFKDSGFDSLTAVELRNRVSRATGLRLPPTVVFDRPTPAELAAHLLDQLVPPADGPAGAATPARKTRKQLDSATVEEIFDLIDSQLGRGSRSDYQEVDAG",
     "domains": [
      {
       "type": "PKS_Docking_Nterm",
       "start": 14,
       "end": 41,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "QKLREYLRRVTDDLLRTRRRLTEVESA",
       "dna_sequence": "CAGAAGCTGCGCGAGTACCTCCGGCGGGTCACCGACGACCTGCTGCGGACCCGCCGGCGCCTGACCGAGGTGGAGTCGGCC",
       "abbreviation": "",
       "html_class": "jsdomain-docking"
      },
      {
       "type": "PKS_KS(Modular-KS)",
       "start": 45,
       "end": 467,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VAIVSMACRFPGGVASPEDLWQLVASGTDAISGFPDDRGWPLDELYDPDPEHPGTSTTRQGGFLHDAADFDPEFFGISPREALTIDPQQRLLLETAWEAVERAGIAPDSLRGSRTGVFAGVMYGDYGARLRPIPAGFEGYMGTGSAGSVATGRIAYTLGLEGPAVSVDTACSSSLVALHLAAQALRRGECDLALAGGVTVIATPELFVEFSRQRGLSPDGRCKAFAASADGTGWAEGVGLVLVERLADARRNGHPVLALLRGSAVNQDGRSSQLSAPNGPAQRRVIRAALASAGLEPAEVDLVEAHGTGTRLGDPIEAQALLAEYGQGRTEPLWLGSLKSNIGHTQAAAGVGGVIKVVQAMRHGLLPATLHADEATPHVDWSVGDVRLLTEARDWPARERPRRAAVSSFGISGTNAHVILEE",
       "dna_sequence": "GTGGCCATCGTCTCGATGGCCTGCCGCTTCCCCGGCGGGGTGGCTTCGCCGGAGGACCTGTGGCAGCTGGTGGCGTCCGGCACCGACGCGATCAGCGGGTTCCCCGATGACCGGGGCTGGCCACTGGACGAGCTGTACGACCCGGACCCGGAGCACCCGGGCACGTCCACCACCCGGCAGGGGGGTTTCCTGCACGACGCCGCCGACTTCGACCCGGAGTTCTTCGGGATCAGCCCCCGTGAGGCGTTGACCATCGACCCGCAGCAGCGGCTGCTGTTGGAGACCGCCTGGGAGGCGGTGGAGCGGGCCGGGATCGCACCGGACTCGCTGCGTGGCAGCCGGACCGGCGTGTTCGCCGGGGTCATGTACGGCGACTACGGTGCCCGCCTGCGCCCGATCCCGGCGGGCTTCGAGGGGTACATGGGCACCGGCAGCGCGGGCAGCGTGGCCACCGGCCGGATCGCGTACACCCTCGGCCTGGAGGGGCCGGCGGTGAGCGTCGACACGGCGTGCTCGTCGTCGCTGGTGGCGCTGCACCTCGCGGCGCAGGCGCTGCGGCGCGGCGAGTGCGACCTGGCGCTGGCCGGCGGCGTGACGGTCATCGCCACGCCGGAGCTGTTCGTGGAGTTCAGCCGCCAGCGGGGGTTGTCGCCGGACGGGCGGTGCAAGGCATTCGCGGCCTCGGCCGACGGCACGGGCTGGGCCGAGGGCGTCGGCCTGGTGCTTGTCGAACGGCTCGCCGACGCCCGCCGCAACGGTCACCCGGTGCTCGCGCTGCTGCGCGGCAGCGCCGTCAACCAGGACGGCCGCAGCAGCCAGCTCTCCGCGCCCAACGGCCCGGCGCAGCGGCGGGTCATCCGGGCGGCGCTGGCCAGTGCCGGCCTGGAGCCCGCCGAGGTCGACCTGGTGGAGGCACACGGCACCGGCACCCGGCTCGGTGACCCGATCGAGGCCCAGGCACTGCTGGCCGAGTACGGGCAGGGGCGCACGGAGCCGCTCTGGCTGGGCTCGCTCAAGTCGAACATCGGGCACACCCAGGCGGCGGCCGGCGTCGGCGGGGTGATCAAGGTGGTGCAGGCCATGCGGCACGGGCTCCTGCCCGCCACCCTGCACGCCGACGAGGCCACCCCGCACGTCGACTGGAGCGTCGGTGACGTCCGTCTGCTCACCGAGGCCCGCGACTGGCCGGCGCGGGAGCGGCCCCGGCGGGCGGCCGTGTCCTCCTTCGGCATCAGCGGCACCAACGCGCACGTGATCCTGGAGGAG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 573,
       "end": 845,
       "predictions": [
        [
         "substrate consensus",
         "mmal"
        ],
        [
         "PKS signature",
         "Methylmalonyl-CoA"
        ],
        [
         "Minowa",
         "mmal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VFPGQGAQWAGMALDLYREDEVFRAALDDCERALAPHVDWSLRAVLADADALGRVDVVQPALWAVMVSLAALWQHHGVTPDAVVGHSQGEIAAACVAGALSLEQAAAVVALRARAITAVAGRGAMASVSVPAQQITERWGDRITVAVTNSADATVVAGEPEAVAEVVAAYDAEGVRARVLPVDYASHSAHVEPVREPILDALRDLTPTEARVPFHSTVTGAEFDTRGLTADYWYTNLRSTVRFDQAVTRLREQGHRIFVEISPHPVLTPVLG",
       "dna_sequence": "GTCTTCCCCGGCCAGGGCGCCCAGTGGGCGGGCATGGCCCTGGACCTGTACCGCGAGGACGAGGTGTTCCGCGCGGCGCTGGACGACTGCGAGCGGGCCCTGGCCCCGCACGTCGACTGGTCGCTGCGGGCCGTGCTGGCCGACGCCGACGCCCTCGGACGCGTCGACGTCGTCCAGCCCGCCCTGTGGGCGGTGATGGTGTCACTGGCGGCGCTGTGGCAGCACCACGGCGTGACCCCCGACGCGGTCGTCGGCCACTCCCAGGGCGAGATCGCCGCCGCCTGTGTCGCGGGTGCCCTGTCGCTGGAGCAGGCCGCGGCCGTGGTGGCGCTGCGGGCGCGGGCCATCACCGCCGTCGCGGGTCGCGGTGCCATGGCGTCGGTTTCTGTGCCCGCACAGCAGATCACCGAGCGGTGGGGCGACCGGATCACCGTGGCCGTGACGAACTCCGCCGACGCGACGGTCGTCGCCGGTGAACCAGAGGCCGTCGCCGAGGTGGTCGCCGCGTACGACGCCGAGGGAGTCCGGGCCCGGGTCCTGCCGGTGGACTACGCCTCCCACTCGGCGCACGTGGAGCCCGTGCGGGAGCCGATCCTCGACGCGCTGCGCGACCTCACCCCGACCGAGGCCCGGGTCCCGTTCCACTCCACCGTCACCGGTGCGGAGTTCGACACCCGGGGCCTGACCGCCGACTACTGGTACACCAACCTGCGCAGCACCGTCCGGTTCGACCAGGCGGTGACCCGGCTACGCGAACAGGGCCACCGGATCTTCGTCGAGATCAGCCCGCATCCGGTACTGACGCCGGTGCTCGGC",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PKS_DH",
       "start": 920,
       "end": 1073,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "HPLLGGAVDVAGDGTLVLTGRLVPGADRAAAELRVGGVPVLSGTALLDLALRAGELAGLGAVGEFSVETPLVLSATAGWLQVVVAPAGADGDREIGVYARPDHEAPWTRHGHGVLVPATAQDLPPHRPVPGAPLAPDEAVERLAAAGVELASA",
       "dna_sequence": "CACCCGCTGCTCGGCGGTGCCGTCGACGTGGCCGGCGACGGCACGCTGGTGCTCACCGGGCGGCTGGTGCCCGGAGCGGACCGGGCCGCCGCCGAGCTGCGGGTCGGCGGCGTACCCGTGCTGTCCGGCACCGCGCTGCTCGACCTCGCCCTACGGGCGGGCGAGCTGGCCGGTCTGGGTGCGGTCGGCGAGTTCAGCGTGGAGACGCCTTTGGTGCTGTCCGCCACCGCCGGTTGGTTGCAGGTCGTGGTGGCGCCGGCCGGCGCCGACGGCGACCGGGAGATCGGCGTGTACGCCCGGCCCGACCACGAGGCGCCCTGGACCCGGCACGGTCACGGTGTGCTCGTCCCGGCCACGGCGCAGGACCTCCCGCCGCACCGGCCGGTGCCGGGCGCACCGCTCGCCCCGGACGAGGCGGTGGAGCGGCTCGCCGCGGCCGGTGTGGAACTGGCCTCGGCG",
       "abbreviation": "DH",
       "html_class": "jsdomain-mod-dh"
      },
      {
       "type": "PKS_KR",
       "start": 1304,
       "end": 1467,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C1"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "GTALIVGEAGALRDAVLRTLARHGVDRLVVVDVDGTAPADVGVPTEVLTGDPTDRAVLAEAVHRAANLRTVVHAVQPTADAPLAALSPEDLTALVERIVAPARHLHELTAHLPLTRFVLSGSAAGVLGGIGQAAVAAATTGLGALAARRRADGLPAQVVAWGP",
       "dna_sequence": "GGCACGGCCCTGATCGTCGGGGAGGCCGGAGCGCTGCGCGACGCCGTGCTGCGCACGCTGGCGCGCCACGGCGTGGACCGGCTGGTGGTGGTGGACGTGGACGGCACGGCACCAGCCGACGTGGGCGTACCCACCGAGGTGCTCACCGGTGATCCCACCGACCGTGCCGTGCTCGCCGAGGCGGTCCACCGCGCCGCGAACCTGCGCACGGTCGTGCACGCCGTGCAGCCCACGGCCGACGCGCCGCTGGCCGCGCTGAGCCCCGAGGACCTCACGGCCCTGGTCGAGCGGATCGTGGCGCCGGCCCGGCACCTGCACGAACTGACCGCGCACCTGCCGCTGACCCGGTTCGTGCTGTCCGGCTCGGCGGCGGGTGTGCTGGGCGGCATCGGGCAGGCCGCCGTGGCGGCGGCCACCACCGGGTTGGGCGCGCTCGCGGCCCGCCGTCGCGCCGACGGGCTGCCCGCCCAGGTCGTCGCCTGGGGTCCG",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      },
      {
       "type": "PKS_PP",
       "start": 1538,
       "end": 1623,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LAGASPAEGRRLLLDTIRTHVAGVLGHDDASGIDERRAFKDLGFDSLTAIELRNRLNTALGRTLPATLIFDHPSPGALAEHLRDD",
       "dna_sequence": "CTGGCCGGCGCCTCCCCCGCCGAGGGGCGCCGTCTGCTGCTGGACACCATCCGTACCCATGTCGCCGGGGTGCTGGGCCACGACGACGCCAGCGGCATCGACGAGCGCCGCGCCTTCAAGGACCTCGGGTTCGACTCGCTCACCGCCATCGAGCTGCGCAACCGTCTCAACACCGCGCTGGGGCGGACCCTGCCCGCGACGCTGATCTTCGACCACCCCAGTCCCGGCGCTCTGGCCGAACACCTGCGCGACGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "PKS_KS(Modular-KS)",
       "start": 1642,
       "end": 2063,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IAIVAMGCRYPGGIADPEALWQAVVSELDAVGPFPTDRGWPADLYDPDPEATGRTYAREGGFLYDAAGFDPEFFGISPREATGMDPQQRLLLQTGWEVFERAGIDPTALRGSRTGVFAGVVYTDYGSRADPIPADLEGYLGIGSAGSIASGRIAYTLGLEGPAVTVDTACSSSLVALHLAVQSLRRGECDLALAGGATVLSNPDIFVGFSRQRGLSPDSRCKAFAAAADGTAFAEGVGLLLVQRLADARRDGRPVLAVIRGTAINQDGASNGLTAPNGPSQQRVILGALADAGLRPSDVDVVEAHGTGTTLGDPIEAQAIIATYGQGRDEPLLLGSLKSNIGHTQAAAGVGGVIKMVAAMRHGLVPRTLHVDEPTPHVDWSAGAVRLVTEARPWPESNRPRRAGVSSFGMSGTNAHVVVEQ",
       "dna_sequence": "ATCGCCATCGTCGCGATGGGCTGCCGCTATCCGGGCGGCATCGCCGACCCCGAGGCGTTGTGGCAGGCGGTGGTGTCGGAACTCGACGCGGTGGGACCGTTCCCGACCGACCGGGGCTGGCCGGCGGACCTGTACGACCCCGACCCGGAGGCCACCGGCCGCACGTACGCGCGTGAGGGCGGCTTCCTCTACGACGCCGCCGGGTTCGACCCGGAATTCTTCGGCATCAGCCCCCGCGAGGCCACCGGCATGGACCCGCAGCAGCGGCTGCTGCTGCAGACCGGCTGGGAGGTGTTCGAGCGGGCCGGGATCGACCCCACGGCGCTGCGCGGCAGCCGTACCGGGGTCTTCGCGGGGGTCGTCTACACCGACTACGGCTCCCGGGCCGACCCGATCCCCGCCGACCTGGAGGGATACCTCGGCATCGGCAGCGCCGGCAGCATCGCCTCCGGCCGCATCGCCTACACCCTCGGCCTGGAGGGCCCGGCGGTCACCGTGGACACCGCGTGCTCCTCGTCGCTGGTGGCGCTGCACCTGGCCGTGCAGTCGCTGCGCCGCGGCGAGTGCGACCTGGCCCTGGCGGGCGGTGCGACGGTGCTGTCCAACCCGGACATCTTCGTCGGCTTCTCGCGCCAGCGGGGCCTGTCCCCGGACAGCCGTTGCAAGGCGTTCGCCGCCGCCGCCGACGGCACCGCCTTCGCCGAGGGTGTCGGCCTGCTGCTGGTGCAGCGGCTCGCCGACGCGCGGCGCGATGGTCGGCCGGTGCTGGCCGTCATCCGGGGCACCGCCATCAACCAGGACGGCGCGTCCAACGGGCTCACCGCACCCAACGGGCCGTCGCAGCAGCGGGTCATCCTGGGTGCGCTGGCCGACGCGGGGCTGCGCCCGTCCGACGTCGACGTGGTGGAGGCGCACGGCACCGGCACCACCCTGGGCGACCCGATCGAGGCGCAGGCGATCATCGCCACCTACGGGCAGGGCCGCGACGAGCCGCTGCTGCTCGGCTCGCTGAAGTCGAACATCGGCCACACCCAGGCCGCAGCCGGTGTCGGCGGCGTGATCAAGATGGTCGCCGCCATGCGACACGGGCTGGTGCCCCGGACCCTGCACGTCGACGAGCCGACCCCGCACGTGGACTGGTCGGCGGGTGCGGTCCGGCTGGTCACCGAGGCGCGGCCCTGGCCGGAGTCGAACCGGCCGCGCCGCGCCGGGGTGTCCTCGTTCGGCATGAGCGGCACGAACGCCCACGTCGTCGTCGAGCAG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 2160,
       "end": 2445,
       "predictions": [
        [
         "substrate consensus",
         "mmal"
        ],
        [
         "PKS signature",
         "Methylmalonyl-CoA"
        ],
        [
         "Minowa",
         "mmal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VFPGQGGQWTGMALDLYRDEPTFRESLDACAAALAPHVDWALLDVLADEEALRRVDVVQPALWAVMVSVARLWQHHGVTPDAVVGHSQGEIAAAHVAGALSLADAAAVVALRARAITAIAGTGGMASVALGVGEVTRRWGHTVAVAATNGPDTAVIAGDPGVLDHIAATCAAEEVRVKILPVDYASHSAHVEALREELLAALETVQPRAAEIAFCSTVTAEALDTTTLTADYWYTNLRSTVRYDETVRRLHAEGHRTFLEMSPHPVLTTVTEQVTGAVALGTLRR",
       "dna_sequence": "GTCTTCCCCGGGCAGGGCGGGCAGTGGACCGGCATGGCTCTGGACCTGTACCGCGACGAGCCCACCTTCCGCGAGTCCCTGGACGCCTGCGCCGCCGCGCTGGCACCGCACGTGGACTGGGCGTTGCTCGACGTGCTCGCCGACGAGGAGGCCCTGCGGCGGGTGGACGTCGTGCAGCCCGCGCTCTGGGCGGTGATGGTGTCGGTGGCCCGGCTCTGGCAGCACCACGGCGTCACGCCCGACGCGGTGGTCGGCCACTCCCAGGGTGAGATCGCCGCCGCCCACGTGGCCGGCGCGCTCAGCCTGGCCGACGCCGCCGCCGTGGTGGCGCTGCGGGCCAGGGCGATCACGGCGATCGCCGGGACCGGCGGCATGGCCTCGGTCGCACTCGGTGTCGGAGAGGTCACCCGGCGCTGGGGCCACACGGTGGCCGTCGCCGCGACCAACGGTCCGGACACCGCGGTGATCGCCGGCGACCCGGGCGTGCTGGACCACATCGCCGCCACGTGTGCCGCCGAGGAGGTCCGGGTGAAGATCCTGCCGGTCGACTACGCCTCACACTCCGCGCACGTGGAGGCACTGCGTGAGGAACTGCTGGCTGCGTTGGAGACCGTGCAACCCCGGGCCGCCGAGATCGCGTTCTGTTCCACGGTCACCGCCGAGGCGCTGGACACCACCACGCTCACGGCCGACTACTGGTACACGAACCTGCGCAGCACCGTGCGCTACGACGAGACGGTCCGCCGGCTGCACGCCGAGGGGCACCGCACCTTTCTGGAGATGAGCCCTCACCCGGTGCTGACCACCGTCACCGAGCAGGTCACCGGGGCGGTCGCGCTGGGCACGCTGCGCCGG",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PKS_DH",
       "start": 2512,
       "end": 2666,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "HPLLGAAVDLADDEGVLLTGRLSLDSHPWLADHTVAGVPLLPGAAFVELCAQAAEAAGAAGVAELTLETPCVLPERGGVDVQVQVRDGGLRVYSRSVGDAWVRNASGVLLPTEPPAPAGWGAWPPPGAQAVDVEGLYPQLAASGYGYGPAFRGL",
       "dna_sequence": "CACCCACTGCTCGGCGCGGCCGTCGACCTGGCCGACGACGAGGGCGTGCTGCTCACCGGCCGACTGTCGCTCGACAGCCACCCGTGGCTGGCCGACCACACGGTGGCGGGCGTGCCGTTGCTGCCGGGCGCGGCGTTCGTCGAGCTGTGCGCCCAGGCCGCGGAGGCCGCCGGCGCTGCCGGGGTGGCGGAGCTGACCCTGGAGACGCCCTGCGTGCTGCCCGAGCGCGGGGGCGTGGACGTGCAGGTCCAGGTCCGCGACGGCGGGCTGCGCGTGTACTCGCGCAGCGTCGGCGACGCCTGGGTACGCAACGCCTCCGGCGTCCTGCTTCCCACCGAGCCGCCCGCGCCGGCCGGTTGGGGCGCCTGGCCGCCACCCGGGGCGCAGGCCGTCGACGTCGAGGGCCTGTACCCGCAGCTGGCCGCGTCCGGCTACGGGTACGGCCCGGCCTTCCGGGGGCTG",
       "abbreviation": "DH",
       "html_class": "jsdomain-mod-dh"
      },
      {
       "type": "PKS_ER",
       "start": 2938,
       "end": 3228,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "TVDELRLTEVTEAPLPAGHVRVAVRACGLNFRDVLATLGVVPRDAPLGAEGAGVVVEVGVGVTGFAPGDRVYGFLQGAIGPRAVVDARLLAHLPAGWSFAQAATAPAVCTTAYYALVTLADLRPGERVLIHSAAGGVGLAAGHLARHLGAEVFGTASPAKWAALDLDEAHLASSRNTDFADRFGPVDVVLNSLTGEFIDASLRLLGPGGRFVEMGVADLRSSEQMPTGVDYHAFELLDLAPARVGELFAEVVRLIDQGVFPPLPVTAWDVRRAPEALRYFSQARQIGKIA",
       "dna_sequence": "ACTGTGGACGAGCTGCGCCTGACGGAGGTGACCGAAGCGCCGCTGCCGGCCGGGCACGTCCGGGTCGCGGTACGCGCCTGCGGGCTGAACTTCCGCGACGTGCTGGCCACCCTGGGCGTCGTACCCCGCGACGCCCCGCTGGGCGCGGAGGGTGCGGGCGTGGTGGTCGAGGTCGGCGTCGGTGTCACCGGCTTCGCCCCCGGTGACCGGGTGTACGGCTTCCTCCAGGGCGCCATCGGCCCGCGCGCCGTCGTGGACGCGCGGCTGCTCGCCCACCTGCCCGCCGGATGGTCCTTCGCGCAGGCGGCCACAGCGCCGGCGGTCTGCACCACCGCCTACTACGCGCTGGTCACCCTGGCGGACCTGCGCCCCGGGGAGCGGGTGCTGATCCACTCCGCCGCCGGCGGGGTCGGTCTGGCCGCCGGGCACCTCGCCCGGCACCTGGGCGCCGAGGTGTTCGGCACGGCGAGCCCGGCCAAGTGGGCGGCGCTGGACCTGGACGAGGCGCACCTGGCGTCGTCGCGGAACACCGACTTCGCCGACCGGTTCGGCCCGGTCGACGTGGTGCTCAACTCGCTGACCGGGGAGTTCATCGACGCGTCCCTGCGCCTGCTGGGTCCGGGCGGTCGGTTCGTGGAGATGGGTGTGGCGGACCTGCGGTCGTCCGAGCAGATGCCCACCGGCGTCGACTACCACGCGTTCGAGCTGCTCGACCTGGCCCCCGCGCGGGTGGGCGAGCTGTTCGCCGAGGTGGTCCGGCTGATCGACCAGGGGGTCTTTCCGCCGCTGCCGGTCACCGCCTGGGACGTCCGGCGGGCGCCGGAGGCGCTGCGCTACTTCAGCCAGGCCCGGCAGATCGGCAAGATCGCC",
       "abbreviation": "ER",
       "html_class": "jsdomain-mod-er"
      },
      {
       "type": "PKS_KR",
       "start": 3238,
       "end": 3417,
       "predictions": [
        [
         "KR activity",
         "active"
        ],
        [
         "KR stereochemistry",
         "B1"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "GTVLVTGGTGSLGGLVARHLARAHGVRHLLLVSRSGPAAPGATELVGELTSLDVRVDVVAADLADRAAVAGVLAAVPPEHPLTAVVHTAGVLDDGVLESLTPQKIARVLAPKVDAAWHLHELTRDLDLSAFLLFSSASGLLGGAGQANYAAANAFLDALATARRRAGLPAVSLAWGMWA",
       "dna_sequence": "GGCACGGTCCTGGTCACCGGCGGCACGGGCAGCCTCGGCGGCCTCGTCGCCCGGCACCTGGCGCGCGCCCACGGGGTACGTCACCTGCTGCTGGTCAGCCGGTCCGGTCCGGCCGCGCCCGGCGCGACGGAGCTGGTCGGTGAGTTGACCTCCCTGGACGTACGGGTGGACGTGGTGGCGGCCGACCTGGCCGACCGGGCGGCGGTCGCCGGGGTGTTGGCGGCGGTGCCGCCGGAGCACCCGCTCACCGCCGTCGTGCACACTGCCGGTGTCCTGGACGACGGCGTCCTGGAGTCGTTGACCCCGCAGAAGATCGCCCGGGTGCTCGCACCGAAGGTAGACGCCGCGTGGCACCTGCACGAGCTGACCCGGGACCTGGACCTGTCGGCGTTCCTGCTGTTCTCCTCGGCGTCGGGTCTGCTGGGCGGTGCGGGGCAGGCCAACTACGCGGCGGCCAATGCGTTCCTGGACGCGCTGGCCACGGCGCGGCGCCGCGCCGGCCTGCCCGCCGTGTCGCTGGCCTGGGGCATGTGGGCG",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      },
      {
       "type": "ACP",
       "start": 3522,
       "end": 3594,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "DLVRTQVAAVLGHTDTDAVVVDRAFKDSGFDSLTAVELRNRVSRATGLRLPPTVVFDRPTPAELAAHLLDQL",
       "dna_sequence": "GACCTGGTCCGTACACAGGTCGCGGCGGTCCTGGGCCACACCGACACCGACGCCGTGGTGGTGGACCGGGCGTTCAAGGACAGCGGTTTCGACTCGTTGACGGCGGTGGAGCTGCGCAACCGGGTGTCCCGCGCCACCGGGCTGCGGCTGCCACCCACCGTGGTGTTCGACCGCCCCACGCCGGCGGAGTTGGCCGCGCACCTTCTCGACCAGCTC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 45,
       "end": 1623,
       "complete": true,
       "iterative": false,
       "monomer": "Me-ccmal",
       "multi_cds": null,
       "match_id": null
      },
      {
       "start": 1642,
       "end": 3594,
       "complete": true,
       "iterative": false,
       "monomer": "Me-redmal",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "abyB3",
     "sequence": "MSETREEKLVEYLKWVTGELQETKAQLARARAEREPIAIVSAACRLPGDVHSPEDLWRVVVDGVDAIGDVPTDRGWAVHEVYADAPAHRPLGGFLSDAAGFDAAFFGIGPHEATAMDPQHRLLLESSWEAVERAGIDPTTLRGSATGVYAGLVSQNYAAYGTPPELNGHLMTGTATSVASGRIAYLLGLRGPAVTLDTACSSSLVALHLAAQALRRGECDLALAGGATVMATPALLAEFVTQGGLSPDARCKAFAAAADGTGFAEGVGVLVLERLADARRHHRRVLAVLRGSAVNQDGASNGLTAPSGPAQEEVIRAALADAGLRPSDVDHVEAHGTGTRLGDPIEAAALLATYGQDRAEPLWLGSVKSNIGHTQTAAGVAGVIKVIEALRHERLPRTLHVDEPTPHVDWAAGKVRLLTEEQPWPRGKRRRVAGVSSFGISGTNAHVLIEEGDPEPPPTPPTPSAHPVAWLLGAKTDSALRAQAARLRQRFAVASHDPLDVAVALATTRTAFDRRAAVVAADHDGLLRGLDALAAGETTPGRAVRGPTAFLFSGQGSQRVGMGTELRRVFPAFRDAWREVADEVDRHLDQPLDRVLADEDLLLRTEYAQPALFTLEVALVRLLGGWGLRPDLLLGHSLGELVAAHVAGVLDLPDAVALVAARGAAMQAAPAEGAMVAIRAAADEVRASLAGREHEVSVAAVNGPRSTVVSGDAGAVQEVAAHWAATGHRTSRLRVSHAFHSPHLDGVLDGFRAVAAGVRHHPPSIPVVSNLTGTVVEAFTAEHWVRHVRQEVRFAAGVSALTSAGVRRFVEVGPDAVLAALAGENAPGTPVVATLRRDESEALTVVRALAASHVTGARVDWRAFHDERTAAVPLPTYPFEHRRYWVSPPTGPAPTAPPPVADEPPRESTPHEERLLDLVRTHAAAVLGHDTPESVGPDDNFVEIGLSSFTALEVRNRLCEGTGLELSPLALFEHPTPAALAEHLRAVRAART",
     "domains": [
      {
       "type": "PKS_Docking_Nterm",
       "start": 5,
       "end": 32,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EEKLVEYLKWVTGELQETKAQLARARA",
       "dna_sequence": "GAGGAGAAGCTCGTCGAGTACCTGAAGTGGGTCACCGGTGAGCTGCAGGAGACCAAGGCCCAACTCGCCAGGGCGAGGGCG",
       "abbreviation": "",
       "html_class": "jsdomain-docking"
      },
      {
       "type": "PKS_KS(Modular-KS)",
       "start": 36,
       "end": 451,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IAIVSAACRLPGDVHSPEDLWRVVVDGVDAIGDVPTDRGWAVHEVYADAPAHRPLGGFLSDAAGFDAAFFGIGPHEATAMDPQHRLLLESSWEAVERAGIDPTTLRGSATGVYAGLVSQNYAAYGTPPELNGHLMTGTATSVASGRIAYLLGLRGPAVTLDTACSSSLVALHLAAQALRRGECDLALAGGATVMATPALLAEFVTQGGLSPDARCKAFAAAADGTGFAEGVGVLVLERLADARRHHRRVLAVLRGSAVNQDGASNGLTAPSGPAQEEVIRAALADAGLRPSDVDHVEAHGTGTRLGDPIEAAALLATYGQDRAEPLWLGSVKSNIGHTQTAAGVAGVIKVIEALRHERLPRTLHVDEPTPHVDWAAGKVRLLTEEQPWPRGKRRRVAGVSSFGISGTNAHVLIEE",
       "dna_sequence": "ATCGCGATCGTCTCGGCCGCCTGCCGGCTGCCCGGCGACGTCCACTCCCCCGAGGACCTGTGGCGCGTCGTGGTCGACGGTGTCGACGCCATCGGCGACGTCCCCACCGACCGGGGTTGGGCGGTGCATGAGGTGTACGCCGACGCGCCCGCGCACCGCCCGCTGGGCGGGTTCCTGTCCGACGCGGCCGGCTTCGACGCCGCGTTCTTCGGTATCGGCCCGCACGAGGCCACCGCCATGGACCCGCAGCACCGGCTGCTGCTGGAGTCGTCGTGGGAGGCGGTGGAGCGCGCCGGCATCGACCCGACCACCCTGCGCGGCAGCGCCACCGGGGTGTACGCGGGCCTGGTGTCGCAGAACTACGCCGCGTACGGCACCCCACCGGAGCTCAACGGCCACCTCATGACCGGCACGGCCACCAGCGTGGCGTCCGGCCGGATCGCCTATCTGCTGGGGCTGCGCGGCCCGGCGGTCACCCTGGACACCGCCTGCTCGTCGTCGCTGGTGGCCCTGCACCTGGCGGCGCAGGCGCTGCGCCGGGGCGAGTGCGATCTCGCGCTGGCCGGCGGGGCCACGGTCATGGCCACCCCGGCGTTGCTGGCGGAGTTCGTCACCCAGGGCGGGCTCTCGCCCGACGCCCGGTGCAAGGCGTTCGCGGCGGCGGCCGACGGAACGGGTTTCGCCGAGGGGGTCGGGGTGCTCGTGCTGGAACGCCTGGCCGACGCCCGGCGCCACCACCGGCGCGTGCTCGCGGTGCTGCGCGGCTCGGCGGTGAACCAGGACGGCGCGTCCAACGGGCTGACCGCGCCGAGCGGCCCCGCGCAGGAGGAGGTGATCCGCGCCGCGCTGGCCGACGCGGGCCTGCGACCGTCCGACGTGGACCATGTGGAGGCGCACGGCACCGGCACCCGGTTGGGCGACCCCATCGAGGCGGCGGCCCTGCTCGCCACCTACGGTCAGGACCGCGCCGAGCCGCTGTGGCTGGGTTCGGTGAAGTCCAACATCGGGCACACCCAGACCGCCGCCGGTGTGGCCGGGGTGATCAAGGTGATCGAAGCCCTGCGCCACGAGCGCCTGCCGCGCACCCTGCACGTCGACGAGCCCACTCCGCACGTCGACTGGGCGGCGGGGAAGGTACGGCTGCTCACCGAGGAGCAGCCGTGGCCGCGCGGGAAACGCCGCCGGGTGGCGGGGGTGTCGTCGTTCGGCATCAGCGGCACCAACGCCCACGTGCTCATCGAGGAG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      },
      {
       "type": "PKS_AT",
       "start": 550,
       "end": 838,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "Malonyl-CoA"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LFSGQGSQRVGMGTELRRVFPAFRDAWREVADEVDRHLDQPLDRVLADEDLLLRTEYAQPALFTLEVALVRLLGGWGLRPDLLLGHSLGELVAAHVAGVLDLPDAVALVAARGAAMQAAPAEGAMVAIRAAADEVRASLAGREHEVSVAAVNGPRSTVVSGDAGAVQEVAAHWAATGHRTSRLRVSHAFHSPHLDGVLDGFRAVAAGVRHHPPSIPVVSNLTGTVVEAFTAEHWVRHVRQEVRFAAGVSALTSAGVRRFVEVGPDAVLAALAGENAPGTPVVATLRRD",
       "dna_sequence": "CTCTTCTCCGGGCAGGGCAGCCAGCGCGTCGGCATGGGTACCGAGCTGCGGCGGGTCTTCCCTGCCTTCCGCGACGCCTGGCGGGAGGTCGCCGACGAGGTCGACCGGCACCTGGACCAGCCCCTGGACCGCGTGCTGGCCGACGAGGACCTGCTGCTGCGCACCGAGTACGCCCAGCCCGCGTTGTTCACCCTGGAGGTGGCCCTGGTCCGCTTGCTGGGCGGCTGGGGTCTGCGGCCGGACCTGCTGCTCGGTCACTCGCTCGGCGAACTGGTCGCGGCGCACGTCGCGGGGGTCCTCGACCTGCCCGACGCCGTCGCGCTGGTCGCGGCGCGGGGTGCGGCCATGCAGGCGGCCCCGGCCGAGGGCGCCATGGTTGCGATCCGGGCCGCCGCCGACGAGGTACGGGCCAGCCTCGCCGGCCGCGAGCACGAGGTGTCCGTCGCGGCGGTGAACGGCCCCCGCTCGACAGTCGTCTCCGGCGATGCCGGTGCGGTGCAGGAGGTCGCGGCCCACTGGGCGGCCACCGGGCACCGGACGTCGCGATTGCGGGTCAGCCACGCCTTCCACAGCCCGCACCTGGACGGGGTGCTGGACGGGTTCCGCGCGGTCGCCGCCGGCGTACGCCACCACCCGCCGAGCATCCCGGTCGTGTCGAACCTGACCGGCACGGTCGTCGAGGCGTTCACCGCCGAGCACTGGGTGCGGCACGTGCGCCAGGAGGTCCGCTTCGCCGCCGGCGTGTCCGCGCTCACCTCGGCGGGCGTACGCCGTTTCGTGGAGGTCGGCCCGGACGCGGTGCTGGCTGCCCTGGCCGGCGAGAACGCCCCTGGGACACCCGTCGTGGCGACCCTGCGCCGCGAC",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "ACP",
       "start": 915,
       "end": 986,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LDLVRTHAAAVLGHDTPESVGPDDNFVEIGLSSFTALEVRNRLCEGTGLELSPLALFEHPTPAALAEHLRA",
       "dna_sequence": "CTCGACCTGGTCCGCACGCACGCGGCGGCGGTGCTGGGCCACGACACGCCGGAATCGGTGGGCCCGGACGACAACTTCGTGGAGATCGGGCTGTCGTCGTTCACCGCGCTGGAGGTGCGCAACCGGCTCTGCGAGGGCACCGGCCTGGAACTGTCGCCGCTGGCGCTGTTCGAACACCCCACCCCTGCCGCGCTGGCGGAGCACCTGCGGGCC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 36,
       "end": 986,
       "complete": true,
       "iterative": false,
       "monomer": "mal",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "abyT",
     "sequence": "MGRTARAGTQRSTGYLDRTPDPADRVRLFCFHHAGAAASTFAGWAEALQPRVAVYPVQLPGRENRVREAPITDFGRLLDAVVDAVEPSLERPYALYGHSMGAALAAAVARRQVERGRPPVALFVGGYPDPRCGPPLAVSALSDDEVADLLVRIGGMSEVVRRYPAWVRTAVRLLRGDLAALHSQPPTGPDPVPVPVRAYVGDSDPLVGRADAVGWAAYTSSSFRLRVLPGGHLFHLRSGDRLRADIAACLGELTSLPGGRPDGGASVDVEDRLAGHAAAEQRLDRVVDALPGVPPADR",
     "domains": [
      {
       "type": "Thioesterase",
       "start": 26,
       "end": 240,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "RLFCFHHAGAAASTFAGWAEALQPRVAVYPVQLPGRENRVREAPITDFGRLLDAVVDAVEPSLERPYALYGHSMGAALAAAVARRQVERGRPPVALFVGGYPDPRCGPPLAVSALSDDEVADLLVRIGGMSEVVRRYPAWVRTAVRLLRGDLAALHSQPPTGPDPVPVPVRAYVGDSDPLVGRADAVGWAAYTSSSFRLRVLPGGHLFHLRSGD",
       "dna_sequence": "CGGCTGTTCTGTTTCCACCACGCCGGCGCCGCAGCGTCCACCTTCGCCGGCTGGGCGGAGGCGTTGCAGCCACGGGTCGCGGTCTACCCGGTGCAGCTGCCCGGCCGGGAGAACCGCGTGCGGGAGGCGCCCATCACCGATTTCGGCCGTCTGCTCGACGCCGTCGTGGACGCTGTCGAGCCGTCACTGGAACGTCCGTACGCTCTCTATGGACACAGCATGGGTGCGGCCCTGGCCGCCGCGGTGGCCCGACGGCAGGTCGAGCGGGGACGACCGCCGGTGGCGTTGTTCGTCGGCGGCTACCCGGACCCGCGCTGCGGGCCACCGCTCGCGGTGTCGGCGCTGTCCGACGACGAGGTCGCCGACCTGCTGGTGCGCATCGGGGGCATGTCCGAGGTGGTACGCCGGTATCCCGCGTGGGTGCGGACGGCGGTCCGGCTGCTGCGCGGCGACCTCGCGGCCCTGCACTCCCAGCCTCCGACCGGGCCCGATCCGGTGCCGGTGCCGGTGCGCGCCTACGTCGGCGACTCCGATCCGCTGGTGGGGCGCGCCGACGCGGTCGGGTGGGCGGCGTACACCTCGTCGTCGTTCCGGCTGCGGGTGCTGCCCGGCGGTCACCTGTTCCACCTCCGGTCGGGCGAT",
       "abbreviation": "TE",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": []
    },
    {
     "id": "orfU",
     "sequence": "MQALIAAPDTAEGHRLAEVPEPVPTPGQLLVEVRQSSVNFGEARFRAGMPAGTVLGYDAAGYVVRAAEDGSGPAVGDRVVAFGPGTWAERAVFDVDSVARIPDGLDLAATAALPMVGLTALRTLRGAGPLLGRRVLVTGASGGVGRLAVQLARLGGATVVASVGSPARGEGLRDLGAAEVVVGLDDVREPVDVVVETVGGDHLTRAWSLLKPGGICQSIGWASGAAAVFAPNSTFALGEPRRLQSFGDTSRPGADLATLLAFVAAGDISLPVGWRDSWKRVDDAIEALLGRRVAGKAVLDID",
     "domains": [
      {
       "type": "PKS_ER",
       "start": 16,
       "end": 238,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "AEVPEPVPTPGQLLVEVRQSSVNFGEARFRAGMPAGTVLGYDAAGYVVRAAEDGSGPAVGDRVVAFGPGTWAERAVFDVDSVARIPDGLDLAATAALPMVGLTALRTLRGAGPLLGRRVLVTGASGGVGRLAVQLARLGGATVVASVGSPARGEGLRDLGAAEVVVGLDDVREPVDVVVETVGGDHLTRAWSLLKPGGICQSIGWASGAAAVFAPNSTFALG",
       "dna_sequence": "GCCGAGGTGCCCGAGCCGGTCCCGACGCCCGGCCAGTTGCTCGTCGAGGTGAGACAGTCCTCGGTGAACTTCGGCGAGGCCCGCTTCCGTGCCGGGATGCCCGCCGGCACGGTGCTCGGTTACGACGCCGCGGGTTACGTCGTGCGGGCCGCCGAGGACGGCAGCGGTCCGGCCGTCGGCGACCGGGTGGTCGCCTTCGGTCCGGGAACGTGGGCCGAACGTGCCGTCTTCGACGTCGACAGCGTGGCGCGGATCCCCGACGGGCTCGATCTCGCCGCCACGGCGGCCCTGCCGATGGTGGGCCTCACCGCCCTGCGGACCCTGCGAGGCGCCGGCCCACTGCTGGGCCGTCGGGTGCTGGTCACCGGCGCGTCCGGAGGCGTCGGACGGCTGGCGGTTCAACTCGCCCGCCTCGGCGGAGCCACGGTGGTGGCGTCGGTCGGCTCGCCGGCGCGGGGGGAGGGGCTGCGCGACCTGGGCGCAGCCGAGGTGGTGGTCGGGCTGGACGACGTCCGCGAGCCGGTCGACGTGGTGGTGGAGACAGTCGGTGGTGACCACCTCACCCGCGCGTGGTCGCTGCTCAAGCCGGGCGGGATCTGCCAGAGCATCGGCTGGGCGTCGGGTGCGGCGGCCGTCTTCGCGCCCAACTCGACCTTCGCATTGGGC",
       "abbreviation": "ER",
       "html_class": "jsdomain-mod-er"
      }
     ],
     "modules": []
    }
   ]
  }
 }
};
var resultsData = {
 "r1c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000001: 0-59320": {
       "start": 0,
       "end": 59320,
       "links": [
        {
         "query": "orfU",
         "subject": "orfU",
         "query_loc": 58181,
         "subject_loc": 58181
        },
        {
         "query": "orfS",
         "subject": "orfS",
         "query_loc": 59023,
         "subject_loc": 59023
        },
        {
         "query": "orfP",
         "subject": "orfP",
         "query_loc": 541,
         "subject_loc": 541
        },
        {
         "query": "abyZ",
         "subject": "abyZ",
         "query_loc": 56518,
         "subject_loc": 56518
        },
        {
         "query": "abyX",
         "subject": "abyX",
         "query_loc": 3240,
         "subject_loc": 3240
        },
        {
         "query": "abyW",
         "subject": "abyW",
         "query_loc": 56103,
         "subject_loc": 56103
        },
        {
         "query": "abyV",
         "subject": "abyV",
         "query_loc": 55421,
         "subject_loc": 55421
        },
        {
         "query": "abyT",
         "subject": "abyT",
         "query_loc": 57380,
         "subject_loc": 57380
        },
        {
         "query": "abyR",
         "subject": "abyR",
         "query_loc": 2259,
         "subject_loc": 2259
        },
        {
         "query": "abyK",
         "subject": "abyK",
         "query_loc": 9104,
         "subject_loc": 9104
        },
        {
         "query": "abyI",
         "subject": "abyI",
         "query_loc": 7330,
         "subject_loc": 7330
        },
        {
         "query": "abyH",
         "subject": "abyH",
         "query_loc": 5261,
         "subject_loc": 5261
        },
        {
         "query": "abyF4",
         "subject": "abyF4",
         "query_loc": 54021,
         "subject_loc": 54021
        },
        {
         "query": "abyF3",
         "subject": "abyF3",
         "query_loc": 52796,
         "subject_loc": 52796
        },
        {
         "query": "abyF2",
         "subject": "abyF2",
         "query_loc": 51906,
         "subject_loc": 51906
        },
        {
         "query": "abyF1",
         "subject": "abyF1",
         "query_loc": 50633,
         "subject_loc": 50633
        },
        {
         "query": "abyE",
         "subject": "abyE",
         "query_loc": 49234,
         "subject_loc": 49234
        },
        {
         "query": "abyD",
         "subject": "abyD",
         "query_loc": 47946,
         "subject_loc": 47946
        },
        {
         "query": "abyC",
         "subject": "abyC",
         "query_loc": 46802,
         "subject_loc": 46802
        },
        {
         "query": "abyB3",
         "subject": "abyB3",
         "query_loc": 44898,
         "subject_loc": 44898
        },
        {
         "query": "abyB2",
         "subject": "abyB2",
         "query_loc": 37944,
         "subject_loc": 37944
        },
        {
         "query": "abyB1",
         "subject": "abyB1",
         "query_loc": 23726,
         "subject_loc": 23726
        },
        {
         "query": "abyA5",
         "subject": "abyA5",
         "query_loc": 14523,
         "subject_loc": 14523
        },
        {
         "query": "abyA4",
         "subject": "abyA4",
         "query_loc": 13615,
         "subject_loc": 13615
        },
        {
         "query": "abyA3",
         "subject": "abyA3",
         "query_loc": 13122,
         "subject_loc": 13122
        },
        {
         "query": "abyA2",
         "subject": "abyA2",
         "query_loc": 12073,
         "subject_loc": 12073
        },
        {
         "query": "abyA1",
         "subject": "abyA1",
         "query_loc": 10630,
         "subject_loc": 10630
        },
        {
         "query": "AEK75491.1",
         "subject": "AEK75491.1",
         "query_loc": 1520,
         "subject_loc": 1520
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AEK75491.1",
         "start": 1207,
         "end": 1834,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "AEK75491.1"
         }
        },
        {
         "locus_tag": "abyA1",
         "start": 10117,
         "end": 11143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyA1"
         }
        },
        {
         "locus_tag": "abyA2",
         "start": 11139,
         "end": 13008,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyA2"
         }
        },
        {
         "locus_tag": "abyA3",
         "start": 13004,
         "end": 13241,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyA3"
         }
        },
        {
         "locus_tag": "abyA4",
         "start": 13237,
         "end": 13993,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyA4"
         }
        },
        {
         "locus_tag": "abyA5",
         "start": 13989,
         "end": 15057,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyA5"
         }
        },
        {
         "locus_tag": "abyB1",
         "start": 15053,
         "end": 32399,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB1"
         }
        },
        {
         "locus_tag": "abyB2",
         "start": 32475,
         "end": 43413,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB2"
         }
        },
        {
         "locus_tag": "abyB3",
         "start": 43409,
         "end": 46388,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "abyC",
         "start": 46456,
         "end": 47149,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "abyC"
         }
        },
        {
         "locus_tag": "abyD",
         "start": 47232,
         "end": 48660,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyD"
         }
        },
        {
         "locus_tag": "abyE",
         "start": 48730,
         "end": 49738,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyE"
         }
        },
        {
         "locus_tag": "abyF1",
         "start": 49825,
         "end": 51442,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF1"
         }
        },
        {
         "locus_tag": "abyF2",
         "start": 51438,
         "end": 52374,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF2"
         }
        },
        {
         "locus_tag": "abyF3",
         "start": 52370,
         "end": 53222,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF3"
         }
        },
        {
         "locus_tag": "abyF4",
         "start": 53211,
         "end": 54831,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF4"
         }
        },
        {
         "locus_tag": "abyH",
         "start": 3926,
         "end": 6596,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "abyH"
         }
        },
        {
         "locus_tag": "abyI",
         "start": 6951,
         "end": 7710,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "abyI"
         }
        },
        {
         "locus_tag": "abyK",
         "start": 8174,
         "end": 10034,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "abyK"
         }
        },
        {
         "locus_tag": "abyR",
         "start": 1886,
         "end": 2633,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "abyR"
         }
        },
        {
         "locus_tag": "abyT",
         "start": 56932,
         "end": 57829,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyT"
         }
        },
        {
         "locus_tag": "abyV",
         "start": 54827,
         "end": 56015,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyV"
         }
        },
        {
         "locus_tag": "abyW",
         "start": 55977,
         "end": 56229,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyW"
         }
        },
        {
         "locus_tag": "abyX",
         "start": 2645,
         "end": 3836,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyX"
         }
        },
        {
         "locus_tag": "abyZ",
         "start": 56229,
         "end": 56808,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "abyZ"
         }
        },
        {
         "locus_tag": "orfP",
         "start": 0,
         "end": 1083,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "orfP"
         }
        },
        {
         "locus_tag": "orfS",
         "start": 58726,
         "end": 59320,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "orfS"
         }
        },
        {
         "locus_tag": "orfU",
         "start": 57727,
         "end": 58636,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "orfU"
         }
        }
       ]
      },
      "BGC0000041: 0-14402": {
       "start": 0,
       "end": 14402,
       "links": [
        {
         "query": "abyB3",
         "subject": "cfa7",
         "query_loc": 44898,
         "subject_loc": 11301
        },
        {
         "query": "abyB2",
         "subject": "cfa6",
         "query_loc": 37944,
         "subject_loc": 4098
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cfa6",
         "start": 0,
         "end": 8196,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB2"
         }
        },
        {
         "locus_tag": "cfa7",
         "start": 8201,
         "end": 14402,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        }
       ]
      },
      "BGC0002631: 500-2591": {
       "start": 500,
       "end": 2591,
       "links": [
        {
         "query": "abyX",
         "subject": "bytO",
         "query_loc": 3240,
         "subject_loc": 1199
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "bytA",
         "start": 500,
         "end": 518,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "bytO",
         "start": 619,
         "end": 1780,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyX"
         }
        },
        {
         "locus_tag": "bytZ",
         "start": 1796,
         "end": 2591,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000160: 0-27093": {
       "start": 0,
       "end": 27093,
       "links": [
        {
         "query": "abyB3",
         "subject": "ATEG_06275",
         "query_loc": 44898,
         "subject_loc": 11211
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ATEG_06272",
         "start": 0,
         "end": 1405,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06273",
         "start": 2172,
         "end": 4233,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06274",
         "start": 5201,
         "end": 7478,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06275",
         "start": 8474,
         "end": 13948,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "ATEG_06276",
         "start": 15135,
         "end": 16477,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06277",
         "start": 17580,
         "end": 19101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06278",
         "start": 19605,
         "end": 21638,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06279",
         "start": 23759,
         "end": 25615,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06280",
         "start": 26604,
         "end": 27093,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000677: 120-4940": {
       "start": 120,
       "end": 4940,
       "links": [
        {
         "query": "abyV",
         "subject": "BAI44339.1",
         "query_loc": 55421,
         "subject_loc": 2806
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAI44337.1",
         "start": 120,
         "end": 1200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BAI44338.1",
         "start": 1196,
         "end": 2120,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAI44339.1",
         "start": 2116,
         "end": 3496,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyV"
         }
        },
        {
         "locus_tag": "BAI44340.1",
         "start": 3560,
         "end": 4940,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002229: 510-22108": {
       "start": 510,
       "end": 22108,
       "links": [
        {
         "query": "abyB3",
         "subject": "ASPACDRAFT_1904397",
         "query_loc": 44898,
         "subject_loc": 3135
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ASPACDRAFT_1904397",
         "start": 510,
         "end": 5760,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "ASPACDRAFT_1904400",
         "start": 6710,
         "end": 7887,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_1904405",
         "start": 17963,
         "end": 19812,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_32595",
         "start": 8743,
         "end": 10567,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_45672",
         "start": 10940,
         "end": 11990,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_45673",
         "start": 12647,
         "end": 14493,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_80410",
         "start": 20542,
         "end": 22108,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000844: 2-13901": {
       "start": 2,
       "end": 13901,
       "links": [
        {
         "query": "abyF1",
         "subject": "AAP13504.1",
         "query_loc": 50633,
         "subject_loc": 4665
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAP13500.1",
         "start": 2,
         "end": 128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13501.1",
         "start": 361,
         "end": 1738,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13502.1",
         "start": 1734,
         "end": 2757,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAP13503.1",
         "start": 2708,
         "end": 3728,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13504.1",
         "start": 3821,
         "end": 5510,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "abyF1"
         }
        },
        {
         "locus_tag": "AAP13505.1",
         "start": 5506,
         "end": 6712,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13506.1",
         "start": 6708,
         "end": 8022,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAP13507.1",
         "start": 8294,
         "end": 9779,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13508.1",
         "start": 10385,
         "end": 12539,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAR16180.1",
         "start": 12734,
         "end": 13901,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001273: 0-5301": {
       "start": 0,
       "end": 5301,
       "links": [
        {
         "query": "abyB3",
         "subject": "AAS98200.1",
         "query_loc": 44898,
         "subject_loc": 2650
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAS98200.1",
         "start": 0,
         "end": 5301,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        }
       ]
      },
      "BGC0001276: 1101-6575": {
       "start": 1101,
       "end": 6575,
       "links": [
        {
         "query": "abyB3",
         "subject": "atX",
         "query_loc": 44898,
         "subject_loc": 3838
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "atX",
         "start": 1101,
         "end": 6575,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        }
       ]
      },
      "BGC0000067: 14949-58348": {
       "start": 14949,
       "end": 58348,
       "links": [
        {
         "query": "abyB3",
         "subject": "ABB86410.1",
         "query_loc": 44898,
         "subject_loc": 51732
        },
        {
         "query": "abyB2",
         "subject": "ABB86409.1",
         "query_loc": 37944,
         "subject_loc": 40723
        },
        {
         "query": "abyB1",
         "subject": "ABB86408.1",
         "query_loc": 23726,
         "subject_loc": 25233
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABB86408.1",
         "start": 14949,
         "end": 35517,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB1"
         }
        },
        {
         "locus_tag": "ABB86409.1",
         "start": 35574,
         "end": 45873,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB2"
         }
        },
        {
         "locus_tag": "ABB86410.1",
         "start": 45899,
         "end": 57566,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "ABB86411.1",
         "start": 57574,
         "end": 58348,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000001: 0-59320": {
       "start": 0,
       "end": 59320,
       "links": [
        {
         "query": "orfU",
         "subject": "orfU",
         "query_loc": 58181,
         "subject_loc": 58181
        },
        {
         "query": "orfS",
         "subject": "orfS",
         "query_loc": 59023,
         "subject_loc": 59023
        },
        {
         "query": "orfP",
         "subject": "orfP",
         "query_loc": 541,
         "subject_loc": 541
        },
        {
         "query": "abyZ",
         "subject": "abyZ",
         "query_loc": 56518,
         "subject_loc": 56518
        },
        {
         "query": "abyX",
         "subject": "abyX",
         "query_loc": 3240,
         "subject_loc": 3240
        },
        {
         "query": "abyW",
         "subject": "abyW",
         "query_loc": 56103,
         "subject_loc": 56103
        },
        {
         "query": "abyV",
         "subject": "abyV",
         "query_loc": 55421,
         "subject_loc": 55421
        },
        {
         "query": "abyT",
         "subject": "abyT",
         "query_loc": 57380,
         "subject_loc": 57380
        },
        {
         "query": "abyR",
         "subject": "abyR",
         "query_loc": 2259,
         "subject_loc": 2259
        },
        {
         "query": "abyK",
         "subject": "abyK",
         "query_loc": 9104,
         "subject_loc": 9104
        },
        {
         "query": "abyI",
         "subject": "abyI",
         "query_loc": 7330,
         "subject_loc": 7330
        },
        {
         "query": "abyH",
         "subject": "abyH",
         "query_loc": 5261,
         "subject_loc": 5261
        },
        {
         "query": "abyF4",
         "subject": "abyF4",
         "query_loc": 54021,
         "subject_loc": 54021
        },
        {
         "query": "abyF3",
         "subject": "abyF3",
         "query_loc": 52796,
         "subject_loc": 52796
        },
        {
         "query": "abyF2",
         "subject": "abyF2",
         "query_loc": 51906,
         "subject_loc": 51906
        },
        {
         "query": "abyF1",
         "subject": "abyF1",
         "query_loc": 50633,
         "subject_loc": 50633
        },
        {
         "query": "abyE",
         "subject": "abyE",
         "query_loc": 49234,
         "subject_loc": 49234
        },
        {
         "query": "abyD",
         "subject": "abyD",
         "query_loc": 47946,
         "subject_loc": 47946
        },
        {
         "query": "abyC",
         "subject": "abyC",
         "query_loc": 46802,
         "subject_loc": 46802
        },
        {
         "query": "abyB3",
         "subject": "abyB3",
         "query_loc": 44898,
         "subject_loc": 44898
        },
        {
         "query": "abyB2",
         "subject": "abyB2",
         "query_loc": 37944,
         "subject_loc": 37944
        },
        {
         "query": "abyB1",
         "subject": "abyB1",
         "query_loc": 23726,
         "subject_loc": 23726
        },
        {
         "query": "abyA5",
         "subject": "abyA5",
         "query_loc": 14523,
         "subject_loc": 14523
        },
        {
         "query": "abyA4",
         "subject": "abyA4",
         "query_loc": 13615,
         "subject_loc": 13615
        },
        {
         "query": "abyA3",
         "subject": "abyA3",
         "query_loc": 13122,
         "subject_loc": 13122
        },
        {
         "query": "abyA2",
         "subject": "abyA2",
         "query_loc": 12073,
         "subject_loc": 12073
        },
        {
         "query": "abyA1",
         "subject": "abyA1",
         "query_loc": 10630,
         "subject_loc": 10630
        },
        {
         "query": "AEK75491.1",
         "subject": "AEK75491.1",
         "query_loc": 1520,
         "subject_loc": 1520
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AEK75491.1",
         "start": 1207,
         "end": 1834,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "AEK75491.1"
         }
        },
        {
         "locus_tag": "abyA1",
         "start": 10117,
         "end": 11143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyA1"
         }
        },
        {
         "locus_tag": "abyA2",
         "start": 11139,
         "end": 13008,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyA2"
         }
        },
        {
         "locus_tag": "abyA3",
         "start": 13004,
         "end": 13241,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyA3"
         }
        },
        {
         "locus_tag": "abyA4",
         "start": 13237,
         "end": 13993,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyA4"
         }
        },
        {
         "locus_tag": "abyA5",
         "start": 13989,
         "end": 15057,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyA5"
         }
        },
        {
         "locus_tag": "abyB1",
         "start": 15053,
         "end": 32399,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB1"
         }
        },
        {
         "locus_tag": "abyB2",
         "start": 32475,
         "end": 43413,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB2"
         }
        },
        {
         "locus_tag": "abyB3",
         "start": 43409,
         "end": 46388,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "abyC",
         "start": 46456,
         "end": 47149,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "abyC"
         }
        },
        {
         "locus_tag": "abyD",
         "start": 47232,
         "end": 48660,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyD"
         }
        },
        {
         "locus_tag": "abyE",
         "start": 48730,
         "end": 49738,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyE"
         }
        },
        {
         "locus_tag": "abyF1",
         "start": 49825,
         "end": 51442,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF1"
         }
        },
        {
         "locus_tag": "abyF2",
         "start": 51438,
         "end": 52374,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF2"
         }
        },
        {
         "locus_tag": "abyF3",
         "start": 52370,
         "end": 53222,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF3"
         }
        },
        {
         "locus_tag": "abyF4",
         "start": 53211,
         "end": 54831,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "abyF4"
         }
        },
        {
         "locus_tag": "abyH",
         "start": 3926,
         "end": 6596,
         "strand": -1,
         "function": "regulatory",
         "linked": {
          "1": "abyH"
         }
        },
        {
         "locus_tag": "abyI",
         "start": 6951,
         "end": 7710,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "abyI"
         }
        },
        {
         "locus_tag": "abyK",
         "start": 8174,
         "end": 10034,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "abyK"
         }
        },
        {
         "locus_tag": "abyR",
         "start": 1886,
         "end": 2633,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "abyR"
         }
        },
        {
         "locus_tag": "abyT",
         "start": 56932,
         "end": 57829,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyT"
         }
        },
        {
         "locus_tag": "abyV",
         "start": 54827,
         "end": 56015,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyV"
         }
        },
        {
         "locus_tag": "abyW",
         "start": 55977,
         "end": 56229,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "abyW"
         }
        },
        {
         "locus_tag": "abyX",
         "start": 2645,
         "end": 3836,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyX"
         }
        },
        {
         "locus_tag": "abyZ",
         "start": 56229,
         "end": 56808,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "abyZ"
         }
        },
        {
         "locus_tag": "orfP",
         "start": 0,
         "end": 1083,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "orfP"
         }
        },
        {
         "locus_tag": "orfS",
         "start": 58726,
         "end": 59320,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "orfS"
         }
        },
        {
         "locus_tag": "orfU",
         "start": 57727,
         "end": 58636,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "orfU"
         }
        }
       ]
      },
      "BGC0000041: 0-14402": {
       "start": 0,
       "end": 14402,
       "links": [
        {
         "query": "abyB3",
         "subject": "cfa7",
         "query_loc": 44898,
         "subject_loc": 11301
        },
        {
         "query": "abyB2",
         "subject": "cfa6",
         "query_loc": 37944,
         "subject_loc": 4098
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cfa6",
         "start": 0,
         "end": 8196,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB2"
         }
        },
        {
         "locus_tag": "cfa7",
         "start": 8201,
         "end": 14402,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        }
       ]
      },
      "BGC0002631: 500-2591": {
       "start": 500,
       "end": 2591,
       "links": [
        {
         "query": "abyX",
         "subject": "bytO",
         "query_loc": 3240,
         "subject_loc": 1199
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "bytA",
         "start": 500,
         "end": 518,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "bytO",
         "start": 619,
         "end": 1780,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyX"
         }
        },
        {
         "locus_tag": "bytZ",
         "start": 1796,
         "end": 2591,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000160: 0-27093": {
       "start": 0,
       "end": 27093,
       "links": [
        {
         "query": "abyB3",
         "subject": "ATEG_06275",
         "query_loc": 44898,
         "subject_loc": 11211
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ATEG_06272",
         "start": 0,
         "end": 1405,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06273",
         "start": 2172,
         "end": 4233,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06274",
         "start": 5201,
         "end": 7478,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06275",
         "start": 8474,
         "end": 13948,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "ATEG_06276",
         "start": 15135,
         "end": 16477,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06277",
         "start": 17580,
         "end": 19101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06278",
         "start": 19605,
         "end": 21638,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06279",
         "start": 23759,
         "end": 25615,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_06280",
         "start": 26604,
         "end": 27093,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000677: 120-4940": {
       "start": 120,
       "end": 4940,
       "links": [
        {
         "query": "abyV",
         "subject": "BAI44339.1",
         "query_loc": 55421,
         "subject_loc": 2806
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAI44337.1",
         "start": 120,
         "end": 1200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BAI44338.1",
         "start": 1196,
         "end": 2120,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAI44339.1",
         "start": 2116,
         "end": 3496,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "abyV"
         }
        },
        {
         "locus_tag": "BAI44340.1",
         "start": 3560,
         "end": 4940,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002229: 510-22108": {
       "start": 510,
       "end": 22108,
       "links": [
        {
         "query": "abyB3",
         "subject": "ASPACDRAFT_1904397",
         "query_loc": 44898,
         "subject_loc": 3135
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ASPACDRAFT_1904397",
         "start": 510,
         "end": 5760,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "ASPACDRAFT_1904400",
         "start": 6710,
         "end": 7887,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_1904405",
         "start": 17963,
         "end": 19812,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_32595",
         "start": 8743,
         "end": 10567,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_45672",
         "start": 10940,
         "end": 11990,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_45673",
         "start": 12647,
         "end": 14493,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ASPACDRAFT_80410",
         "start": 20542,
         "end": 22108,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000844: 2-13901": {
       "start": 2,
       "end": 13901,
       "links": [
        {
         "query": "abyF1",
         "subject": "AAP13504.1",
         "query_loc": 50633,
         "subject_loc": 4665
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAP13500.1",
         "start": 2,
         "end": 128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13501.1",
         "start": 361,
         "end": 1738,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13502.1",
         "start": 1734,
         "end": 2757,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAP13503.1",
         "start": 2708,
         "end": 3728,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13504.1",
         "start": 3821,
         "end": 5510,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "abyF1"
         }
        },
        {
         "locus_tag": "AAP13505.1",
         "start": 5506,
         "end": 6712,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13506.1",
         "start": 6708,
         "end": 8022,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAP13507.1",
         "start": 8294,
         "end": 9779,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAP13508.1",
         "start": 10385,
         "end": 12539,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAR16180.1",
         "start": 12734,
         "end": 13901,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001273: 0-5301": {
       "start": 0,
       "end": 5301,
       "links": [
        {
         "query": "abyB3",
         "subject": "AAS98200.1",
         "query_loc": 44898,
         "subject_loc": 2650
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAS98200.1",
         "start": 0,
         "end": 5301,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        }
       ]
      },
      "BGC0001276: 1101-6575": {
       "start": 1101,
       "end": 6575,
       "links": [
        {
         "query": "abyB3",
         "subject": "atX",
         "query_loc": 44898,
         "subject_loc": 3838
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "atX",
         "start": 1101,
         "end": 6575,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        }
       ]
      },
      "BGC0000067: 14949-58348": {
       "start": 14949,
       "end": 58348,
       "links": [
        {
         "query": "abyB3",
         "subject": "ABB86410.1",
         "query_loc": 44898,
         "subject_loc": 51732
        },
        {
         "query": "abyB2",
         "subject": "ABB86409.1",
         "query_loc": 37944,
         "subject_loc": 40723
        },
        {
         "query": "abyB1",
         "subject": "ABB86408.1",
         "query_loc": 23726,
         "subject_loc": 25233
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABB86408.1",
         "start": 14949,
         "end": 35517,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB1"
         }
        },
        {
         "locus_tag": "ABB86409.1",
         "start": 35574,
         "end": 45873,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB2"
         }
        },
        {
         "locus_tag": "ABB86410.1",
         "start": 45899,
         "end": 57566,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "abyB3"
         }
        },
        {
         "locus_tag": "ABB86411.1",
         "start": 57574,
         "end": 58348,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Hybrid-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 7,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 510,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "ACP",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 866,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "mal"
     },
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Modular-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 956,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 1477,
        "terminalDocking": ""
       },
       {
        "name": "DH",
        "description": "PKS_DH",
        "modifier": true,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-mod-dh",
        "inactive": false,
        "start": 1824,
        "terminalDocking": ""
       },
       {
        "name": "KR",
        "description": "PKS_KR",
        "modifier": true,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-mod-kr",
        "inactive": false,
        "start": 2189,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PKS_PP",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 2443,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "ccmal"
     },
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Modular-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 2541,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 3061,
        "terminalDocking": ""
       },
       {
        "name": "DH",
        "description": "PKS_DH",
        "modifier": true,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-mod-dh",
        "inactive": false,
        "start": 3404,
        "terminalDocking": ""
       },
       {
        "name": "KR",
        "description": "PKS_KR",
        "modifier": true,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-mod-kr",
        "inactive": false,
        "start": 3802,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "ACP",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 4055,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "ccmal"
     },
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Modular-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 4146,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 4661,
        "terminalDocking": ""
       },
       {
        "name": "DH",
        "description": "PKS_DH",
        "modifier": true,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-mod-dh",
        "inactive": false,
        "start": 4998,
        "terminalDocking": ""
       },
       {
        "name": "KR",
        "description": "PKS_KR",
        "modifier": true,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-mod-kr",
        "inactive": false,
        "start": 5407,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PKS_PP",
        "modifier": false,
        "special": false,
        "cds": "abyB1",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 5662,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "ccmal"
     },
     {
      "domains": [
       {
        "name": "",
        "description": "PKS_Docking_Nterm",
        "modifier": false,
        "special": "start",
        "cds": "abyB2",
        "css": "jsdomain-docking",
        "inactive": false,
        "start": 14,
        "terminalDocking": "start"
       }
      ],
      "complete": false,
      "iterative": false,
      "polymer": ""
     },
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Modular-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 45,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 573,
        "terminalDocking": ""
       },
       {
        "name": "DH",
        "description": "PKS_DH",
        "modifier": true,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-mod-dh",
        "inactive": false,
        "start": 920,
        "terminalDocking": ""
       },
       {
        "name": "KR",
        "description": "PKS_KR - inactive",
        "modifier": true,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-mod-kr",
        "inactive": true,
        "start": 1304,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PKS_PP",
        "modifier": false,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 1538,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Me-ccmal"
     },
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Modular-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 1642,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 2160,
        "terminalDocking": ""
       },
       {
        "name": "DH",
        "description": "PKS_DH",
        "modifier": true,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-mod-dh",
        "inactive": false,
        "start": 2512,
        "terminalDocking": ""
       },
       {
        "name": "ER",
        "description": "PKS_ER",
        "modifier": true,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-mod-er",
        "inactive": false,
        "start": 2938,
        "terminalDocking": ""
       },
       {
        "name": "KR",
        "description": "PKS_KR",
        "modifier": true,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-mod-kr",
        "inactive": false,
        "start": 3238,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "ACP",
        "modifier": false,
        "special": false,
        "cds": "abyB2",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 3522,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Me-redmal"
     },
     {
      "domains": [
       {
        "name": "",
        "description": "PKS_Docking_Nterm",
        "modifier": false,
        "special": "start",
        "cds": "abyB3",
        "css": "jsdomain-docking",
        "inactive": false,
        "start": 5,
        "terminalDocking": "start"
       }
      ],
      "complete": false,
      "iterative": false,
      "polymer": ""
     },
     {
      "domains": [
       {
        "name": "KS",
        "description": "PKS_KS(Modular-KS)",
        "modifier": false,
        "special": false,
        "cds": "abyB3",
        "css": "jsdomain-ketosynthase",
        "inactive": false,
        "start": 36,
        "terminalDocking": ""
       },
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "abyB3",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 550,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "ACP",
        "modifier": false,
        "special": false,
        "cds": "abyB3",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 915,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "mal"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "orfP": {
     "functions": [
      {
       "description": "PCMT",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "AEK75491.1": {
     "functions": []
    },
    "abyR": {
     "functions": [
      {
       "description": "SMCOG1041:transcriptional regulator, SARP family ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "abyX": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1007:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyH": {
     "functions": [
      {
       "description": "SMCOG1149:LuxR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "abyI": {
     "functions": [
      {
       "description": "SMCOG1041:transcriptional regulator, SARP family ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "abyK": {
     "functions": []
    },
    "abyA1": {
     "functions": [
      {
       "description": "fabH",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1084:3-oxoacyl-(acyl carrier protein) synthase III ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyA2": {
     "functions": [
      {
       "description": "SMCOG1256:FkbH like protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyA3": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "abyA4": {
     "functions": []
    },
    "abyA5": {
     "functions": []
    },
    "abyB1": {
     "functions": [
      {
       "description": "mod_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PKS_AT",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "hyb_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyB2": {
     "functions": [
      {
       "description": "mod_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PKS_AT",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "ADH_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "ADH_zinc_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1021:malonyl CoA-acyl carrier protein transacylase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyB3": {
     "functions": [
      {
       "description": "mod_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PKS_AT",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyC": {
     "functions": [
      {
       "description": "SMCOG1057:TetR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "abyD": {
     "functions": [
      {
       "description": "SMCOG1005:Drug resistance transporter, EmrB/QacA ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "abyE": {
     "functions": [
      {
       "description": "SMCOG1251:luciferase family protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "abyF1": {
     "functions": [
      {
       "description": "SMCOG1068:extracellular solute-binding protein family 5 ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "abyF2": {
     "functions": [
      {
       "description": "SMCOG1118:binding-protein-dependent transport systems ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "abyF3": {
     "functions": [
      {
       "description": "SMCOG1085:binding-protein-dependent transport systems ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "abyF4": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "abyV": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1007:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "abyW": {
     "functions": [
      {
       "description": "SMCOG1265:ferredoxin ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "abyZ": {
     "functions": []
    },
    "abyT": {
     "functions": [
      {
       "description": "Abhydrolase_6",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1004:thioesterase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "orfU": {
     "functions": [
      {
       "description": "ADH_zinc_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "orfS": {
     "functions": [
      {
       "description": "SMCOG1057:TetR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "orfP",
      "seqLength": 360,
      "domains": [
       {
        "start": 23,
        "end": 143,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PCMT",
        "accession": "PF01135",
        "description": "Protein-L-isoaspartate(D-aspartate) O-methyltransferase (PCMT)",
        "evalue": "2.9e-25",
        "score": "89.4"
       }
      ]
     },
     {
      "id": "abyR",
      "seqLength": 248,
      "domains": [
       {
        "start": 17,
        "end": 87,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Trans_reg_C",
        "accession": "PF00486",
        "description": "Transcriptional regulatory protein, C terminal",
        "evalue": "3.3e-09",
        "score": "36.8"
       },
       {
        "start": 93,
        "end": 238,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "BTAD",
        "accession": "PF03704",
        "description": "Bacterial transcriptional activator domain",
        "evalue": "1.3e-36",
        "score": "126.3"
       }
      ]
     },
     {
      "id": "abyX",
      "seqLength": 396,
      "domains": [
       {
        "start": 29,
        "end": 365,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "3.6e-27",
        "score": "95.3"
       }
      ]
     },
     {
      "id": "abyH",
      "seqLength": 889,
      "domains": [
       {
        "start": 828,
        "end": 884,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "GerE",
        "accession": "PF00196",
        "description": "Bacterial regulatory proteins, luxR family",
        "evalue": "9.6e-16",
        "score": "57.3"
       }
      ]
     },
     {
      "id": "abyI",
      "seqLength": 252,
      "domains": [
       {
        "start": 22,
        "end": 83,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Trans_reg_C",
        "accession": "PF00486",
        "description": "Transcriptional regulatory protein, C terminal",
        "evalue": "1.4e-08",
        "score": "34.9"
       },
       {
        "start": 94,
        "end": 240,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "BTAD",
        "accession": "PF03704",
        "description": "Bacterial transcriptional activator domain",
        "evalue": "8.4e-40",
        "score": "136.6"
       }
      ]
     },
     {
      "id": "abyK",
      "seqLength": 619,
      "domains": [
       {
        "start": 131,
        "end": 167,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "RHS_repeat",
        "accession": "PF05593",
        "description": "RHS Repeat",
        "evalue": "7.4e-06",
        "score": "26.5"
       }
      ]
     },
     {
      "id": "abyA1",
      "seqLength": 341,
      "domains": [
       {
        "start": 118,
        "end": 198,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004315' target='_blank'>GO:0004315</a>: 3-oxoacyl-[acyl-carrier-protein] synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006633' target='_blank'>GO:0006633</a>: fatty acid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "ACP_syn_III",
        "accession": "PF08545",
        "description": "3-Oxoacyl-[acyl-carrier-protein (ACP)] synthase III",
        "evalue": "3.4e-11",
        "score": "43.0"
       },
       {
        "start": 253,
        "end": 325,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ACP_syn_III_C",
        "accession": "PF08541",
        "description": "3-Oxoacyl-[acyl-carrier-protein (ACP)] synthase III C terminal",
        "evalue": "6e-07",
        "score": "29.7"
       }
      ]
     },
     {
      "id": "abyA3",
      "seqLength": 78,
      "domains": [
       {
        "start": 9,
        "end": 73,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.6e-08",
        "score": "34.8"
       }
      ]
     },
     {
      "id": "abyA4",
      "seqLength": 251,
      "domains": [
       {
        "start": 164,
        "end": 250,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "2-oxoacid_dh",
        "accession": "PF00198",
        "description": "2-oxoacid dehydrogenases acyltransferase (catalytic domain)",
        "evalue": "1.5e-17",
        "score": "64.0"
       }
      ]
     },
     {
      "id": "abyA5",
      "seqLength": 355,
      "domains": [
       {
        "start": 45,
        "end": 283,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "FrsA-like",
        "accession": "PF06500",
        "description": "Esterase FrsA-like",
        "evalue": "1.9e-12",
        "score": "46.8"
       }
      ]
     },
     {
      "id": "abyB1",
      "seqLength": 5781,
      "domains": [
       {
        "start": 5,
        "end": 243,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "7.9e-80",
        "score": "268.2"
       },
       {
        "start": 250,
        "end": 366,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "1.5e-36",
        "score": "125.1"
       },
       {
        "start": 368,
        "end": 475,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "1.9e-19",
        "score": "70.3"
       },
       {
        "start": 509,
        "end": 811,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "4.8e-59",
        "score": "200.6"
       },
       {
        "start": 869,
        "end": 935,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.7e-12",
        "score": "47.6"
       },
       {
        "start": 954,
        "end": 1205,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "1.5e-91",
        "score": "306.6"
       },
       {
        "start": 1212,
        "end": 1328,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "1.7e-43",
        "score": "147.5"
       },
       {
        "start": 1330,
        "end": 1446,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "2.3e-17",
        "score": "63.6"
       },
       {
        "start": 1476,
        "end": 1775,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "9.6e-57",
        "score": "193.0"
       },
       {
        "start": 1824,
        "end": 2071,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PS-DH",
        "accession": "PF14765",
        "description": "Polyketide synthase dehydratase",
        "evalue": "6.9e-43",
        "score": "147.1"
       },
       {
        "start": 2189,
        "end": 2365,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "KR",
        "accession": "PF08659",
        "description": "KR domain",
        "evalue": "6.6e-53",
        "score": "179.4"
       },
       {
        "start": 2452,
        "end": 2519,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "5.1e-13",
        "score": "49.3"
       },
       {
        "start": 2539,
        "end": 2790,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "4.8e-93",
        "score": "311.5"
       },
       {
        "start": 2797,
        "end": 2913,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "3.2e-43",
        "score": "146.6"
       },
       {
        "start": 2915,
        "end": 3030,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "1.4e-16",
        "score": "61.1"
       },
       {
        "start": 3060,
        "end": 3359,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "9.6e-57",
        "score": "193.0"
       },
       {
        "start": 3404,
        "end": 3663,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PS-DH",
        "accession": "PF14765",
        "description": "Polyketide synthase dehydratase",
        "evalue": "3.3e-39",
        "score": "135.0"
       },
       {
        "start": 3802,
        "end": 3980,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "KR",
        "accession": "PF08659",
        "description": "KR domain",
        "evalue": "2.3e-62",
        "score": "210.2"
       },
       {
        "start": 4056,
        "end": 4123,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "5.3e-12",
        "score": "46.0"
       },
       {
        "start": 4144,
        "end": 4396,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "2.2e-89",
        "score": "299.5"
       },
       {
        "start": 4403,
        "end": 4519,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "3.2e-43",
        "score": "146.6"
       },
       {
        "start": 4521,
        "end": 4611,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "1.4e-10",
        "score": "41.8"
       },
       {
        "start": 4659,
        "end": 4926,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "1.6e-51",
        "score": "175.9"
       },
       {
        "start": 4998,
        "end": 5252,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PS-DH",
        "accession": "PF14765",
        "description": "Polyketide synthase dehydratase",
        "evalue": "1.5e-34",
        "score": "119.8"
       },
       {
        "start": 5407,
        "end": 5582,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "KR",
        "accession": "PF08659",
        "description": "KR domain",
        "evalue": "3.9e-55",
        "score": "186.6"
       },
       {
        "start": 5677,
        "end": 5744,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "2.8e-12",
        "score": "46.9"
       }
      ]
     },
     {
      "id": "abyB2",
      "seqLength": 3645,
      "domains": [
       {
        "start": 11,
        "end": 39,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016740' target='_blank'>GO:0016740</a>: transferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Docking",
        "accession": "PF08990",
        "description": "Erythronolide synthase docking domain",
        "evalue": "7.8e-07",
        "score": "28.8"
       },
       {
        "start": 43,
        "end": 294,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "2.1e-91",
        "score": "306.1"
       },
       {
        "start": 301,
        "end": 417,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "5.2e-41",
        "score": "139.5"
       },
       {
        "start": 421,
        "end": 532,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "1.2e-15",
        "score": "58.1"
       },
       {
        "start": 571,
        "end": 847,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "6.4e-88",
        "score": "295.4"
       },
       {
        "start": 920,
        "end": 1171,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PS-DH",
        "accession": "PF14765",
        "description": "Polyketide synthase dehydratase",
        "evalue": "7.3e-14",
        "score": "51.8"
       },
       {
        "start": 1304,
        "end": 1468,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "KR",
        "accession": "PF08659",
        "description": "KR domain",
        "evalue": "1.6e-20",
        "score": "73.9"
       },
       {
        "start": 1552,
        "end": 1620,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "9.7e-14",
        "score": "51.6"
       },
       {
        "start": 1640,
        "end": 1890,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "8.3e-87",
        "score": "291.1"
       },
       {
        "start": 1897,
        "end": 2013,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "1.2e-42",
        "score": "144.8"
       },
       {
        "start": 2015,
        "end": 2114,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "1.3e-13",
        "score": "51.5"
       },
       {
        "start": 2158,
        "end": 2466,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "4.3e-84",
        "score": "282.9"
       },
       {
        "start": 2512,
        "end": 2772,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PS-DH",
        "accession": "PF14765",
        "description": "Polyketide synthase dehydratase",
        "evalue": "8.1e-53",
        "score": "179.7"
       },
       {
        "start": 3107,
        "end": 3229,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "ADH_zinc_N_2",
        "accession": "PF13602",
        "description": "Zinc-binding dehydrogenase",
        "evalue": "6.5e-14",
        "score": "53.2"
       },
       {
        "start": 3238,
        "end": 3417,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "KR",
        "accession": "PF08659",
        "description": "KR domain",
        "evalue": "5.6e-60",
        "score": "202.4"
       },
       {
        "start": 3523,
        "end": 3590,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.8e-12",
        "score": "47.5"
       }
      ]
     },
     {
      "id": "abyB3",
      "seqLength": 992,
      "domains": [
       {
        "start": 5,
        "end": 32,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016740' target='_blank'>GO:0016740</a>: transferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Docking",
        "accession": "PF08990",
        "description": "Erythronolide synthase docking domain",
        "evalue": "1.2e-07",
        "score": "31.3"
       },
       {
        "start": 34,
        "end": 278,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "4.3e-81",
        "score": "272.3"
       },
       {
        "start": 285,
        "end": 401,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "1.6e-43",
        "score": "147.6"
       },
       {
        "start": 403,
        "end": 513,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "KAsynt_C_assoc",
        "accession": "PF16197",
        "description": "Ketoacyl-synthetase C-terminal extension",
        "evalue": "1.2e-15",
        "score": "58.0"
       },
       {
        "start": 549,
        "end": 858,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "2e-52",
        "score": "178.8"
       },
       {
        "start": 917,
        "end": 984,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.1e-12",
        "score": "48.2"
       }
      ]
     },
     {
      "id": "abyC",
      "seqLength": 230,
      "domains": [
       {
        "start": 19,
        "end": 65,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding"
        ],
        "html_class": "generic-type-regulatory",
        "name": "TetR_N",
        "accession": "PF00440",
        "description": "Bacterial regulatory proteins, tetR family",
        "evalue": "9.3e-15",
        "score": "54.3"
       },
       {
        "start": 94,
        "end": 210,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TetR_C_7",
        "accession": "PF14246",
        "description": "AefR-like transcriptional repressor, C-terminal domain",
        "evalue": "3e-25",
        "score": "88.6"
       }
      ]
     },
     {
      "id": "abyD",
      "seqLength": 475,
      "domains": [
       {
        "start": 20,
        "end": 413,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
        ],
        "html_class": "generic-type-transport",
        "name": "MFS_1",
        "accession": "PF07690",
        "description": "Major Facilitator Superfamily",
        "evalue": "3.5e-55",
        "score": "187.5"
       }
      ]
     },
     {
      "id": "abyE",
      "seqLength": 335,
      "domains": [
       {
        "start": 16,
        "end": 299,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Bac_luciferase",
        "accession": "PF00296",
        "description": "Luciferase-like monooxygenase",
        "evalue": "2.1e-38",
        "score": "132.6"
       }
      ]
     },
     {
      "id": "abyF1",
      "seqLength": 538,
      "domains": [
       {
        "start": 79,
        "end": 446,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "SBP_bac_5",
        "accession": "PF00496",
        "description": "Bacterial extracellular solute-binding proteins, family 5 Middle",
        "evalue": "7.4e-71",
        "score": "239.3"
       }
      ]
     },
     {
      "id": "abyF2",
      "seqLength": 311,
      "domains": [
       {
        "start": 4,
        "end": 105,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "BPD_transp_1_N",
        "accession": "PF19300",
        "description": "Binding-prot-dependent transport system membrane comp, N-term",
        "evalue": "8.1e-09",
        "score": "35.8"
       },
       {
        "start": 119,
        "end": 307,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-transport",
        "name": "BPD_transp_1",
        "accession": "PF00528",
        "description": "Binding-protein-dependent transport system inner membrane component",
        "evalue": "2.3e-30",
        "score": "105.9"
       }
      ]
     },
     {
      "id": "abyF3",
      "seqLength": 283,
      "domains": [
       {
        "start": 96,
        "end": 267,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-transport",
        "name": "BPD_transp_1",
        "accession": "PF00528",
        "description": "Binding-protein-dependent transport system inner membrane component",
        "evalue": "4.5e-26",
        "score": "91.8"
       }
      ]
     },
     {
      "id": "abyF4",
      "seqLength": 539,
      "domains": [
       {
        "start": 25,
        "end": 183,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_tran",
        "accession": "PF00005",
        "description": "ABC transporter",
        "evalue": "2.2e-23",
        "score": "83.4"
       },
       {
        "start": 233,
        "end": 274,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015833' target='_blank'>GO:0015833</a>: peptide transport"
        ],
        "html_class": "generic-type-transport",
        "name": "oligo_HPY",
        "accession": "PF08352",
        "description": "Oligopeptide/dipeptide transporter, C-terminal region",
        "evalue": "1e-05",
        "score": "26.0"
       },
       {
        "start": 308,
        "end": 448,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_tran",
        "accession": "PF00005",
        "description": "ABC transporter",
        "evalue": "2.4e-31",
        "score": "109.2"
       },
       {
        "start": 499,
        "end": 529,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015833' target='_blank'>GO:0015833</a>: peptide transport"
        ],
        "html_class": "generic-type-transport",
        "name": "oligo_HPY",
        "accession": "PF08352",
        "description": "Oligopeptide/dipeptide transporter, C-terminal region",
        "evalue": "3.4e-06",
        "score": "27.6"
       }
      ]
     },
     {
      "id": "abyV",
      "seqLength": 395,
      "domains": [
       {
        "start": 268,
        "end": 364,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "5.9e-21",
        "score": "74.9"
       }
      ]
     },
     {
      "id": "abyW",
      "seqLength": 83,
      "domains": [
       {
        "start": 16,
        "end": 75,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Fer4_15",
        "accession": "PF13459",
        "description": "4Fe-4S single cluster domain",
        "evalue": "2.5e-11",
        "score": "44.2"
       }
      ]
     },
     {
      "id": "abyZ",
      "seqLength": 192,
      "domains": [
       {
        "start": 2,
        "end": 143,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "FMN_red",
        "accession": "PF03358",
        "description": "NADPH-dependent FMN reductase",
        "evalue": "1.3e-29",
        "score": "103.1"
       }
      ]
     },
     {
      "id": "abyT",
      "seqLength": 298,
      "domains": [
       {
        "start": 26,
        "end": 237,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Thioesterase",
        "accession": "PF00975",
        "description": "Thioesterase domain",
        "evalue": "5.4e-34",
        "score": "118.4"
       }
      ]
     },
     {
      "id": "orfU",
      "seqLength": 302,
      "domains": [
       {
        "start": 175,
        "end": 299,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "ADH_zinc_N_2",
        "accession": "PF13602",
        "description": "Zinc-binding dehydrogenase",
        "evalue": "3.3e-12",
        "score": "47.7"
       }
      ]
     },
     {
      "id": "orfS",
      "seqLength": 197,
      "domains": [
       {
        "start": 14,
        "end": 61,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding"
        ],
        "html_class": "generic-type-regulatory",
        "name": "TetR_N",
        "accession": "PF00440",
        "description": "Bacterial regulatory proteins, tetR family",
        "evalue": "2e-08",
        "score": "34.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "abyK",
      "seqLength": 619,
      "domains": [
       {
        "start": 90,
        "end": 119,
        "name": "TIGR01643",
        "description": "YD_repeat_2x: YD repeat (two copies)",
        "accession": "TIGR01643",
        "evalue": "0.00031",
        "score": "19.2",
        "html_class": "generic-type-other"
       },
       {
        "start": 131,
        "end": 167,
        "name": "TIGR01643",
        "description": "YD_repeat_2x: YD repeat (two copies)",
        "accession": "TIGR01643",
        "evalue": "5.4e-08",
        "score": "31.0",
        "html_class": "generic-type-other"
       },
       {
        "start": 238,
        "end": 280,
        "name": "TIGR01643",
        "description": "YD_repeat_2x: YD repeat (two copies)",
        "accession": "TIGR01643",
        "evalue": "9.6e-09",
        "score": "33.4",
        "html_class": "generic-type-other"
       },
       {
        "start": 309,
        "end": 335,
        "name": "TIGR01643",
        "description": "YD_repeat_2x: YD repeat (two copies)",
        "accession": "TIGR01643",
        "evalue": "0.00048",
        "score": "18.6",
        "html_class": "generic-type-other"
       },
       {
        "start": 501,
        "end": 572,
        "name": "TIGR03696",
        "description": "Rhs_assc_core: RHS repeat-associated core domain",
        "accession": "TIGR03696",
        "evalue": "9e-11",
        "score": "40.1",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "abyA2",
      "seqLength": 622,
      "domains": [
       {
        "start": 262,
        "end": 589,
        "name": "TIGR01686",
        "description": "FkbH: FkbH domain",
        "accession": "TIGR01686",
        "evalue": "3.5e-88",
        "score": "293.8",
        "html_class": "generic-type-other"
       },
       {
        "start": 264,
        "end": 386,
        "name": "TIGR01681",
        "description": "HAD-SF-IIIC: HAD phosphatase, family IIIC",
        "accession": "TIGR01681",
        "evalue": "9.8e-17",
        "score": "60.0",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "abyD",
      "seqLength": 475,
      "domains": [
       {
        "start": 13,
        "end": 422,
        "name": "TIGR00711",
        "description": "efflux_EmrB: drug resistance MFS transporter, drug:H+ antiporter-2 (14 Spanner) (DHA2) family",
        "accession": "TIGR00711",
        "evalue": "8.5e-103",
        "score": "342.6",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "abyE",
      "seqLength": 335,
      "domains": [
       {
        "start": 6,
        "end": 328,
        "name": "TIGR03558",
        "description": "oxido_grp_1: luciferase family oxidoreductase, group 1",
        "accession": "TIGR03558",
        "evalue": "4.6e-117",
        "score": "388.8",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "abyZ",
      "seqLength": 192,
      "domains": [
       {
        "start": 2,
        "end": 172,
        "name": "TIGR03567",
        "description": "FMN_reduc_SsuE: FMN reductase",
        "accession": "TIGR03567",
        "evalue": "8.8e-62",
        "score": "206.0",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};
